# AirGesture — Phase 1 (Foundation)

Native Android (Kotlin, View-based UI), CameraX + MediaPipe HandLandmarker, fully on-device.

## What Phase 1 does
- Home screen (dark theme, English / বাংলা switch, 10 menu cards — only Gesture Transfer is live)
- Camera with permission handling, front/back switch
- Real-time hand tracking with 21-landmark overlay
- Open Palm and Fist detection, debounced (stable after 4 frames), left/right hand label, FPS and latency readout
- "Move your hand closer" hint when the hand is too small to classify

## What Phase 1 does NOT do
No file picking, pairing or transfer yet (Phases 3–5). Grab/Release logic is Phase 2.

## Build
GitHub Actions (`.github/workflows/build-apk.yml`) downloads the MediaPipe model, builds a debug APK and
uploads it as the `AirGesture-debug-apk` artifact (Actions tab → latest run → Artifacts).
