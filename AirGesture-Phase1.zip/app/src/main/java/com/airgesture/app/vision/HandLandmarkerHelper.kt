package com.airgesture.app.vision

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.SystemClock
import android.util.Log
import androidx.camera.core.ImageProxy
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult

/**
 * Thin wrapper around MediaPipe HandLandmarker (LIVE_STREAM mode, fully on-device).
 * Throws from the constructor if the model file is missing from assets.
 */
class HandLandmarkerHelper(
    context: Context,
    private val listener: Listener,
    private val minConfidence: Float = 0.5f,
    private val maxHands: Int = 1
) {
    interface Listener {
        fun onResults(frame: HandFrame)
        fun onError(message: String)
    }

    @Volatile
    private var closed = false
    private var handLandmarker: HandLandmarker? = null

    init {
        setup(context.applicationContext)
    }

    private fun setup(context: Context) {
        val baseOptions = BaseOptions.builder()
            .setModelAssetPath(MODEL_PATH)
            .setDelegate(Delegate.CPU)
            .build()

        val options = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(baseOptions)
            .setNumHands(maxHands)
            .setMinHandDetectionConfidence(minConfidence)
            .setMinHandPresenceConfidence(minConfidence)
            .setMinTrackingConfidence(minConfidence)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setResultListener(this::onLandmarkerResult)
            .setErrorListener(this::onLandmarkerError)
            .build()

        handLandmarker = HandLandmarker.createFromOptions(context, options)
    }

    /** Always closes [imageProxy]. Safe to call from the camera analysis thread. */
    fun detectLiveStream(imageProxy: ImageProxy, isFrontCamera: Boolean) {
        imageProxy.use { proxy ->
            val landmarker = handLandmarker
            if (closed || landmarker == null) return

            val plane = proxy.planes[0]
            val pixelStride = plane.pixelStride
            val paddedWidth = plane.rowStride / pixelStride
            val padded = Bitmap.createBitmap(paddedWidth, proxy.height, Bitmap.Config.ARGB_8888)
            plane.buffer.rewind()
            padded.copyPixelsFromBuffer(plane.buffer)
            val source = if (paddedWidth != proxy.width) {
                Bitmap.createBitmap(padded, 0, 0, proxy.width, proxy.height)
            } else {
                padded
            }

            val matrix = Matrix().apply {
                postRotate(proxy.imageInfo.rotationDegrees.toFloat())
                if (isFrontCamera) {
                    postScale(-1f, 1f, proxy.width / 2f, proxy.height / 2f)
                }
            }
            val oriented = Bitmap.createBitmap(
                source, 0, 0, source.width, source.height, matrix, true
            )

            try {
                val mpImage = BitmapImageBuilder(oriented).build()
                landmarker.detectAsync(mpImage, SystemClock.uptimeMillis())
            } catch (e: Exception) {
                Log.w(TAG, "detectAsync failed", e)
            }
        }
    }

    private fun onLandmarkerResult(result: HandLandmarkerResult, input: MPImage) {
        if (closed) return
        val inferenceMs = SystemClock.uptimeMillis() - result.timestampMs()
        val hands = result.landmarks()
        if (hands.isEmpty()) {
            listener.onResults(HandFrame(null, null, 0f, input.width, input.height, inferenceMs))
            return
        }
        val category = result.handednesses().firstOrNull()?.firstOrNull()
        listener.onResults(
            HandFrame(
                landmarks = hands[0],
                handedness = category?.categoryName(),
                handednessScore = category?.score() ?: 0f,
                imageWidth = input.width,
                imageHeight = input.height,
                inferenceMs = inferenceMs
            )
        )
    }

    private fun onLandmarkerError(error: RuntimeException) {
        Log.e(TAG, "HandLandmarker error", error)
        listener.onError(error.message ?: "Hand detection error")
    }

    @Synchronized
    fun close() {
        closed = true
        try {
            handLandmarker?.close()
        } catch (e: Exception) {
            Log.w(TAG, "close failed", e)
        }
        handLandmarker = null
    }

    companion object {
        private const val TAG = "HandLandmarkerHelper"
        const val MODEL_PATH = "hand_landmarker.task"
    }
}
