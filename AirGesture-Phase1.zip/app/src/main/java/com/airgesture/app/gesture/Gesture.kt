package com.airgesture.app.gesture

/** Stable hand states recognised by the Phase 1 engine. */
enum class Gesture { NONE, OPEN_PALM, FIST, UNKNOWN }

/** Result of classifying a single frame. [tooFar] means the hand is too small to classify reliably. */
data class GestureResult(val gesture: Gesture, val tooFar: Boolean)

/** Smoothed landmark positions, normalised 0..1 in the (rotated, mirrored) analysis frame. */
class HandPoints(val x: FloatArray, val y: FloatArray)
