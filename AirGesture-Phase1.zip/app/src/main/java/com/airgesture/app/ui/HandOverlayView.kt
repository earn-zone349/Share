package com.airgesture.app.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import com.airgesture.app.R
import com.airgesture.app.gesture.Gesture
import com.airgesture.app.gesture.HandPoints
import kotlin.math.max

/** Draws the 21 hand landmarks on top of the camera preview (FILL_CENTER scaling). */
class HandOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var points: HandPoints? = null
    private var imageWidth = 1
    private var imageHeight = 1
    private var gesture = Gesture.NONE

    private val density = resources.displayMetrics.density

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 3f * density
        strokeCap = Paint.Cap.ROUND
    }
    private val pointPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.white)
        style = Paint.Style.FILL
    }

    fun setHand(points: HandPoints?, imageWidth: Int, imageHeight: Int, gesture: Gesture) {
        this.points = points
        this.imageWidth = imageWidth
        this.imageHeight = imageHeight
        this.gesture = gesture
        invalidate()
    }

    fun clear() {
        points = null
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val p = points ?: return
        if (imageWidth <= 0 || imageHeight <= 0 || width == 0 || height == 0) return

        val scale = max(width.toFloat() / imageWidth, height.toFloat() / imageHeight)
        val offsetX = (width - imageWidth * scale) / 2f
        val offsetY = (height - imageHeight * scale) / 2f

        linePaint.color = ContextCompat.getColor(
            context,
            when (gesture) {
                Gesture.OPEN_PALM -> R.color.success
                Gesture.FIST -> R.color.accent2
                else -> R.color.accent
            }
        )

        fun px(i: Int) = p.x[i] * imageWidth * scale + offsetX
        fun py(i: Int) = p.y[i] * imageHeight * scale + offsetY

        val count = p.x.size
        var i = 0
        while (i < CONNECTIONS.size) {
            val a = CONNECTIONS[i]
            val b = CONNECTIONS[i + 1]
            if (a < count && b < count) {
                canvas.drawLine(px(a), py(a), px(b), py(b), linePaint)
            }
            i += 2
        }
        for (k in 0 until count) {
            canvas.drawCircle(px(k), py(k), 4f * density, pointPaint)
        }
    }

    companion object {
        // Pairs of landmark indices: thumb, index, middle, ring, pinky and palm edges.
        private val CONNECTIONS = intArrayOf(
            0, 1, 1, 2, 2, 3, 3, 4,
            0, 5, 5, 6, 6, 7, 7, 8,
            5, 9, 9, 10, 10, 11, 11, 12,
            9, 13, 13, 14, 14, 15, 15, 16,
            13, 17, 17, 18, 18, 19, 19, 20,
            0, 17
        )
    }
}
