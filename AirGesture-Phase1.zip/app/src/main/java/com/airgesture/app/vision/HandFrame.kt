package com.airgesture.app.vision

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark

/** One processed camera frame. [landmarks] is null when no hand was found. */
data class HandFrame(
    val landmarks: List<NormalizedLandmark>?,
    val handedness: String?,
    val handednessScore: Float,
    val imageWidth: Int,
    val imageHeight: Int,
    val inferenceMs: Long
)
