package com.airgesture.app.gesture

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import kotlin.math.hypot

/**
 * Rule-based classifier working on the 21 MediaPipe hand landmarks.
 *
 * A finger counts as extended when its tip is clearly farther from the wrist than its PIP joint,
 * and as curled when the tip is no farther than the PIP joint. This works for any hand rotation
 * and for both hands. The thumb is ignored in Phase 1 (it is the least reliable signal).
 */
object GestureClassifier {
    private const val WRIST = 0
    private const val MIDDLE_MCP = 9
    private val FINGER_TIPS = intArrayOf(8, 12, 16, 20)
    private val FINGER_PIPS = intArrayOf(6, 10, 14, 18)

    private const val EXTENDED_RATIO = 1.15f
    private const val CURLED_RATIO = 1.0f
    private const val MIN_HAND_SIZE = 0.05f // wrist -> middle knuckle, as a fraction of frame diagonal

    fun classify(
        landmarks: List<NormalizedLandmark>,
        imageWidth: Int,
        imageHeight: Int
    ): GestureResult {
        if (landmarks.size < 21 || imageWidth <= 0 || imageHeight <= 0) {
            return GestureResult(Gesture.UNKNOWN, false)
        }

        fun dist(a: Int, b: Int): Float {
            val dx = (landmarks[a].x() - landmarks[b].x()) * imageWidth
            val dy = (landmarks[a].y() - landmarks[b].y()) * imageHeight
            return hypot(dx, dy)
        }

        val diagonal = hypot(imageWidth.toFloat(), imageHeight.toFloat())
        val handSize = dist(WRIST, MIDDLE_MCP) / diagonal
        if (handSize < MIN_HAND_SIZE) return GestureResult(Gesture.UNKNOWN, true)

        var extended = 0
        var curled = 0
        for (i in FINGER_TIPS.indices) {
            val pipDist = dist(FINGER_PIPS[i], WRIST)
            if (pipDist <= 0f) continue
            val ratio = dist(FINGER_TIPS[i], WRIST) / pipDist
            if (ratio >= EXTENDED_RATIO) extended++ else if (ratio <= CURLED_RATIO) curled++
        }

        val gesture = when {
            extended >= 3 && curled == 0 -> Gesture.OPEN_PALM
            extended == 0 && curled >= 3 -> Gesture.FIST
            else -> Gesture.UNKNOWN
        }
        return GestureResult(gesture, false)
    }
}
