package com.airgesture.app.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.util.Log
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.AspectRatio
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.airgesture.app.R
import com.airgesture.app.databinding.ActivityGestureBinding
import com.airgesture.app.gesture.Gesture
import com.airgesture.app.gesture.GestureClassifier
import com.airgesture.app.gesture.GestureStabilizer
import com.airgesture.app.gesture.LandmarkSmoother
import com.airgesture.app.vision.HandFrame
import com.airgesture.app.vision.HandLandmarkerHelper
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.roundToInt

/**
 * Phase 1 screen: live camera, on-device hand tracking, Open Palm / Fist detection.
 * No file transfer happens here yet.
 */
class GestureActivity : AppCompatActivity(), HandLandmarkerHelper.Listener {

    private lateinit var binding: ActivityGestureBinding
    private lateinit var cameraExecutor: ExecutorService

    @Volatile
    private var helper: HandLandmarkerHelper? = null
    private var cameraProvider: ProcessCameraProvider? = null

    @Volatile
    private var lensFacing = CameraSelector.LENS_FACING_FRONT
    private var cameraStarted = false

    private val stabilizer = GestureStabilizer()
    private val smoother = LandmarkSmoother()
    private var lastFrameTime = 0L
    private var fpsEma = 0f

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) onCameraPermissionGranted() else showPermissionPanel()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGestureBinding.inflate(layoutInflater)
        setContentView(binding.root)

        cameraExecutor = Executors.newSingleThreadExecutor()

        binding.backButton.setOnClickListener { finish() }
        binding.switchCameraButton.setOnClickListener { switchCamera() }
        binding.grantButton.setOnClickListener {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
        binding.settingsButton.setOnClickListener {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.fromParts("package", packageName, null)
                }
            )
        }

        renderState(Gesture.NONE, tooFar = false)
        binding.statsText.text = getString(R.string.stats_no_hand, 0)

        if (hasCameraPermission()) {
            onCameraPermissionGranted()
        } else {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    override fun onResume() {
        super.onResume()
        // Covers the case where the user granted permission from system settings.
        if (hasCameraPermission() && !cameraStarted) onCameraPermissionGranted()
    }

    override fun onDestroy() {
        cameraProvider?.unbindAll()
        helper?.close()
        helper = null
        cameraExecutor.shutdown()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- permission

    private fun hasCameraPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED

    private fun showPermissionPanel() {
        binding.permissionPanel.visibility = View.VISIBLE
    }

    private fun onCameraPermissionGranted() {
        if (cameraStarted) return
        cameraStarted = true
        binding.permissionPanel.visibility = View.GONE
        initHelper()
        startCamera()
    }

    // ---------------------------------------------------------------- hand model

    private fun initHelper() {
        if (helper != null) return
        cameraExecutor.execute {
            try {
                helper = HandLandmarkerHelper(applicationContext, this)
            } catch (e: Exception) {
                Log.e(TAG, "Hand model failed to load", e)
                runOnUiThread { showError(getString(R.string.err_model)) }
            }
        }
    }

    // ---------------------------------------------------------------- camera

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                cameraProvider = providerFuture.get()
                bindCameraUseCases()
            } catch (e: Exception) {
                Log.e(TAG, "Camera start failed", e)
                cameraStarted = false
                showError(getString(R.string.err_camera))
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindCameraUseCases() {
        val provider = cameraProvider ?: return

        var selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
        if (!provider.hasCamera(selector)) {
            lensFacing =
                if (lensFacing == CameraSelector.LENS_FACING_FRONT) CameraSelector.LENS_FACING_BACK
                else CameraSelector.LENS_FACING_FRONT
            selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
            if (!provider.hasCamera(selector)) {
                showError(getString(R.string.err_no_camera))
                return
            }
        }

        val preview = Preview.Builder()
            .setTargetAspectRatio(AspectRatio.RATIO_4_3)
            .build()
            .also { it.setSurfaceProvider(binding.previewView.surfaceProvider) }

        val analysis = ImageAnalysis.Builder()
            .setTargetAspectRatio(AspectRatio.RATIO_4_3)
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
            .build()
            .also { useCase ->
                useCase.setAnalyzer(cameraExecutor) { proxy ->
                    val h = helper
                    if (h == null) {
                        proxy.close()
                    } else {
                        h.detectLiveStream(proxy, lensFacing == CameraSelector.LENS_FACING_FRONT)
                    }
                }
            }

        try {
            provider.unbindAll()
            provider.bindToLifecycle(this, selector, preview, analysis)
        } catch (e: Exception) {
            Log.e(TAG, "Use case binding failed", e)
            showError(getString(R.string.err_camera))
        }
    }

    private fun switchCamera() {
        lensFacing =
            if (lensFacing == CameraSelector.LENS_FACING_FRONT) CameraSelector.LENS_FACING_BACK
            else CameraSelector.LENS_FACING_FRONT
        stabilizer.reset()
        smoother.reset()
        binding.overlay.clear()
        renderState(Gesture.NONE, tooFar = false)
        bindCameraUseCases()
    }

    // ---------------------------------------------------------------- results

    override fun onResults(frame: HandFrame) {
        runOnUiThread {
            if (isFinishing || isDestroyed) return@runOnUiThread
            handleFrame(frame)
        }
    }

    override fun onError(message: String) {
        runOnUiThread {
            if (isFinishing || isDestroyed) return@runOnUiThread
            showError(getString(R.string.err_detection))
        }
    }

    private fun handleFrame(frame: HandFrame) {
        updateFps()
        val fps = fpsEma.roundToInt()
        val landmarks = frame.landmarks

        if (landmarks == null) {
            smoother.reset()
            val stable = stabilizer.update(Gesture.NONE)
            binding.overlay.setHand(null, frame.imageWidth, frame.imageHeight, stable)
            renderState(stable, tooFar = false)
            binding.statsText.text = getString(R.string.stats_no_hand, fps)
            return
        }

        val result = GestureClassifier.classify(landmarks, frame.imageWidth, frame.imageHeight)
        val stable = stabilizer.update(result.gesture)
        val points = smoother.smooth(landmarks)
        binding.overlay.setHand(points, frame.imageWidth, frame.imageHeight, stable)
        renderState(stable, result.tooFar)

        val handLabel = when (frame.handedness) {
            "Left" -> getString(R.string.hand_left)
            "Right" -> getString(R.string.hand_right)
            else -> "–"
        }
        binding.statsText.text = getString(
            R.string.stats_format,
            handLabel,
            (frame.handednessScore * 100f).roundToInt(),
            fps,
            frame.inferenceMs.toInt()
        )
    }

    private fun updateFps() {
        val now = SystemClock.uptimeMillis()
        if (lastFrameTime != 0L) {
            val delta = (now - lastFrameTime).coerceAtLeast(1L)
            val instant = 1000f / delta
            fpsEma = if (fpsEma == 0f) instant else 0.9f * fpsEma + 0.1f * instant
        }
        lastFrameTime = now
    }

    private fun renderState(gesture: Gesture, tooFar: Boolean) {
        val emoji: String
        val title: Int
        var hint: Int
        val color: Int
        when (gesture) {
            Gesture.OPEN_PALM -> {
                emoji = "🖐️"; title = R.string.state_open_title
                hint = R.string.state_open_hint; color = R.color.success
            }
            Gesture.FIST -> {
                emoji = "✊"; title = R.string.state_fist_title
                hint = R.string.state_fist_hint; color = R.color.accent2
            }
            Gesture.UNKNOWN -> {
                emoji = "🤚"; title = R.string.state_unknown_title
                hint = R.string.state_unknown_hint; color = R.color.warning
            }
            Gesture.NONE -> {
                emoji = "👀"; title = R.string.state_none_title
                hint = R.string.state_none_hint; color = R.color.text_primary
            }
        }
        if (tooFar) hint = R.string.hint_move_closer
        binding.gestureEmoji.text = emoji
        binding.gestureTitle.setText(title)
        binding.gestureTitle.setTextColor(ContextCompat.getColor(this, color))
        binding.gestureHint.setText(hint)
    }

    private fun showError(message: String) {
        binding.errorBanner.text = message
        binding.errorBanner.visibility = View.VISIBLE
    }

    companion object {
        private const val TAG = "GestureActivity"
    }
}
