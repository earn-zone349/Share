package com.airgesture.app.net

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Random

class PairingProtocolTest {

    @Test
    fun hostNameRoundTrip() {
        val name = PairingProtocol.hostEndpointName("ABCD2345", "Rakib|Phone")
        val info = PairingProtocol.parseHost(name)
        assertNotNull(info)
        assertEquals("ABCD2345", info!!.sessionId)
        assertEquals("Rakib/Phone", info.deviceName)
    }

    @Test
    fun clientNameRoundTrip() {
        val name = PairingProtocol.clientRequestName("ABCD2345", "DEVK23", "Tab A")
        val info = PairingProtocol.parseClient(name)
        assertNotNull(info)
        assertEquals("ABCD2345", info!!.sessionId)
        assertEquals("DEVK23", info.deviceId)
        assertEquals("Tab A", info.deviceName)
    }

    @Test
    fun foreignNamesAreRejected() {
        assertNull(PairingProtocol.parseHost("Pixel 7"))
        assertNull(PairingProtocol.parseHost("AG1|short|x"))
        assertNull(PairingProtocol.parseHost("AG1|ABCD2345"))
        assertNull(PairingProtocol.parseClient("AG1|ABCD2345|DEVK23|x"))
        assertNull(PairingProtocol.parseClient("AGC|ABCD2345|bad|x"))
    }

    @Test
    fun qrRoundTripKeepsUnicodeNames() {
        val payload = PairingProtocol.qrPayload("ABCD2345", "রাকিব ফোন")
        val info = PairingProtocol.parseQr(payload)
        assertNotNull(info)
        assertEquals("ABCD2345", info!!.sessionId)
        assertEquals("রাকিব ফোন", info.deviceName)
    }

    @Test
    fun qrGarbageIsRejected() {
        assertNull(PairingProtocol.parseQr("https://example.com"))
        assertNull(PairingProtocol.parseQr("airgesture://pair?v=2&s=ABCD2345&n=x"))
        assertNull(PairingProtocol.parseQr("airgesture://pair?v=1&s=abc&n=x"))
        assertNull(PairingProtocol.parseQr("airgesture://pair?v=1&n=x"))
    }

    @Test
    fun namesAreCleanedAndShortened() {
        assertEquals("Android", PairingProtocol.cleanName("   "))
        assertEquals(24, PairingProtocol.cleanName("x".repeat(100)).length)
        assertEquals("a/b", PairingProtocol.cleanName("a|b"))
    }

    @Test
    fun generatedIdsAreValid() {
        val random = Random(42)
        repeat(50) {
            val id = PairingProtocol.newSessionId(random)
            assertTrue(id, Regex("[A-HJ-NP-Z2-9]{8}").matches(id))
            assertTrue(Regex("[A-HJ-NP-Z2-9]{6}").matches(PairingProtocol.newDeviceId(random)))
        }
    }
}
