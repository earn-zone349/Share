package com.airgesture.app.files

import org.junit.Assert.assertEquals
import org.junit.Test
import java.util.Locale

class FilesLogicTest {

    @Test
    fun sizeFormatting() {
        assertEquals("0 B", SizeFormatter.format(0, Locale.US))
        assertEquals("1023 B", SizeFormatter.format(1023, Locale.US))
        assertEquals("1.5 KB", SizeFormatter.format(1536, Locale.US))
        assertEquals("5.0 MB", SizeFormatter.format(5L * 1024 * 1024, Locale.US))
        assertEquals("2.0 GB", SizeFormatter.format(2L * 1024 * 1024 * 1024, Locale.US))
        assertEquals("?", SizeFormatter.format(-1, Locale.US))
    }

    @Test
    fun duplicatesFlagLaterCopiesOnly() {
        val keys = listOf(
            "a.jpg" to 10L,   // first: kept
            "A.JPG" to 10L,   // same name (case-insensitive) + size: duplicate
            "a.jpg" to 11L,   // different size: not a duplicate
            "b.bin" to -1L,   // unknown size: never flagged
            "b.bin" to -1L
        )
        assertEquals(setOf(1), DuplicateDetector.duplicateIndexes(keys))
    }

    @Test
    fun categoryByMime() {
        assertEquals(FileCategory.IMAGE, FileCategory.detect("image/jpeg", "x.jpg"))
        assertEquals(FileCategory.VIDEO, FileCategory.detect("video/mp4", "x.mp4"))
        assertEquals(FileCategory.AUDIO, FileCategory.detect("audio/mpeg", "x.mp3"))
        assertEquals(FileCategory.PDF, FileCategory.detect("application/pdf", "x"))
        assertEquals(FileCategory.ARCHIVE, FileCategory.detect("application/zip", "x.zip"))
        assertEquals(FileCategory.DOCUMENT, FileCategory.detect("text/plain", "x.txt"))
        assertEquals(
            FileCategory.DOCUMENT,
            FileCategory.detect(
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "x.docx"
            )
        )
    }

    @Test
    fun categoryFallsBackToExtension() {
        assertEquals(FileCategory.VIDEO, FileCategory.detect(null, "clip.MP4"))
        assertEquals(FileCategory.ARCHIVE, FileCategory.detect("application/octet-stream", "a.rar"))
        assertEquals(FileCategory.PDF, FileCategory.detect("application/octet-stream", "a.pdf"))
        assertEquals(FileCategory.OTHER, FileCategory.detect(null, "mystery"))
        assertEquals(
            FileCategory.OTHER,
            FileCategory.detect("application/vnd.android.package-archive", "app.apk")
        )
    }
}
