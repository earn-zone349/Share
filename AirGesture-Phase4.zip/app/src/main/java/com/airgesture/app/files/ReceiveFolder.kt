package com.airgesture.app.files

import android.content.Context
import android.os.StatFs
import java.io.File

/**
 * Dedicated folder for incoming files (created on first use) and free-space helpers.
 * The folder lives in app-specific storage, so no storage permission is needed.
 * Publishing received files to Downloads / Gallery is added together with real transfers (Phase 5).
 */
object ReceiveFolder {
    const val FOLDER_NAME = "AirGesture"
    private const val DEFAULT_RESERVE_BYTES = 100L * 1024 * 1024

    fun directory(context: Context): File {
        val base = context.getExternalFilesDir(null) ?: context.filesDir
        return File(base, FOLDER_NAME).also { if (!it.exists()) it.mkdirs() }
    }

    fun freeBytes(context: Context): Long = try {
        StatFs(directory(context).path).availableBytes
    } catch (e: Exception) {
        -1L
    }

    /** True if [bytes] fit while keeping [reserveBytes] free. Unknown free space counts as "not enough". */
    fun hasSpaceFor(context: Context, bytes: Long, reserveBytes: Long = DEFAULT_RESERVE_BYTES): Boolean {
        val free = freeBytes(context)
        return free >= 0 && free - reserveBytes >= bytes
    }
}
