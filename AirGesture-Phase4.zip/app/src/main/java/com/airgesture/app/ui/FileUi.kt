package com.airgesture.app.ui

import androidx.annotation.StringRes
import com.airgesture.app.R
import com.airgesture.app.files.FileCategory

@StringRes
fun FileCategory.labelRes(): Int = when (this) {
    FileCategory.IMAGE -> R.string.cat_image
    FileCategory.VIDEO -> R.string.cat_video
    FileCategory.AUDIO -> R.string.cat_audio
    FileCategory.PDF -> R.string.cat_pdf
    FileCategory.DOCUMENT -> R.string.cat_document
    FileCategory.ARCHIVE -> R.string.cat_archive
    FileCategory.OTHER -> R.string.cat_other
}
