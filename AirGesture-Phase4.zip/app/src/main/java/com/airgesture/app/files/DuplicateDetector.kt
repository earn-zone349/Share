package com.airgesture.app.files

/**
 * Flags later copies of a file that has the same name (case-insensitive) and the same size.
 * Files with an unknown size (< 0) are never flagged. The first occurrence is never flagged.
 */
object DuplicateDetector {
    fun duplicateIndexes(keys: List<Pair<String, Long>>): Set<Int> {
        val seen = HashSet<Pair<String, Long>>()
        val result = LinkedHashSet<Int>()
        for (i in keys.indices) {
            val (name, size) = keys[i]
            if (size < 0) continue
            if (!seen.add(name.lowercase() to size)) result.add(i)
        }
        return result
    }
}
