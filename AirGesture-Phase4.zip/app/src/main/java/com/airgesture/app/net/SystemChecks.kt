package com.airgesture.app.net

import android.bluetooth.BluetoothManager
import android.content.Context
import android.location.LocationManager
import android.net.wifi.WifiManager
import android.os.Build
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability

/** Quick readiness checks for offline pairing. None of them need the internet. */
object SystemChecks {

    enum class Problem { BLUETOOTH_OFF, WIFI_OFF, LOCATION_OFF }

    fun isBluetoothOn(context: Context): Boolean = try {
        val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        manager?.adapter?.isEnabled == true
    } catch (e: SecurityException) {
        true // cannot tell; do not block the user
    }

    fun isWifiOn(context: Context): Boolean = try {
        val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        wifi?.isWifiEnabled == true
    } catch (e: SecurityException) {
        true
    }

    /** Android 11 and below need Location switched on for nearby scanning; newer versions do not. */
    fun needsLocation(): Boolean = Build.VERSION.SDK_INT <= Build.VERSION_CODES.R

    fun isLocationOn(context: Context): Boolean {
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return true
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            lm.isLocationEnabled
        } else {
            lm.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
        }
    }

    fun playServicesOk(context: Context): Boolean =
        GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(context) ==
            ConnectionResult.SUCCESS

    /** The most important thing to fix first, or null when all is fine. */
    fun firstProblem(context: Context): Problem? = when {
        !isBluetoothOn(context) -> Problem.BLUETOOTH_OFF
        needsLocation() && !isLocationOn(context) -> Problem.LOCATION_OFF
        !isWifiOn(context) -> Problem.WIFI_OFF
        else -> null
    }
}
