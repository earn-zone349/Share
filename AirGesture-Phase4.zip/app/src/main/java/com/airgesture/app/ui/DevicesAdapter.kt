package com.airgesture.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.airgesture.app.databinding.ItemDeviceBinding
import com.airgesture.app.net.ConnectionManager

class DevicesAdapter(
    private val onClick: (ConnectionManager.Device) -> Unit
) : ListAdapter<ConnectionManager.Device, DevicesAdapter.Holder>(Diff) {

    class Holder(val binding: ItemDeviceBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(ItemDeviceBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val device = getItem(position)
        holder.binding.deviceName.text = device.name
        holder.binding.root.setOnClickListener { onClick(device) }
    }

    private object Diff : DiffUtil.ItemCallback<ConnectionManager.Device>() {
        override fun areItemsTheSame(a: ConnectionManager.Device, b: ConnectionManager.Device) =
            a.endpointId == b.endpointId

        override fun areContentsTheSame(a: ConnectionManager.Device, b: ConnectionManager.Device) = a == b
    }
}
