package com.airgesture.app.ui

import android.content.Context
import androidx.annotation.StringRes
import com.airgesture.app.R
import com.airgesture.app.net.ConnectionManager
import com.airgesture.app.net.SystemChecks

@StringRes
fun ConnectionManager.Problem.messageRes(): Int? = when (this) {
    ConnectionManager.Problem.NONE -> null
    ConnectionManager.Problem.START_FAILED -> R.string.prob_start_failed
    ConnectionManager.Problem.CONNECT_FAILED -> R.string.prob_connect_failed
    ConnectionManager.Problem.REJECTED -> R.string.prob_rejected
    ConnectionManager.Problem.LOST -> R.string.prob_lost
    ConnectionManager.Problem.TIMEOUT -> R.string.prob_timeout
}

/** Text of the most important thing to fix before pairing (Bluetooth, Location, Wi-Fi), or null. */
fun systemWarning(context: Context): String? = when (SystemChecks.firstProblem(context)) {
    SystemChecks.Problem.BLUETOOTH_OFF -> context.getString(R.string.sys_bluetooth_off)
    SystemChecks.Problem.LOCATION_OFF -> context.getString(R.string.sys_location_off)
    SystemChecks.Problem.WIFI_OFF -> context.getString(R.string.sys_wifi_off)
    null -> null
}
