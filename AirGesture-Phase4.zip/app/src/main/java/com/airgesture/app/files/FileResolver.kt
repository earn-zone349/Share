package com.airgesture.app.files

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap

/** Reads name, size and type of a content URI. Call from a background thread. */
class FileResolver(context: Context) {
    private val resolver = context.applicationContext.contentResolver

    /** Returns null when the file cannot be read (permission revoked, deleted, ...). */
    fun resolve(uri: Uri, fromCamera: Boolean = false): SharedFile? {
        var name: String? = null
        var size = -1L

        try {
            resolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
                null, null, null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIndex >= 0 && !cursor.isNull(nameIndex)) name = cursor.getString(nameIndex)
                    if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
                }
            }
        } catch (e: Exception) {
            // fall back to the generic lookups below
        }

        if (size < 0) {
            size = try {
                resolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
            } catch (e: Exception) {
                -1L
            }
        }

        val readable = try {
            resolver.openInputStream(uri)?.use { true } ?: false
        } catch (e: Exception) {
            false
        }
        if (!readable) return null

        val displayName = name?.takeIf { it.isNotBlank() }
            ?: uri.lastPathSegment?.substringAfterLast('/')
            ?: "file"

        val mime = resolver.getType(uri)?.takeIf { it.isNotBlank() }
            ?: MimeTypeMap.getSingleton()
                .getMimeTypeFromExtension(displayName.substringAfterLast('.', "").lowercase())
            ?: "application/octet-stream"

        return SharedFile(
            uri = uri,
            name = displayName,
            sizeBytes = size,
            mimeType = mime,
            category = FileCategory.detect(mime, displayName),
            fromCamera = fromCamera
        )
    }
}
