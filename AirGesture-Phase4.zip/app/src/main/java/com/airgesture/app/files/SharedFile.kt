package com.airgesture.app.files

import android.net.Uri

/**
 * A file the user chose to send. Only metadata and the content URI are stored: the file itself is
 * never copied or compressed, so sending later streams straight from the original location.
 */
data class SharedFile(
    val uri: Uri,
    val name: String,
    val sizeBytes: Long,
    val mimeType: String,
    val category: FileCategory,
    val fromCamera: Boolean = false
)
