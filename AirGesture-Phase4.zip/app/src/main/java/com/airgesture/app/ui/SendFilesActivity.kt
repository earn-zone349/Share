package com.airgesture.app.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.airgesture.app.R
import com.airgesture.app.databinding.ActivitySendFilesBinding
import com.airgesture.app.files.FileResolver
import com.airgesture.app.files.ReceiveFolder
import com.airgesture.app.files.SelectionStore
import com.airgesture.app.files.SizeFormatter
import com.airgesture.app.files.ThumbnailLoader
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Choose what to send: Photos & Videos (system photo picker), any file (system document picker),
 * or take a photo. Only the system pickers are used, so no storage permission is needed.
 * Files are never copied or compressed: we keep their URIs.
 */
class SendFilesActivity : AppCompatActivity(), SelectionStore.Listener {

    private lateinit var binding: ActivitySendFilesBinding
    private lateinit var adapter: SelectedFilesAdapter
    private val ioExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private var pendingCapturePath: String? = null

    private val pickMedia =
        registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { uris ->
            addUris(uris, fromCamera = false)
        }

    private val pickDocuments =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            uris.forEach { persistReadAccess(it) }
            addUris(uris, fromCamera = false)
        }

    private val takePicture =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            val path = pendingCapturePath
            pendingCapturePath = null
            if (path != null) {
                if (success) {
                    addUris(listOf(captureUri(File(path))), fromCamera = true)
                } else {
                    File(path).delete()
                }
            }
        }

    private val cameraPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) launchCapture()
            else Toast.makeText(this, R.string.msg_camera_denied, Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySendFilesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        pendingCapturePath = savedInstanceState?.getString(KEY_CAPTURE_PATH)

        adapter = SelectedFilesAdapter(ThumbnailLoader.get(this)) { SelectionStore.remove(it.uri) }
        binding.fileList.layoutManager = LinearLayoutManager(this)
        binding.fileList.adapter = adapter

        binding.backButton.setOnClickListener { finish() }
        binding.tileMedia.setOnClickListener {
            pickMedia.launch(
                PickVisualMediaRequest.Builder()
                    .setMediaType(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                    .build()
            )
        }
        binding.tileFiles.setOnClickListener { pickDocuments.launch(arrayOf("*/*")) }
        binding.tileCamera.setOnClickListener { onCameraClicked() }
        binding.clearButton.setOnClickListener { SelectionStore.clear() }
        binding.removeDuplicatesButton.setOnClickListener { SelectionStore.removeDuplicates() }
        binding.useGestureButton.setOnClickListener {
            startActivity(Intent(this, GestureActivity::class.java))
        }
    }

    override fun onStart() {
        super.onStart()
        SelectionStore.addListener(this)
        render()
    }

    override fun onStop() {
        SelectionStore.removeListener(this)
        super.onStop()
    }

    override fun onDestroy() {
        ioExecutor.shutdown()
        super.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        pendingCapturePath?.let { outState.putString(KEY_CAPTURE_PATH, it) }
    }

    override fun onSelectionChanged() = render()

    // ---------------------------------------------------------------- UI

    private fun render() {
        val files = SelectionStore.snapshot()
        val duplicates = SelectionStore.duplicateUris()
        val empty = files.isEmpty()

        adapter.submitList(files.map { FileRow(it, it.uri in duplicates) })
        binding.emptyState.visibility = if (empty) View.VISIBLE else View.GONE
        binding.fileList.visibility = if (empty) View.GONE else View.VISIBLE
        binding.clearButton.visibility = if (empty) View.GONE else View.VISIBLE
        binding.useGestureButton.isEnabled = !empty

        binding.summaryText.text = if (empty) {
            getString(R.string.send_no_files)
        } else {
            resources.getQuantityString(
                R.plurals.summary_files, files.size, files.size,
                SizeFormatter.format(SelectionStore.totalBytes())
            )
        }

        binding.duplicateBar.visibility = if (duplicates.isEmpty()) View.GONE else View.VISIBLE
        if (duplicates.isNotEmpty()) {
            binding.duplicateText.text = resources.getQuantityString(
                R.plurals.duplicates_found, duplicates.size, duplicates.size
            )
        }

        binding.storageText.text = getString(
            R.string.storage_format, SizeFormatter.format(ReceiveFolder.freeBytes(this))
        )
    }

    // ---------------------------------------------------------------- adding files

    private fun addUris(uris: List<Uri>, fromCamera: Boolean) {
        if (uris.isEmpty()) return
        ioExecutor.execute {
            val resolver = FileResolver(applicationContext)
            val resolved = uris.mapNotNull { resolver.resolve(it, fromCamera) }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                val result = SelectionStore.add(resolved)
                val unreadable = uris.size - resolved.size

                val messages = ArrayList<String>()
                if (unreadable > 0) {
                    messages.add(
                        resources.getQuantityString(R.plurals.msg_unreadable, unreadable, unreadable)
                    )
                }
                if (result.alreadyAdded > 0) {
                    messages.add(getString(R.string.msg_already_added, result.alreadyAdded))
                }
                if (result.overLimit > 0) {
                    messages.add(getString(R.string.msg_limit, SelectionStore.MAX_FILES))
                }
                if (messages.isNotEmpty()) {
                    Toast.makeText(this, messages.joinToString("\n"), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun persistReadAccess(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
            // Not every provider offers persistable grants; the temporary grant is enough for now.
        }
    }

    // ---------------------------------------------------------------- camera

    private fun onCameraClicked() {
        // The manifest declares CAMERA, and the system camera app refuses to start for us
        // unless that permission has actually been granted.
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) launchCapture() else cameraPermission.launch(Manifest.permission.CAMERA)
    }

    private fun launchCapture() {
        try {
            val dir = File(cacheDir, "captures").apply { mkdirs() }
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val file = File(dir, "IMG_$stamp.jpg")
            pendingCapturePath = file.absolutePath
            takePicture.launch(captureUri(file))
        } catch (e: Exception) {
            pendingCapturePath = null
            Toast.makeText(this, R.string.msg_no_camera_app, Toast.LENGTH_LONG).show()
        }
    }

    private fun captureUri(file: File): Uri =
        FileProvider.getUriForFile(this, "$packageName.fileprovider", file)

    private companion object {
        const val KEY_CAPTURE_PATH = "pending_capture_path"
    }
}
