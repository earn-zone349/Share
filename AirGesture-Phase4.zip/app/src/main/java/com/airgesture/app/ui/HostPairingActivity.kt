package com.airgesture.app.ui

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.airgesture.app.R
import com.airgesture.app.databinding.ActivityHostPairingBinding
import com.airgesture.app.net.ConnectionManager
import com.airgesture.app.net.ConnectionManager.Status
import com.airgesture.app.net.NearbyPermissionRequester
import com.airgesture.app.net.QrCode

/** Shows a QR code and waits for the other phone. The host always approves the connection. */
class HostPairingActivity : AppCompatActivity(), ConnectionManager.Listener {

    private lateinit var binding: ActivityHostPairingBinding
    private lateinit var manager: ConnectionManager
    private var finished = false

    private val permissions = NearbyPermissionRequester(this) { granted ->
        if (granted) {
            beginHosting()
        } else {
            binding.statusText.setText(R.string.perm_nearby_denied)
            binding.waitProgress.visibility = View.GONE
            binding.retryButton.visibility = View.VISIBLE
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHostPairingBinding.inflate(layoutInflater)
        setContentView(binding.root)
        manager = ConnectionManager.get(this)

        binding.backButton.setOnClickListener { finish() }
        binding.retryButton.setOnClickListener { permissions.request() }
        binding.requestPanel.acceptButton.setOnClickListener { manager.accept() }
        binding.requestPanel.rejectButton.setOnClickListener { manager.reject() }
        binding.phoneText.text = getString(R.string.host_phone_format, manager.localName)

        permissions.request()
    }

    override fun onStart() {
        super.onStart()
        manager.addListener(this)
        val warning = systemWarning(this)
        binding.warningBanner.visibility = if (warning != null) View.VISIBLE else View.GONE
        warning?.let { binding.warningBanner.text = it }
        render(manager.state)
    }

    override fun onStop() {
        manager.removeListener(this)
        super.onStop()
    }

    override fun onDestroy() {
        if (!isChangingConfigurations && manager.state.status != Status.CONNECTED &&
            manager.state.status != Status.RECONNECTING
        ) {
            manager.cancelPairing()
        }
        super.onDestroy()
    }

    private fun beginHosting() {
        binding.retryButton.visibility = View.GONE
        manager.clearProblem()
        manager.startHosting()
        showQr()
        render(manager.state)
    }

    private fun showQr() {
        val payload = manager.qrPayload() ?: return
        val sid = manager.state.sessionId.orEmpty()
        binding.qrImage.setImageBitmap(QrCode.generate(payload, 720))
        binding.pairIdText.text = getString(R.string.host_pair_id_format, sid)
    }

    override fun onStateChanged(state: ConnectionManager.State) = render(state)

    private fun render(state: ConnectionManager.State) {
        val pending = state.pending
        val showRequest = state.status == Status.CONFIRMING && pending != null
        binding.requestPanel.root.visibility = if (showRequest) View.VISIBLE else View.GONE
        if (showRequest && pending != null) {
            binding.requestPanel.requestPeerText.text =
                getString(R.string.req_peer_format, pending.peerName)
            binding.requestPanel.requestCodeText.text = pending.code
        }

        val problemRes = state.problem.messageRes()
        binding.waitProgress.visibility =
            if (state.status == Status.ADVERTISING || state.status == Status.REQUESTING) View.VISIBLE
            else View.GONE

        binding.statusText.text = when {
            problemRes != null && state.status != Status.CONNECTED -> getString(problemRes)
            state.status == Status.ADVERTISING -> getString(R.string.host_waiting)
            state.status == Status.REQUESTING -> getString(R.string.host_connecting_format, state.peerName ?: "")
            state.status == Status.CONFIRMING -> getString(R.string.host_confirm)
            else -> binding.statusText.text
        }
        binding.retryButton.visibility =
            if (state.status == Status.IDLE) View.VISIBLE else binding.retryButton.visibility

        if (state.status == Status.CONNECTED && !finished) {
            finished = true
            Toast.makeText(
                this, getString(R.string.toast_connected_format, state.peerName ?: ""), Toast.LENGTH_SHORT
            ).show()
            finish()
        }
    }
}
