package com.airgesture.app.net

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

/** Runtime permissions Nearby Connections needs, which differ per Android version. */
object NearbyPermissions {

    fun required(): List<String> {
        val list = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            list.add(Manifest.permission.BLUETOOTH_ADVERTISE)
            list.add(Manifest.permission.BLUETOOTH_CONNECT)
            list.add(Manifest.permission.BLUETOOTH_SCAN)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            list.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.S) { // Android 12 and below
            list.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        return list
    }

    fun missing(context: Context): Array<String> =
        required().filter {
            ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
        }.toTypedArray()

    fun allGranted(context: Context): Boolean = missing(context).isEmpty()
}

/** Create as a property of an Activity (it registers an ActivityResult launcher). */
class NearbyPermissionRequester(
    private val activity: ComponentActivity,
    private val onResult: (Boolean) -> Unit
) {
    private val launcher =
        activity.registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            onResult(NearbyPermissions.allGranted(activity))
        }

    fun request() {
        val missing = NearbyPermissions.missing(activity)
        if (missing.isEmpty()) onResult(true) else launcher.launch(missing)
    }
}
