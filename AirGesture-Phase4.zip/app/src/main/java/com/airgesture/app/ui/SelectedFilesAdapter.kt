package com.airgesture.app.ui

import android.graphics.Bitmap
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.airgesture.app.R
import com.airgesture.app.databinding.ItemFileBinding
import com.airgesture.app.files.SharedFile
import com.airgesture.app.files.SizeFormatter
import com.airgesture.app.files.ThumbnailLoader

data class FileRow(val file: SharedFile, val isDuplicate: Boolean)

class SelectedFilesAdapter(
    private val thumbnails: ThumbnailLoader,
    private val onRemove: (SharedFile) -> Unit
) : ListAdapter<FileRow, SelectedFilesAdapter.Holder>(Diff) {

    class Holder(val binding: ItemFileBinding) : RecyclerView.ViewHolder(binding.root) {
        var boundUri: Uri? = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(ItemFileBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val row = getItem(position)
        val file = row.file
        val b = holder.binding
        val context = b.root.context

        b.fileName.text = file.name
        b.fileMeta.text = context.getString(
            R.string.file_meta_format,
            context.getString(file.category.labelRes()),
            SizeFormatter.format(file.sizeBytes)
        )
        b.duplicateBadge.visibility = if (row.isDuplicate) View.VISIBLE else View.GONE
        b.removeButton.setOnClickListener { onRemove(file) }

        holder.boundUri = file.uri
        b.thumbEmoji.text = file.category.emoji
        val cached = thumbnails.cached(file, THUMB_PX)
        if (cached != null) {
            showThumbnail(b, cached)
        } else {
            showIcon(b)
            thumbnails.load(file, THUMB_PX) { bitmap ->
                if (bitmap != null && holder.boundUri == file.uri) showThumbnail(b, bitmap)
            }
        }
    }

    private fun showThumbnail(b: ItemFileBinding, bitmap: Bitmap) {
        b.thumbImage.setImageBitmap(bitmap)
        b.thumbImage.visibility = View.VISIBLE
        b.thumbEmoji.visibility = View.GONE
    }

    private fun showIcon(b: ItemFileBinding) {
        b.thumbImage.setImageDrawable(null)
        b.thumbImage.visibility = View.GONE
        b.thumbEmoji.visibility = View.VISIBLE
    }

    private object Diff : DiffUtil.ItemCallback<FileRow>() {
        override fun areItemsTheSame(oldItem: FileRow, newItem: FileRow) =
            oldItem.file.uri == newItem.file.uri

        override fun areContentsTheSame(oldItem: FileRow, newItem: FileRow) = oldItem == newItem
    }

    companion object {
        const val THUMB_PX = 160
    }
}
