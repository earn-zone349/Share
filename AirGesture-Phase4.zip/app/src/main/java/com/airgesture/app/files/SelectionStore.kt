package com.airgesture.app.files

import android.net.Uri
import java.util.concurrent.CopyOnWriteArrayList

/**
 * In-memory list of the files chosen for sending, shared by the Send Files and Gesture screens.
 * Mutations should happen on the main thread (listeners are notified on the calling thread).
 */
object SelectionStore {
    const val MAX_FILES = 200

    fun interface Listener {
        fun onSelectionChanged()
    }

    data class AddResult(val added: Int, val alreadyAdded: Int, val overLimit: Int)

    private val items = ArrayList<SharedFile>()
    private val listeners = CopyOnWriteArrayList<Listener>()

    fun addListener(listener: Listener) {
        listeners.addIfAbsent(listener)
    }

    fun removeListener(listener: Listener) {
        listeners.remove(listener)
    }

    @Synchronized
    fun snapshot(): List<SharedFile> = items.toList()

    @Synchronized
    fun totalBytes(): Long = items.sumOf { if (it.sizeBytes > 0) it.sizeBytes else 0L }

    @Synchronized
    fun duplicateUris(): Set<Uri> {
        val indexes = DuplicateDetector.duplicateIndexes(items.map { it.name to it.sizeBytes })
        return indexes.map { items[it].uri }.toSet()
    }

    fun add(newFiles: List<SharedFile>): AddResult {
        var added = 0
        var alreadyAdded = 0
        var overLimit = 0
        synchronized(this) {
            for (file in newFiles) {
                when {
                    items.any { it.uri == file.uri } -> alreadyAdded++
                    items.size >= MAX_FILES -> overLimit++
                    else -> {
                        items.add(file)
                        added++
                    }
                }
            }
        }
        if (added > 0) notifyChanged()
        return AddResult(added, alreadyAdded, overLimit)
    }

    fun remove(uri: Uri) {
        val changed = synchronized(this) { items.removeAll { it.uri == uri } }
        if (changed) notifyChanged()
    }

    /** Removes later copies of same-name, same-size files. Returns how many were removed. */
    fun removeDuplicates(): Int {
        val removed = synchronized(this) {
            val indexes = DuplicateDetector.duplicateIndexes(items.map { it.name to it.sizeBytes })
            val keep = items.filterIndexed { index, _ -> index !in indexes }
            items.clear()
            items.addAll(keep)
            indexes.size
        }
        if (removed > 0) notifyChanged()
        return removed
    }

    fun clear() {
        val changed = synchronized(this) {
            val had = items.isNotEmpty()
            items.clear()
            had
        }
        if (changed) notifyChanged()
    }

    private fun notifyChanged() {
        for (l in listeners) l.onSelectionChanged()
    }
}
