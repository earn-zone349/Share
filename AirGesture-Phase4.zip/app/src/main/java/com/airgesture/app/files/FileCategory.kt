package com.airgesture.app.files

/** Broad file kinds used for icons, labels and (later) per-type transfer handling. */
enum class FileCategory(val emoji: String) {
    IMAGE("🖼️"), VIDEO("🎬"), AUDIO("🎵"), PDF("📕"), DOCUMENT("📄"), ARCHIVE("🗜️"), OTHER("📎");

    companion object {
        private val ARCHIVE_MIMES = setOf(
            "application/zip", "application/x-zip-compressed", "application/x-rar-compressed",
            "application/vnd.rar", "application/x-7z-compressed", "application/gzip",
            "application/x-gzip", "application/x-tar", "application/x-bzip2"
        )
        private val DOC_MIME_HINTS = listOf(
            "msword", "wordprocessing", "excel", "spreadsheet", "powerpoint",
            "presentation", "opendocument", "rtf"
        )
        private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "gif", "webp", "heic", "heif", "bmp")
        private val VIDEO_EXT = setOf("mp4", "mkv", "webm", "3gp", "mov", "avi", "m4v")
        private val AUDIO_EXT = setOf("mp3", "m4a", "aac", "wav", "ogg", "flac", "opus")
        private val ARCHIVE_EXT = setOf("zip", "rar", "7z", "tar", "gz", "bz2")
        private val DOC_EXT = setOf(
            "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "odt", "ods", "odp", "rtf", "csv"
        )

        /** MIME type wins; the extension is the fallback for missing / generic MIME types. */
        fun detect(mime: String?, name: String): FileCategory {
            val m = mime?.lowercase()?.trim().orEmpty()
            val ext = name.substringAfterLast('.', "").lowercase()

            if (m.startsWith("image/")) return IMAGE
            if (m.startsWith("video/")) return VIDEO
            if (m.startsWith("audio/")) return AUDIO
            if (m == "application/pdf") return PDF
            if (m in ARCHIVE_MIMES) return ARCHIVE
            if (m.startsWith("text/") || DOC_MIME_HINTS.any { m.contains(it) }) return DOCUMENT

            return when {
                ext == "pdf" -> PDF
                ext in IMAGE_EXT -> IMAGE
                ext in VIDEO_EXT -> VIDEO
                ext in AUDIO_EXT -> AUDIO
                ext in ARCHIVE_EXT -> ARCHIVE
                ext in DOC_EXT -> DOCUMENT
                else -> OTHER
            }
        }
    }
}
