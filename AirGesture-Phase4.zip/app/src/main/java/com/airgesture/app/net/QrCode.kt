package com.airgesture.app.net

import android.graphics.Bitmap
import android.graphics.Color
import android.os.SystemClock
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.EncodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel

object QrCode {
    /** Black-on-white QR code, [sizePx] square. */
    fun generate(text: String, sizePx: Int): Bitmap {
        val hints = mapOf(
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,
            EncodeHintType.MARGIN to 1,
            EncodeHintType.CHARACTER_SET to "UTF-8"
        )
        val matrix = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, sizePx, sizePx, hints)
        val pixels = IntArray(sizePx * sizePx)
        for (y in 0 until sizePx) {
            val row = y * sizePx
            for (x in 0 until sizePx) {
                pixels[row + x] = if (matrix.get(x, y)) Color.BLACK else Color.WHITE
            }
        }
        return Bitmap.createBitmap(pixels, sizePx, sizePx, Bitmap.Config.ARGB_8888)
    }
}

/**
 * Reads QR codes from the camera's luminance (Y) plane with ZXing. QR codes are rotation
 * invariant, so no rotation handling is needed. [onQr] runs on the analysis thread.
 */
class QrAnalyzer(private val onQr: (String) -> Unit) : ImageAnalysis.Analyzer {
    private val reader = MultiFormatReader().apply {
        setHints(
            mapOf(
                DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE),
                DecodeHintType.TRY_HARDER to true
            )
        )
    }
    private var lastAnalyzed = 0L

    override fun analyze(image: ImageProxy) {
        image.use { proxy ->
            val now = SystemClock.uptimeMillis()
            if (now - lastAnalyzed < MIN_INTERVAL_MS) return
            lastAnalyzed = now

            val plane = proxy.planes[0]
            val width = proxy.width
            val height = proxy.height
            val rowStride = plane.rowStride
            val buffer = plane.buffer
            val data = ByteArray(width * height)
            for (row in 0 until height) {
                buffer.position(row * rowStride)
                buffer.get(data, row * width, width)
            }

            val source = PlanarYUVLuminanceSource(data, width, height, 0, 0, width, height, false)
            try {
                val result = reader.decodeWithState(BinaryBitmap(HybridBinarizer(source)))
                onQr(result.text)
            } catch (e: Exception) {
                // no QR code in this frame
            } finally {
                reader.reset()
            }
        }
    }

    private companion object {
        const val MIN_INTERVAL_MS = 150L
    }
}
