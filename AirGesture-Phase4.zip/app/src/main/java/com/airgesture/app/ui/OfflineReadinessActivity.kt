package com.airgesture.app.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.airgesture.app.R
import com.airgesture.app.databinding.ActivityOfflineReadinessBinding
import com.airgesture.app.databinding.ItemCheckBinding
import com.airgesture.app.net.NearbyPermissionRequester
import com.airgesture.app.net.NearbyPermissions
import com.airgesture.app.net.SystemChecks

/** Offline Mode: a checklist of everything pairing needs. None of it needs the internet. */
class OfflineReadinessActivity : AppCompatActivity() {

    private class Check(
        val ok: Boolean,
        @StringRes val title: Int,
        @StringRes val detail: Int,
        @StringRes val actionLabel: Int? = null,
        val action: (() -> Unit)? = null,
        val countsAsProblem: Boolean = true
    )

    private lateinit var binding: ActivityOfflineReadinessBinding

    private val permissions = NearbyPermissionRequester(this) { render() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOfflineReadinessBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.backButton.setOnClickListener { finish() }
    }

    override fun onResume() {
        super.onResume()
        render() // settings may have changed while we were away
    }

    private fun render() {
        val checks = ArrayList<Check>()

        val play = SystemChecks.playServicesOk(this)
        checks.add(
            Check(play, R.string.check_play, if (play) R.string.check_play_ok else R.string.check_play_bad)
        )

        val granted = NearbyPermissions.allGranted(this)
        checks.add(
            Check(
                granted, R.string.check_perm,
                if (granted) R.string.check_perm_ok else R.string.check_perm_bad,
                R.string.btn_grant, { permissions.request() }
            )
        )

        val bluetooth = SystemChecks.isBluetoothOn(this)
        checks.add(
            Check(
                bluetooth, R.string.check_bt, if (bluetooth) R.string.check_on else R.string.check_off,
                R.string.btn_settings, { openSettings(Settings.ACTION_BLUETOOTH_SETTINGS) }
            )
        )

        val wifi = SystemChecks.isWifiOn(this)
        checks.add(
            Check(
                wifi, R.string.check_wifi, if (wifi) R.string.check_on else R.string.check_off,
                R.string.btn_settings, { openSettings(Settings.ACTION_WIFI_SETTINGS) }
            )
        )

        if (SystemChecks.needsLocation()) {
            val location = SystemChecks.isLocationOn(this)
            checks.add(
                Check(
                    location, R.string.check_location,
                    if (location) R.string.check_on else R.string.check_off,
                    R.string.btn_settings, { openSettings(Settings.ACTION_LOCATION_SOURCE_SETTINGS) }
                )
            )
        }

        checks.add(
            Check(true, R.string.check_internet, R.string.check_internet_ok, countsAsProblem = false)
        )

        val problems = checks.count { !it.ok && it.countsAsProblem }
        binding.readySummary.text =
            if (problems == 0) getString(R.string.ready_ok) else getString(R.string.ready_fix_format, problems)
        binding.readySummary.setTextColor(
            ContextCompat.getColor(this, if (problems == 0) R.color.success else R.color.warning)
        )

        binding.checkList.removeAllViews()
        for (check in checks) {
            val row = ItemCheckBinding.inflate(layoutInflater, binding.checkList, false)
            row.checkIcon.text = if (check.ok) "✅" else "⚠️"
            row.checkTitle.setText(check.title)
            row.checkDetail.setText(check.detail)
            val label = check.actionLabel
            val action = check.action
            if (!check.ok && label != null && action != null) {
                row.checkAction.setText(label)
                row.checkAction.visibility = View.VISIBLE
                row.checkAction.setOnClickListener { action() }
            }
            binding.checkList.addView(row.root)
        }
    }

    private fun openSettings(action: String) {
        try {
            startActivity(Intent(action))
        } catch (e: ActivityNotFoundException) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }
}
