package com.airgesture.app.ui

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.airgesture.app.R
import com.airgesture.app.databinding.ActivityNearbyListBinding
import com.airgesture.app.net.ConnectionManager
import com.airgesture.app.net.ConnectionManager.Status
import com.airgesture.app.net.NearbyPermissionRequester

/** Alternative to QR: lists phones that are showing a QR code nearby; tap one to connect. */
class NearbyListActivity : AppCompatActivity(), ConnectionManager.Listener {

    private lateinit var binding: ActivityNearbyListBinding
    private lateinit var manager: ConnectionManager
    private lateinit var adapter: DevicesAdapter
    private var finished = false

    private val permissions = NearbyPermissionRequester(this) { granted ->
        if (granted) {
            manager.clearProblem()
            manager.startNearbySearch()
            render(manager.state)
        } else {
            binding.statusText.setText(R.string.perm_nearby_denied)
            binding.waitProgress.visibility = View.GONE
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNearbyListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        manager = ConnectionManager.get(this)

        adapter = DevicesAdapter { manager.connectTo(it) }
        binding.deviceList.layoutManager = LinearLayoutManager(this)
        binding.deviceList.adapter = adapter

        binding.backButton.setOnClickListener { finish() }
        binding.requestPanel.acceptButton.setOnClickListener { manager.accept() }
        binding.requestPanel.rejectButton.setOnClickListener { manager.reject() }

        permissions.request()
    }

    override fun onStart() {
        super.onStart()
        manager.addListener(this)
        val warning = systemWarning(this)
        binding.warningBanner.visibility = if (warning != null) View.VISIBLE else View.GONE
        warning?.let { binding.warningBanner.text = it }
        render(manager.state)
    }

    override fun onStop() {
        manager.removeListener(this)
        super.onStop()
    }

    override fun onDestroy() {
        if (!isChangingConfigurations && manager.state.status != Status.CONNECTED &&
            manager.state.status != Status.RECONNECTING
        ) {
            manager.cancelPairing()
        }
        super.onDestroy()
    }

    override fun onStateChanged(state: ConnectionManager.State) = render(state)

    private fun render(state: ConnectionManager.State) {
        adapter.submitList(state.devices)
        val listing = state.status == Status.DISCOVERING
        binding.emptyText.visibility = if (listing && state.devices.isEmpty()) View.VISIBLE else View.GONE
        binding.deviceList.visibility = if (listing) View.VISIBLE else View.GONE
        binding.waitProgress.visibility =
            if (state.status == Status.IDLE || state.status == Status.CONNECTED) View.GONE else View.VISIBLE

        val pending = state.pending
        val showRequest = state.status == Status.CONFIRMING && pending != null
        binding.requestPanel.root.visibility = if (showRequest) View.VISIBLE else View.GONE
        if (showRequest && pending != null) {
            binding.requestPanel.requestPeerText.text = getString(R.string.req_peer_client_format, pending.peerName)
            binding.requestPanel.requestCodeText.text = pending.code
        }

        val problemRes = state.problem.messageRes()
        binding.statusText.text = when {
            problemRes != null && state.status == Status.IDLE -> getString(problemRes)
            state.status == Status.DISCOVERING -> getString(R.string.nearby_searching)
            state.status == Status.REQUESTING -> getString(R.string.scan_connecting_format, state.peerName ?: "")
            state.status == Status.CONFIRMING -> getString(R.string.nearby_confirm_hint)
            else -> binding.statusText.text
        }

        if (state.status == Status.CONNECTED && !finished) {
            finished = true
            Toast.makeText(
                this, getString(R.string.toast_connected_format, state.peerName ?: ""), Toast.LENGTH_SHORT
            ).show()
            finish()
        }
    }
}
