package com.airgesture.app.files

import java.util.Locale

/** Human-readable sizes using 1024-based units ("1.5 KB", "24.5 MB"). */
object SizeFormatter {
    private val UNITS = arrayOf("B", "KB", "MB", "GB", "TB")

    fun format(bytes: Long, locale: Locale = Locale.getDefault()): String {
        if (bytes < 0) return "?"
        if (bytes < 1024) return "$bytes B"
        var value = bytes.toDouble()
        var unit = 0
        while (value >= 1024.0 && unit < UNITS.lastIndex) {
            value /= 1024.0
            unit++
        }
        return String.format(locale, "%.1f %s", value, UNITS[unit])
    }
}
