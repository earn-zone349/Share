package com.airgesture.app.files

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.util.Size
import androidx.exifinterface.media.ExifInterface
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Loads small image / video thumbnails off the main thread, with an in-memory LRU cache. */
class ThumbnailLoader private constructor(context: Context) {

    private val appContext = context.applicationContext
    private val executor: ExecutorService = Executors.newFixedThreadPool(2)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val cache = object : LruCache<String, Bitmap>(CACHE_BYTES) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    private fun key(file: SharedFile, sizePx: Int) = "${file.uri}#$sizePx"

    fun cached(file: SharedFile, sizePx: Int): Bitmap? = cache.get(key(file, sizePx))

    /** [onLoaded] runs on the main thread; null means "no thumbnail, show the type icon". */
    fun load(file: SharedFile, sizePx: Int, onLoaded: (Bitmap?) -> Unit) {
        cached(file, sizePx)?.let {
            onLoaded(it)
            return
        }
        if (file.category != FileCategory.IMAGE && file.category != FileCategory.VIDEO) {
            onLoaded(null)
            return
        }
        executor.execute {
            val bitmap = try {
                when (file.category) {
                    FileCategory.IMAGE -> decodeImage(file.uri, sizePx)
                    FileCategory.VIDEO -> decodeVideo(file.uri, sizePx)
                    else -> null
                }
            } catch (e: Throwable) {
                null
            }
            if (bitmap != null) cache.put(key(file, sizePx), bitmap)
            mainHandler.post { onLoaded(bitmap) }
        }
    }

    private fun decodeImage(uri: Uri, target: Int): Bitmap? {
        val resolver = appContext.contentResolver

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        while (min(bounds.outWidth, bounds.outHeight) / (sample * 2) >= target) sample *= 2

        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        val bitmap = resolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, options)
        } ?: return null

        val orientation = try {
            resolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                )
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }
        return applyOrientation(bitmap, orientation)
    }

    private fun applyOrientation(bitmap: Bitmap, orientation: Int): Bitmap {
        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> {
                m.postRotate(90f)
                m.postScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_TRANSVERSE -> {
                m.postRotate(-90f)
                m.postScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(-90f)
            else -> return bitmap
        }
        val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, m, true)
        if (rotated != bitmap) bitmap.recycle()
        return rotated
    }

    private fun decodeVideo(uri: Uri, target: Int): Bitmap? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                return appContext.contentResolver.loadThumbnail(uri, Size(target, target), null)
            } catch (e: Exception) {
                // fall back to the retriever below
            }
        }
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(appContext, uri)
            retriever.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?.let { scaleDown(it, target) }
        } catch (e: Exception) {
            null
        } finally {
            try {
                retriever.release()
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    private fun scaleDown(bitmap: Bitmap, target: Int): Bitmap {
        val longest = max(bitmap.width, bitmap.height)
        if (longest <= target) return bitmap
        val factor = target.toFloat() / longest
        return Bitmap.createScaledBitmap(
            bitmap,
            (bitmap.width * factor).roundToInt().coerceAtLeast(1),
            (bitmap.height * factor).roundToInt().coerceAtLeast(1),
            true
        )
    }

    companion object {
        private const val CACHE_BYTES = 24 * 1024 * 1024

        @Volatile
        private var instance: ThumbnailLoader? = null

        fun get(context: Context): ThumbnailLoader =
            instance ?: synchronized(this) {
                instance ?: ThumbnailLoader(context).also { instance = it }
            }
    }
}
