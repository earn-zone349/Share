package com.airgesture.app.net

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class RecentDevice(val name: String, val role: String, val lastConnectedMs: Long)

/** Remembers the last few phones this one connected to (name, role, time). */
class DeviceHistoryStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("device_history", Context.MODE_PRIVATE)

    fun load(): List<RecentDevice> {
        val raw = prefs.getString(KEY, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).map {
                val o = array.getJSONObject(it)
                RecentDevice(o.getString("name"), o.getString("role"), o.getLong("time"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun add(device: RecentDevice) {
        val updated = (listOf(device) + load().filter { it.name != device.name }).take(MAX)
        val array = JSONArray()
        for (d in updated) {
            array.put(
                JSONObject().put("name", d.name).put("role", d.role).put("time", d.lastConnectedMs)
            )
        }
        prefs.edit().putString(KEY, array.toString()).apply()
    }

    fun clear() {
        prefs.edit().remove(KEY).apply()
    }

    private companion object {
        const val KEY = "recent"
        const val MAX = 10
    }
}
