package com.airgesture.app.net

import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import java.nio.ByteBuffer
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Owns the one phone-to-phone link (Google Nearby Connections, P2P_POINT_TO_POINT, no internet).
 *
 * Pairing:   the HOST advertises, the CLIENT discovers. Either scans the host's QR code (the QR carries
 *            the session id, so the client only connects to that exact phone) or picks it from a list.
 *            The host always approves, and both phones can compare a 4-digit code.
 * Recovery:  if the link drops without a goodbye, both sides search again for up to a minute and
 *            reconnect automatically (same session, same peer, no new approval needed).
 * Keep-alive: a small ping/pong every few seconds detects dead links and measures round-trip time.
 *
 * All state changes happen on the main thread; screens listen via [Listener].
 */
class ConnectionManager private constructor(context: Context) {

    enum class Role { HOST, CLIENT }
    enum class Status { IDLE, ADVERTISING, DISCOVERING, REQUESTING, CONFIRMING, CONNECTED, RECONNECTING }
    enum class Problem { NONE, START_FAILED, CONNECT_FAILED, REJECTED, LOST, TIMEOUT }

    private enum class Mode { NONE, HOSTING, QR, LIST }

    data class Pending(
        val endpointId: String,
        val peerName: String,
        val code: String,
        val incoming: Boolean
    )

    data class Device(val endpointId: String, val name: String, val sessionId: String)

    data class State(
        val status: Status = Status.IDLE,
        val role: Role? = null,
        val sessionId: String? = null,
        val peerName: String? = null,
        val pending: Pending? = null,
        val devices: List<Device> = emptyList(),
        val problem: Problem = Problem.NONE,
        val attempt: Int = 0,
        val maxAttempts: Int = MAX_ATTEMPTS,
        val rttMs: Long = -1L,
        val connectedAtMs: Long = 0L
    )

    fun interface Listener {
        fun onStateChanged(state: State)
    }

    private class Session(
        val role: Role,
        val sessionId: String,
        val peerName: String,
        val peerDeviceId: String?
    )

    private val appContext = context.applicationContext
    private val client: ConnectionsClient = Nearby.getConnectionsClient(appContext)
    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<Listener>()
    private val history = DeviceHistoryStore(appContext)
    private val deviceName: String = resolveDeviceName()
    private val deviceId: String = loadOrCreateDeviceId()

    @Volatile
    var state: State = State()
        private set

    private var mode = Mode.NONE
    private var role: Role? = null
    private var sessionId: String? = null
    private var autoAcceptOutgoing = false
    private var connectedEndpoint: String? = null
    private var requestInFlight = false
    private var peerDeviceId: String? = null
    private var candidatePeerDeviceId: String? = null
    private var recovering = false
    private var recoveryAttempts = 0
    private var lastRecoveryEndpoint: String? = null
    private var userDisconnecting = false
    private var peerSaidBye = false
    private var lastPongAt = 0L
    private var lastSession: Session? = null

    // ------------------------------------------------------------------ public API

    fun addListener(listener: Listener) {
        listeners.addIfAbsent(listener)
    }

    fun removeListener(listener: Listener) {
        listeners.remove(listener)
    }

    val localName: String get() = deviceName

    /** QR text for the current hosting session, or null when not hosting. */
    fun qrPayload(): String? {
        val sid = sessionId ?: return null
        return if (role == Role.HOST) PairingProtocol.qrPayload(sid, deviceName) else null
    }

    fun canReconnect(): Boolean = state.status == Status.IDLE && lastSession != null

    private fun busy(): Boolean =
        state.status == Status.CONNECTED || state.status == Status.RECONNECTING

    /** Start advertising. Calling it again while already hosting keeps the same QR code. */
    fun startHosting() {
        if (busy()) return
        if (state.status == Status.ADVERTISING && role == Role.HOST) return
        resetNearby()
        val sid = PairingProtocol.newSessionId()
        sessionId = sid
        role = Role.HOST
        mode = Mode.HOSTING
        peerDeviceId = null
        candidatePeerDeviceId = null
        update { State(status = Status.ADVERTISING, role = Role.HOST, sessionId = sid) }
        startAdvertising(sid)
    }

    /** Client side of QR pairing: find the phone with this session id and connect to it. */
    fun startQrConnect(sid: String) {
        if (busy()) return
        resetNearby()
        sessionId = sid
        role = Role.CLIENT
        mode = Mode.QR
        autoAcceptOutgoing = true
        update { State(status = Status.DISCOVERING, role = Role.CLIENT, sessionId = sid) }
        startDiscovery()
        scheduleRequestTimeout()
    }

    /** Client side without QR: list every phone that is hosting nearby. */
    fun startNearbySearch() {
        if (busy()) return
        if (state.status == Status.DISCOVERING && mode == Mode.LIST) return
        resetNearby()
        sessionId = null
        role = Role.CLIENT
        mode = Mode.LIST
        autoAcceptOutgoing = false
        update { State(status = Status.DISCOVERING, role = Role.CLIENT) }
        startDiscovery()
    }

    fun connectTo(device: Device) {
        if (mode != Mode.LIST || busy()) return
        sessionId = device.sessionId
        update { it.copy(status = Status.REQUESTING, peerName = device.name, sessionId = device.sessionId) }
        requestRemote(device.endpointId)
        scheduleRequestTimeout()
    }

    /** User pressed Accept on a pending request (either side). */
    fun accept() {
        val p = state.pending ?: return
        acceptNow(p.endpointId, p.peerName)
        update { it.copy(pending = null, status = Status.REQUESTING) }
    }

    /** User pressed Reject on a pending request. */
    fun reject() {
        val p = state.pending ?: return
        client.rejectConnection(p.endpointId)
        if (role == Role.HOST) {
            update { it.copy(pending = null, status = Status.ADVERTISING, peerName = null) }
        } else {
            resetNearby()
            clearSession()
            update { State() }
        }
    }

    /** Leave any pairing step that is still in progress (does nothing when connected). */
    fun cancelPairing() {
        when (state.status) {
            Status.ADVERTISING, Status.DISCOVERING, Status.REQUESTING, Status.CONFIRMING -> {
                state.pending?.let { client.rejectConnection(it.endpointId) }
                resetNearby()
                clearSession()
                update { State() }
            }
            else -> Unit
        }
    }

    /** User chose to disconnect. Tells the other phone so it does not try to reconnect. */
    fun disconnect() {
        val id = connectedEndpoint
        userDisconnecting = true
        recovering = false
        main.removeCallbacks(recoveryTimeout)
        stopKeepAlive()
        connectedEndpoint = null
        if (id != null) {
            client.sendPayload(id, Payload.fromBytes(byteArrayOf(MSG_BYE)))
            main.postDelayed({
                client.disconnectFromEndpoint(id)
                if (state.status == Status.IDLE) resetNearby()
            }, BYE_DELAY_MS)
        } else {
            resetNearby()
        }
        lastSession = null
        clearSession()
        update { State() }
    }

    /** Manual reconnect after the automatic window ran out. */
    fun reconnectNow() {
        if (canReconnect()) beginRecovery()
    }

    fun sendPing() {
        val id = connectedEndpoint ?: return
        val bytes = ByteBuffer.allocate(9).put(MSG_PING).putLong(SystemClock.elapsedRealtime()).array()
        client.sendPayload(id, Payload.fromBytes(bytes))
    }

    fun clearProblem() {
        if (state.problem != Problem.NONE) update { it.copy(problem = Problem.NONE) }
    }

    // ------------------------------------------------------------------ Nearby: start / stop

    private fun startAdvertising(sid: String) {
        val options = AdvertisingOptions.Builder().setStrategy(Strategy.P2P_POINT_TO_POINT).build()
        client.startAdvertising(
            PairingProtocol.hostEndpointName(sid, deviceName),
            PairingProtocol.SERVICE_ID,
            lifecycle,
            options
        ).addOnFailureListener { e -> onStartFailed(e) }
    }

    private fun startDiscovery() {
        val options = DiscoveryOptions.Builder().setStrategy(Strategy.P2P_POINT_TO_POINT).build()
        client.startDiscovery(PairingProtocol.SERVICE_ID, endpointCallback, options)
            .addOnFailureListener { e -> onStartFailed(e) }
    }

    private fun onStartFailed(e: Exception) {
        val code = (e as? ApiException)?.statusCode
        if (code == ConnectionsStatusCodes.STATUS_ALREADY_ADVERTISING ||
            code == ConnectionsStatusCodes.STATUS_ALREADY_DISCOVERING
        ) return // already doing what we asked for
        if (recovering) return // the recovery window keeps trying / times out on its own
        fail(Problem.START_FAILED)
    }

    private fun requestRemote(endpointId: String) {
        val sid = sessionId ?: return
        requestInFlight = true
        client.requestConnection(
            PairingProtocol.clientRequestName(sid, deviceId, deviceName),
            endpointId,
            lifecycle
        ).addOnFailureListener {
            requestInFlight = false
            if (recovering) scheduleRecoveryRetry() else fail(Problem.CONNECT_FAILED)
        }
    }

    private fun acceptNow(endpointId: String, peer: String) {
        client.acceptConnection(endpointId, payloadCallback)
            .addOnFailureListener { if (!recovering) fail(Problem.CONNECT_FAILED) }
        update { it.copy(peerName = peer) }
    }

    /** Stops advertising, discovery and any half-open connection. Keeps the session fields. */
    private fun resetNearby() {
        main.removeCallbacks(requestTimeout)
        main.removeCallbacks(recoveryTimeout)
        requestInFlight = false
        try {
            client.stopAdvertising()
            client.stopDiscovery()
            client.stopAllEndpoints()
        } catch (e: Exception) {
            // nothing running
        }
    }

    private fun clearSession() {
        mode = Mode.NONE
        role = null
        sessionId = null
        autoAcceptOutgoing = false
        candidatePeerDeviceId = null
        recovering = false
        recoveryAttempts = 0
        lastRecoveryEndpoint = null
    }

    private fun fail(problem: Problem) {
        resetNearby()
        clearSession()
        update { State(problem = problem) }
    }

    // ------------------------------------------------------------------ Nearby callbacks

    private val endpointCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            val host = PairingProtocol.parseHost(info.endpointName) ?: return
            when {
                recovering && role == Role.CLIENT -> {
                    if (host.sessionId == sessionId && !requestInFlight &&
                        recoveryAttempts < MAX_ATTEMPTS
                    ) {
                        recoveryAttempts++
                        lastRecoveryEndpoint = endpointId
                        val attempt = recoveryAttempts
                        update { it.copy(attempt = attempt) }
                        requestRemote(endpointId)
                    }
                }
                mode == Mode.QR -> {
                    if (host.sessionId == sessionId && !requestInFlight) {
                        update { it.copy(status = Status.REQUESTING, peerName = host.deviceName) }
                        requestRemote(endpointId)
                    }
                }
                mode == Mode.LIST -> {
                    val device = Device(endpointId, host.deviceName, host.sessionId)
                    update { s -> s.copy(devices = s.devices.filter { it.endpointId != endpointId } + device) }
                }
            }
        }

        override fun onEndpointLost(endpointId: String) {
            if (mode == Mode.LIST) {
                update { s -> s.copy(devices = s.devices.filter { it.endpointId != endpointId }) }
            }
        }
    }

    private val lifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) =
            handleInitiated(endpointId, info)

        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) =
            handleResult(endpointId, result)

        override fun onDisconnected(endpointId: String) = handleDisconnected(endpointId)
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            payload.asBytes()?.let { handleControl(endpointId, it) }
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {
            // file payloads arrive in Phase 5
        }
    }

    private fun handleInitiated(endpointId: String, info: ConnectionInfo) {
        val sid = sessionId
        if (sid == null) {
            client.rejectConnection(endpointId)
            return
        }
        val incoming = info.isIncomingConnection
        val peer: String
        if (incoming) {
            val c = PairingProtocol.parseClient(info.endpointName)
            val busyWithOther = state.pending?.let { it.endpointId != endpointId } == true
            if (c == null || c.sessionId != sid || busyWithOther ||
                (recovering && c.deviceId != peerDeviceId)
            ) {
                client.rejectConnection(endpointId)
                return
            }
            peer = c.deviceName
            candidatePeerDeviceId = c.deviceId
        } else {
            val h = PairingProtocol.parseHost(info.endpointName)
            if (h == null || h.sessionId != sid) {
                client.rejectConnection(endpointId)
                return
            }
            peer = h.deviceName
        }
        requestInFlight = false

        val auto = recovering || (!incoming && autoAcceptOutgoing)
        if (auto) {
            acceptNow(endpointId, peer)
        } else {
            update {
                it.copy(
                    status = Status.CONFIRMING,
                    peerName = peer,
                    pending = Pending(endpointId, peer, info.authenticationDigits, incoming)
                )
            }
        }
    }

    private fun handleResult(endpointId: String, result: ConnectionResolution) {
        if (result.status.isSuccess) {
            onConnected(endpointId)
            return
        }
        requestInFlight = false
        val rejected = result.status.statusCode == ConnectionsStatusCodes.STATUS_CONNECTION_REJECTED
        when {
            recovering -> scheduleRecoveryRetry()
            role == Role.HOST -> {
                update {
                    it.copy(
                        status = Status.ADVERTISING,
                        pending = null,
                        peerName = null,
                        problem = if (rejected) Problem.REJECTED else Problem.CONNECT_FAILED
                    )
                }
                sessionId?.let { startAdvertising(it) } // no-op if it is still running
            }
            else -> fail(if (rejected) Problem.REJECTED else Problem.CONNECT_FAILED)
        }
    }

    private fun onConnected(endpointId: String) {
        main.removeCallbacks(requestTimeout)
        main.removeCallbacks(recoveryTimeout)
        client.stopAdvertising()
        client.stopDiscovery()

        val currentRole = role ?: Role.CLIENT
        val sid = sessionId.orEmpty()
        val peer = state.peerName ?: lastSession?.peerName ?: "?"
        if (currentRole == Role.HOST && candidatePeerDeviceId != null) {
            peerDeviceId = candidatePeerDeviceId
        }
        val wasRecovering = recovering
        connectedEndpoint = endpointId
        lastSession = Session(currentRole, sid, peer, peerDeviceId)
        if (!wasRecovering) {
            history.add(RecentDevice(peer, currentRole.name, System.currentTimeMillis()))
        }
        recovering = false
        recoveryAttempts = 0
        lastRecoveryEndpoint = null
        userDisconnecting = false
        peerSaidBye = false
        requestInFlight = false
        lastPongAt = SystemClock.elapsedRealtime()

        update {
            State(
                status = Status.CONNECTED,
                role = currentRole,
                sessionId = sid,
                peerName = peer,
                connectedAtMs = System.currentTimeMillis()
            )
        }
        startKeepAlive()
        sendPing()
    }

    private fun handleDisconnected(endpointId: String) {
        if (endpointId == connectedEndpoint) {
            connectedEndpoint = null
            stopKeepAlive()
            if (userDisconnecting || peerSaidBye) {
                lastSession = null
                resetNearby()
                clearSession()
                update { State() }
            } else {
                beginRecovery()
            }
            return
        }
        requestInFlight = false
        val p = state.pending
        if (p != null && p.endpointId == endpointId) {
            if (role == Role.HOST) {
                update { it.copy(status = Status.ADVERTISING, pending = null, peerName = null) }
            } else {
                fail(Problem.CONNECT_FAILED)
            }
        }
    }

    // ------------------------------------------------------------------ recovery

    private fun beginRecovery() {
        val session = lastSession
        if (session == null) {
            resetNearby()
            clearSession()
            update { State() }
            return
        }
        resetNearby()
        recovering = true
        recoveryAttempts = 0
        lastRecoveryEndpoint = null
        role = session.role
        sessionId = session.sessionId
        peerDeviceId = session.peerDeviceId
        mode = Mode.NONE
        update {
            State(
                status = Status.RECONNECTING,
                role = session.role,
                sessionId = session.sessionId,
                peerName = session.peerName
            )
        }
        if (session.role == Role.HOST) startAdvertising(session.sessionId) else startDiscovery()
        main.postDelayed(recoveryTimeout, RECOVERY_WINDOW_MS)
    }

    private fun scheduleRecoveryRetry() {
        main.postDelayed({
            if (!recovering || requestInFlight) return@postDelayed
            if (role == Role.HOST) {
                sessionId?.let { startAdvertising(it) }
            } else {
                val endpoint = lastRecoveryEndpoint
                if (endpoint != null && recoveryAttempts < MAX_ATTEMPTS) {
                    recoveryAttempts++
                    val attempt = recoveryAttempts
                    update { it.copy(attempt = attempt) }
                    requestRemote(endpoint)
                }
            }
        }, RETRY_DELAY_MS)
    }

    private val recoveryTimeout = Runnable {
        if (recovering) {
            resetNearby()
            clearSession()
            update { State(problem = Problem.LOST) } // lastSession is kept so "Reconnect" is offered
        }
    }

    private val requestTimeout = Runnable {
        val s = state.status
        if (s == Status.DISCOVERING || s == Status.REQUESTING || s == Status.CONFIRMING) {
            fail(Problem.TIMEOUT)
        }
    }

    private fun scheduleRequestTimeout() {
        main.removeCallbacks(requestTimeout)
        main.postDelayed(requestTimeout, REQUEST_TIMEOUT_MS)
    }

    // ------------------------------------------------------------------ keep-alive + control messages

    private val keepAlive = object : Runnable {
        override fun run() {
            val id = connectedEndpoint ?: return
            if (SystemClock.elapsedRealtime() - lastPongAt > DEAD_AFTER_MS) {
                client.disconnectFromEndpoint(id)
                handleDisconnected(id) // a local disconnect does not call onDisconnected
                return
            }
            sendPing()
            main.postDelayed(this, KEEPALIVE_MS)
        }
    }

    private fun startKeepAlive() {
        main.removeCallbacks(keepAlive)
        main.postDelayed(keepAlive, KEEPALIVE_MS)
    }

    private fun stopKeepAlive() {
        main.removeCallbacks(keepAlive)
    }

    private fun handleControl(endpointId: String, bytes: ByteArray) {
        if (bytes.isEmpty()) return
        when (bytes[0]) {
            MSG_PING -> {
                lastPongAt = SystemClock.elapsedRealtime()
                if (bytes.size >= 9) {
                    val pong = bytes.copyOf()
                    pong[0] = MSG_PONG
                    client.sendPayload(endpointId, Payload.fromBytes(pong))
                }
            }
            MSG_PONG -> {
                if (bytes.size >= 9) {
                    val sentAt = ByteBuffer.wrap(bytes, 1, 8).long
                    val now = SystemClock.elapsedRealtime()
                    lastPongAt = now
                    val rtt = (now - sentAt).coerceAtLeast(0L)
                    update { it.copy(rttMs = rtt) }
                }
            }
            MSG_BYE -> {
                peerSaidBye = true
                main.postDelayed({
                    if (connectedEndpoint == endpointId) {
                        client.disconnectFromEndpoint(endpointId)
                        handleDisconnected(endpointId)
                    }
                }, BYE_GRACE_MS)
            }
        }
    }

    // ------------------------------------------------------------------ helpers

    private fun update(transform: (State) -> State) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            applyUpdate(transform)
        } else {
            main.post { applyUpdate(transform) }
        }
    }

    private fun applyUpdate(transform: (State) -> State) {
        val next = transform(state)
        state = next
        for (l in listeners) l.onStateChanged(next)
    }

    private fun resolveDeviceName(): String {
        val configured = try {
            Settings.Global.getString(appContext.contentResolver, "device_name")
        } catch (e: Exception) {
            null
        }
        return PairingProtocol.cleanName(configured?.takeIf { it.isNotBlank() } ?: Build.MODEL ?: "Android")
    }

    private fun loadOrCreateDeviceId(): String {
        val prefs = appContext.getSharedPreferences("pairing", Context.MODE_PRIVATE)
        val existing = prefs.getString("device_id", null)
        if (existing != null) return existing
        val created = PairingProtocol.newDeviceId()
        prefs.edit().putString("device_id", created).apply()
        return created
    }

    companion object {
        const val MAX_ATTEMPTS = 5

        private const val MSG_PING: Byte = 1
        private const val MSG_PONG: Byte = 2
        private const val MSG_BYE: Byte = 3

        private const val RECOVERY_WINDOW_MS = 60_000L
        private const val RETRY_DELAY_MS = 2_000L
        private const val REQUEST_TIMEOUT_MS = 60_000L
        private const val KEEPALIVE_MS = 4_000L
        private const val DEAD_AFTER_MS = 14_000L
        private const val BYE_DELAY_MS = 350L
        private const val BYE_GRACE_MS = 1_500L

        @Volatile
        private var instance: ConnectionManager? = null

        fun get(context: Context): ConnectionManager =
            instance ?: synchronized(this) {
                instance ?: ConnectionManager(context).also { instance = it }
            }
    }
}
