package com.airgesture.app.ui

import android.content.Intent
import android.os.Bundle
import android.text.format.DateUtils
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.airgesture.app.R
import com.airgesture.app.databinding.ActivityConnectedDevicesBinding
import com.airgesture.app.databinding.ItemRecentBinding
import com.airgesture.app.net.ConnectionManager
import com.airgesture.app.net.ConnectionManager.Status
import com.airgesture.app.net.DeviceHistoryStore

/** Hub: current connection, ways to pair, test / disconnect, recent devices. */
class ConnectedDevicesActivity : AppCompatActivity(), ConnectionManager.Listener {

    private lateinit var binding: ActivityConnectedDevicesBinding
    private lateinit var manager: ConnectionManager
    private lateinit var history: DeviceHistoryStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityConnectedDevicesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        manager = ConnectionManager.get(this)
        history = DeviceHistoryStore(this)

        binding.backButton.setOnClickListener { finish() }
        binding.hostButton.setOnClickListener { startActivity(Intent(this, HostPairingActivity::class.java)) }
        binding.scanButton.setOnClickListener { startActivity(Intent(this, ScanPairingActivity::class.java)) }
        binding.nearbyButton.setOnClickListener { startActivity(Intent(this, NearbyListActivity::class.java)) }
        binding.reconnectButton.setOnClickListener { manager.reconnectNow() }
        binding.testButton.setOnClickListener { manager.sendPing() }
        binding.disconnectButton.setOnClickListener { manager.disconnect() }
        binding.cancelButton.setOnClickListener {
            if (manager.state.status == Status.RECONNECTING) manager.disconnect() else manager.cancelPairing()
        }
    }

    override fun onStart() {
        super.onStart()
        manager.addListener(this)
        render(manager.state)
        renderRecent()
    }

    override fun onStop() {
        manager.removeListener(this)
        super.onStop()
    }

    override fun onStateChanged(state: ConnectionManager.State) = render(state)

    private fun render(state: ConnectionManager.State) {
        val connected = state.status == Status.CONNECTED
        val idle = state.status == Status.IDLE
        val peer = state.peerName ?: ""

        when (state.status) {
            Status.IDLE -> {
                binding.statusEmoji.text = "📴"
                binding.statusTitle.setText(R.string.conn_status_idle_title)
                binding.statusSubtitle.setText(R.string.conn_status_idle_sub)
            }
            Status.CONNECTED -> {
                binding.statusEmoji.text = "✅"
                binding.statusTitle.text = getString(R.string.conn_connected_title, peer)
                val roleText = getString(
                    if (state.role == ConnectionManager.Role.HOST) R.string.conn_role_host
                    else R.string.conn_role_client
                )
                binding.statusSubtitle.text =
                    if (state.rttMs >= 0) getString(R.string.conn_connected_sub_format, roleText, state.rttMs.toInt())
                    else getString(R.string.conn_connected_sub_checking, roleText)
            }
            Status.RECONNECTING -> {
                binding.statusEmoji.text = "🔄"
                binding.statusTitle.text = getString(R.string.conn_reconnecting_title, peer)
                binding.statusSubtitle.text =
                    getString(R.string.conn_reconnecting_sub, state.attempt, state.maxAttempts)
            }
            else -> {
                binding.statusEmoji.text = "⏳"
                binding.statusTitle.setText(R.string.conn_pairing_title)
                binding.statusSubtitle.setText(R.string.conn_pairing_sub)
            }
        }

        binding.statusProgress.visibility =
            if (idle || connected) View.GONE else View.VISIBLE
        binding.idleActions.visibility = if (idle) View.VISIBLE else View.GONE
        binding.connectedActions.visibility = if (connected) View.VISIBLE else View.GONE
        binding.cancelButton.visibility = if (idle || connected) View.GONE else View.VISIBLE
        binding.cancelButton.setText(
            if (state.status == Status.RECONNECTING) R.string.btn_stop_reconnecting else R.string.btn_cancel_pairing
        )

        val canReconnect = manager.canReconnect()
        binding.reconnectButton.visibility = if (canReconnect) View.VISIBLE else View.GONE
        if (canReconnect) {
            binding.reconnectButton.text = getString(R.string.btn_reconnect_format, lastPeerName())
        }

        val problemRes = state.problem.messageRes()
        if (problemRes != null && idle) {
            binding.problemText.setText(problemRes)
            binding.problemText.visibility = View.VISIBLE
        } else {
            binding.problemText.visibility = View.GONE
        }
    }

    private fun lastPeerName(): String = history.load().firstOrNull()?.name ?: ""

    private fun renderRecent() {
        val recent = history.load()
        binding.recentContainer.removeAllViews()
        binding.recentEmpty.visibility = if (recent.isEmpty()) View.VISIBLE else View.GONE
        val now = System.currentTimeMillis()
        for (device in recent) {
            val row = ItemRecentBinding.inflate(layoutInflater, binding.recentContainer, false)
            row.recentName.text = device.name
            val roleText = getString(
                if (device.role == ConnectionManager.Role.HOST.name) R.string.role_host_short
                else R.string.role_client_short
            )
            val whenText = DateUtils.getRelativeTimeSpanString(
                device.lastConnectedMs, now, DateUtils.MINUTE_IN_MILLIS
            )
            row.recentMeta.text = getString(R.string.conn_recent_sub, roleText, whenText.toString())
            binding.recentContainer.addView(row.root)
        }
    }
}
