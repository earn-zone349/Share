package com.airgesture.app.net

import java.net.URLDecoder
import java.net.URLEncoder
import java.security.SecureRandom
import java.util.Random

/**
 * Names and QR payloads used for pairing. Pure Kotlin (no Android classes) so it is unit-tested.
 *
 *  - Host advertises as     "AG1|<sessionId>|<deviceName>"
 *  - Client requests as     "AGC|<sessionId>|<deviceId>|<deviceName>"
 *  - QR code contains       "airgesture://pair?v=1&s=<sessionId>&n=<deviceName>"
 *
 * The session id in the QR code ties the scanning phone to exactly that advertising phone.
 */
object PairingProtocol {
    const val SERVICE_ID = "com.airgesture.app.p2p"

    private const val HOST_PREFIX = "AG1"
    private const val CLIENT_PREFIX = "AGC"
    private const val QR_PREFIX = "airgesture://pair?"
    private const val ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789" // no I, O, 0, 1
    private const val MAX_NAME = 24
    private val SESSION_REGEX = Regex("[A-HJ-NP-Z2-9]{8}")
    private val DEVICE_REGEX = Regex("[A-HJ-NP-Z2-9]{6}")

    data class HostInfo(val sessionId: String, val deviceName: String)
    data class ClientInfo(val sessionId: String, val deviceId: String, val deviceName: String)
    data class QrInfo(val sessionId: String, val deviceName: String)

    fun newId(length: Int, random: Random = SecureRandom()): String =
        buildString { repeat(length) { append(ALPHABET[random.nextInt(ALPHABET.length)]) } }

    fun newSessionId(random: Random = SecureRandom()): String = newId(8, random)

    fun newDeviceId(random: Random = SecureRandom()): String = newId(6, random)

    /** Removes the separator and control characters, trims and shortens a device name. */
    fun cleanName(raw: String): String {
        val cleaned = raw.replace('|', '/').filter { !it.isISOControl() }.trim().take(MAX_NAME).trim()
        return cleaned.ifEmpty { "Android" }
    }

    fun hostEndpointName(sessionId: String, deviceName: String): String =
        "$HOST_PREFIX|$sessionId|${cleanName(deviceName)}"

    fun parseHost(endpointName: String): HostInfo? {
        val parts = endpointName.split('|', limit = 3)
        if (parts.size != 3 || parts[0] != HOST_PREFIX || !SESSION_REGEX.matches(parts[1])) return null
        return HostInfo(parts[1], parts[2])
    }

    fun clientRequestName(sessionId: String, deviceId: String, deviceName: String): String =
        "$CLIENT_PREFIX|$sessionId|$deviceId|${cleanName(deviceName)}"

    fun parseClient(endpointName: String): ClientInfo? {
        val parts = endpointName.split('|', limit = 4)
        if (parts.size != 4 || parts[0] != CLIENT_PREFIX) return null
        if (!SESSION_REGEX.matches(parts[1]) || !DEVICE_REGEX.matches(parts[2])) return null
        return ClientInfo(parts[1], parts[2], parts[3])
    }

    fun qrPayload(sessionId: String, deviceName: String): String =
        "${QR_PREFIX}v=1&s=$sessionId&n=${URLEncoder.encode(cleanName(deviceName), "UTF-8")}"

    fun parseQr(text: String): QrInfo? {
        if (!text.startsWith(QR_PREFIX)) return null
        val params = HashMap<String, String>()
        for (pair in text.removePrefix(QR_PREFIX).split('&')) {
            val eq = pair.indexOf('=')
            if (eq <= 0) continue
            val value = try {
                URLDecoder.decode(pair.substring(eq + 1), "UTF-8")
            } catch (e: Exception) {
                return null
            }
            params[pair.substring(0, eq)] = value
        }
        if (params["v"] != "1") return null
        val sessionId = params["s"] ?: return null
        if (!SESSION_REGEX.matches(sessionId)) return null
        return QrInfo(sessionId, cleanName(params["n"] ?: ""))
    }
}
