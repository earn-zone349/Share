package com.airgesture.app.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.AspectRatio
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.airgesture.app.R
import com.airgesture.app.databinding.ActivityScanPairingBinding
import com.airgesture.app.net.ConnectionManager
import com.airgesture.app.net.ConnectionManager.Status
import com.airgesture.app.net.NearbyPermissionRequester
import com.airgesture.app.net.PairingProtocol
import com.airgesture.app.net.QrAnalyzer
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Scans the host's QR code, then connects to exactly that phone (no list, no guessing). */
class ScanPairingActivity : AppCompatActivity(), ConnectionManager.Listener {

    private lateinit var binding: ActivityScanPairingBinding
    private lateinit var manager: ConnectionManager
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()

    private var analysis: ImageAnalysis? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var scanning = false
    private var finished = false

    private val permissions = NearbyPermissionRequester(this) { granted ->
        if (granted) startCamera() else showStatus(getString(R.string.perm_nearby_denied), retry = true)
    }

    private val cameraPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                binding.permissionPanel.root.visibility = View.GONE
                permissions.request()
            } else {
                binding.permissionPanel.root.visibility = View.VISIBLE
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScanPairingBinding.inflate(layoutInflater)
        setContentView(binding.root)
        manager = ConnectionManager.get(this)

        binding.backButton.setOnClickListener { finish() }
        binding.retryButton.setOnClickListener { restartScanning() }
        binding.permissionPanel.grantButton.setOnClickListener {
            cameraPermission.launch(Manifest.permission.CAMERA)
        }
        binding.permissionPanel.settingsButton.setOnClickListener {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.fromParts("package", packageName, null)
                }
            )
        }

        binding.statusText.setText(R.string.scan_hint)
        startFlow()
    }

    override fun onStart() {
        super.onStart()
        manager.addListener(this)
        val warning = systemWarning(this)
        binding.warningBanner.visibility = if (warning != null) View.VISIBLE else View.GONE
        warning?.let { binding.warningBanner.text = it }
        render(manager.state)
    }

    override fun onStop() {
        manager.removeListener(this)
        super.onStop()
    }

    override fun onDestroy() {
        analysis?.clearAnalyzer()
        cameraProvider?.unbindAll()
        executor.shutdown()
        if (!isChangingConfigurations && manager.state.status != Status.CONNECTED &&
            manager.state.status != Status.RECONNECTING
        ) {
            manager.cancelPairing()
        }
        super.onDestroy()
    }

    // ---------------------------------------------------------------- camera + QR

    private fun startFlow() {
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) permissions.request() else cameraPermission.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                cameraProvider = provider

                val preview = Preview.Builder()
                    .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                    .build()
                    .also { it.setSurfaceProvider(binding.previewView.surfaceProvider) }

                val useCase = ImageAnalysis.Builder()
                    .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis = useCase
                scanning = true
                useCase.setAnalyzer(executor, QrAnalyzer { text ->
                    runOnUiThread { onQrFound(text) }
                })

                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, useCase)
            } catch (e: Exception) {
                Log.e(TAG, "Camera start failed", e)
                showStatus(getString(R.string.err_camera), retry = false)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun onQrFound(text: String) {
        if (!scanning || finished || isDestroyed) return
        val info = PairingProtocol.parseQr(text)
        if (info == null) {
            binding.statusText.setText(R.string.scan_invalid)
            return
        }
        scanning = false
        analysis?.clearAnalyzer()
        manager.clearProblem()
        manager.startQrConnect(info.sessionId)
        showStatus(getString(R.string.scan_looking_format, info.deviceName), retry = false, busy = true)
    }

    private fun restartScanning() {
        manager.cancelPairing()
        binding.retryButton.visibility = View.GONE
        binding.statusText.setText(R.string.scan_hint)
        val useCase = analysis
        if (useCase != null) {
            scanning = true
            useCase.setAnalyzer(executor, QrAnalyzer { text -> runOnUiThread { onQrFound(text) } })
        } else {
            startFlow()
        }
    }

    // ---------------------------------------------------------------- state

    override fun onStateChanged(state: ConnectionManager.State) = render(state)

    private fun render(state: ConnectionManager.State) {
        val problemRes = state.problem.messageRes()
        when {
            state.status == Status.CONNECTED && !finished -> {
                finished = true
                Toast.makeText(
                    this, getString(R.string.toast_connected_format, state.peerName ?: ""), Toast.LENGTH_SHORT
                ).show()
                finish()
            }
            state.status == Status.IDLE && problemRes != null && !scanning ->
                showStatus(getString(problemRes), retry = true)
            state.status == Status.REQUESTING ->
                showStatus(getString(R.string.scan_connecting_format, state.peerName ?: ""), retry = false, busy = true)
            state.status == Status.CONFIRMING && state.pending != null ->
                showStatus(
                    getString(R.string.scan_confirm_format, state.pending.code), retry = false, busy = true
                )
        }
    }

    private fun showStatus(text: String, retry: Boolean, busy: Boolean = false) {
        binding.statusText.text = text
        binding.retryButton.visibility = if (retry) View.VISIBLE else View.GONE
        binding.waitProgress.visibility = if (busy) View.VISIBLE else View.GONE
    }

    private companion object {
        const val TAG = "ScanPairing"
    }
}
