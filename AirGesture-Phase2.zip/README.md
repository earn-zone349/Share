# AirGesture

Native Android (Kotlin, View-based UI), CameraX + MediaPipe HandLandmarker, fully on-device.

## Phase 1: Foundation
Home screen (dark, English / বাংলা), camera + permission handling, live hand tracking with landmark
overlay, Open Palm / Fist detection, left/right hand label, FPS + latency readout.

## Phase 2: Gesture Engine (this version)
- Grab -> Move -> Release state machine (`GestureEngine`, pure Kotlin, unit-tested)
- Cancel: hold the peace sign (index + middle finger), or the hand leaves the view for 2 s
- False-gesture protection: palm must be "armed" before a fist counts, every step needs a hold time,
  early release is ignored, cooldown after each cycle
- Hold-progress ring and a placeholder file token that follows your palm while grabbed
- Calibration (open palm, then fist) tunes finger thresholds to your hand and camera distance
- Gesture Settings: hold-time sliders, haptics, low-light warning, reset
- Low-light warning (frame brightness with hysteresis), haptic feedback on grab / release / cancel

Not yet: file selection, pairing, transfer (Phases 3-6). The token is a placeholder, real file preview comes later.

## How to use the Gesture Transfer screen
1. Open your palm until the ring fills -> **Ready**
2. Close your fist until the ring fills -> **Grabbed** (token appears)
3. Move your hand; open it and hold -> **Released**
4. Show the peace sign and hold -> **Cancelled**

## Build
`.github/workflows/build-apk.yml` downloads the MediaPipe model, runs the engine unit tests, builds a debug
APK and uploads it as the `AirGesture-debug-apk` artifact.
