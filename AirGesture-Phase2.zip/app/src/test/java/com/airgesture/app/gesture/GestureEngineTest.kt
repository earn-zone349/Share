package com.airgesture.app.gesture

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GestureEngineTest {

    private val aspect = 0.75f

    private fun GestureEngine.feed(
        t: Long, g: Gesture, x: Float = 0.5f, y: Float = 0.5f
    ): List<GestureEvent> =
        update(t, g, if (g == Gesture.NONE) null else x, if (g == Gesture.NONE) null else y, aspect)

    /** Drives the engine to GRABBED at t=1100 and returns the collected events. */
    private fun GestureEngine.grab(): List<GestureEvent> {
        val ev = ArrayList<GestureEvent>()
        ev += feed(0, Gesture.OPEN_PALM)
        ev += feed(600, Gesture.OPEN_PALM)   // READY
        ev += feed(700, Gesture.FIST)        // GRABBING
        ev += feed(1100, Gesture.FIST)       // GRABBED
        return ev
    }

    @Test
    fun fullGrabMoveReleaseCycle() {
        val e = GestureEngine()
        val ev = ArrayList<GestureEvent>(e.grab())
        assertEquals(Phase.GRABBED, e.snapshot.phase)
        ev += e.feed(1200, Gesture.FIST, x = 0.7f)
        assertEquals(Phase.MOVING, e.snapshot.phase)
        ev += e.feed(1700, Gesture.OPEN_PALM, x = 0.7f)
        assertEquals(Phase.RELEASING, e.snapshot.phase)
        ev += e.feed(2000, Gesture.OPEN_PALM, x = 0.7f)
        assertEquals(Phase.RELEASED, e.snapshot.phase)

        assertTrue(ev.contains(GestureEvent.Armed))
        assertTrue(ev.contains(GestureEvent.Grabbed))
        assertTrue(ev.contains(GestureEvent.MoveStarted))
        val released = ev.filterIsInstance<GestureEvent.Released>().single()
        assertEquals(900L, released.heldMs)
        assertTrue(released.movedDistance > 0.15f)
    }

    @Test
    fun briefOpenPalmNeverArms() {
        val e = GestureEngine()
        e.feed(0, Gesture.OPEN_PALM)
        e.feed(100, Gesture.FIST)
        assertEquals(Phase.IDLE, e.snapshot.phase)
    }

    @Test
    fun briefFistIsIgnored() {
        val e = GestureEngine()
        e.feed(0, Gesture.OPEN_PALM)
        e.feed(600, Gesture.OPEN_PALM)
        e.feed(700, Gesture.FIST)
        val ev = e.feed(800, Gesture.OPEN_PALM)
        assertEquals(Phase.READY, e.snapshot.phase)
        assertTrue(ev.none { it is GestureEvent.Grabbed })
    }

    @Test
    fun earlyReleaseIsIgnored() {
        val e = GestureEngine()
        e.grab()
        e.feed(1200, Gesture.OPEN_PALM) // only 100 ms after the grab
        assertEquals(Phase.GRABBED, e.snapshot.phase)
    }

    @Test
    fun peaceSignCancels() {
        val e = GestureEngine()
        e.grab()
        e.feed(1300, Gesture.PEACE)
        val ev = e.feed(1900, Gesture.PEACE)
        assertEquals(Phase.CANCELLED, e.snapshot.phase)
        assertEquals(GestureEvent.Cancelled(CancelReason.CANCEL_GESTURE), ev.single())
    }

    @Test
    fun handLostCancels() {
        val e = GestureEngine()
        e.grab()
        e.feed(1500, Gesture.NONE)
        assertEquals(Phase.GRABBED, e.snapshot.phase)
        val ev = e.feed(3300, Gesture.NONE) // lastSeen = 1100, 2200 ms later
        assertEquals(Phase.CANCELLED, e.snapshot.phase)
        assertEquals(GestureEvent.Cancelled(CancelReason.HAND_LOST), ev.single())
    }

    @Test
    fun cooldownThenIdle() {
        val e = GestureEngine()
        e.grab()
        e.feed(1300, Gesture.PEACE)
        e.feed(1900, Gesture.PEACE)
        e.feed(2500, Gesture.NONE)
        assertEquals(Phase.CANCELLED, e.snapshot.phase)
        e.feed(3200, Gesture.NONE)
        assertEquals(Phase.IDLE, e.snapshot.phase)
    }
}
