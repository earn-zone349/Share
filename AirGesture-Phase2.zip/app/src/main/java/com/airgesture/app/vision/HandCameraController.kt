package com.airgesture.app.vision

import android.util.Log
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.AspectRatio
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.airgesture.app.R
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Owns CameraX + the MediaPipe helper for one screen. Callbacks arrive on the main thread.
 * Camera permission must already be granted before [start] is called.
 */
class HandCameraController(
    private val activity: AppCompatActivity,
    private val previewView: PreviewView,
    private val listener: Listener
) : HandLandmarkerHelper.Listener {

    interface Listener {
        fun onFrame(frame: HandFrame)
        fun onCameraProblem(@StringRes messageRes: Int)
    }

    private val executor: ExecutorService = Executors.newSingleThreadExecutor()

    @Volatile
    private var helper: HandLandmarkerHelper? = null
    private var provider: ProcessCameraProvider? = null

    @Volatile
    private var lensFacing = CameraSelector.LENS_FACING_FRONT

    var isStarted = false
        private set

    fun start() {
        if (isStarted) return
        isStarted = true
        initHelper()
        startCamera()
    }

    fun switchCamera() {
        lensFacing =
            if (lensFacing == CameraSelector.LENS_FACING_FRONT) CameraSelector.LENS_FACING_BACK
            else CameraSelector.LENS_FACING_FRONT
        bindUseCases()
    }

    fun release() {
        try {
            provider?.unbindAll()
        } catch (e: Exception) {
            Log.w(TAG, "unbind failed", e)
        }
        helper?.close()
        helper = null
        executor.shutdown()
    }

    private fun initHelper() {
        if (helper != null) return
        executor.execute {
            try {
                helper = HandLandmarkerHelper(activity.applicationContext, this)
            } catch (e: Exception) {
                Log.e(TAG, "Hand model failed to load", e)
                activity.runOnUiThread { listener.onCameraProblem(R.string.err_model) }
            }
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(activity)
        future.addListener({
            try {
                provider = future.get()
                bindUseCases()
            } catch (e: Exception) {
                Log.e(TAG, "Camera start failed", e)
                isStarted = false
                listener.onCameraProblem(R.string.err_camera)
            }
        }, ContextCompat.getMainExecutor(activity))
    }

    private fun bindUseCases() {
        val cameraProvider = provider ?: return

        var selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
        if (!cameraProvider.hasCamera(selector)) {
            lensFacing =
                if (lensFacing == CameraSelector.LENS_FACING_FRONT) CameraSelector.LENS_FACING_BACK
                else CameraSelector.LENS_FACING_FRONT
            selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
            if (!cameraProvider.hasCamera(selector)) {
                listener.onCameraProblem(R.string.err_no_camera)
                return
            }
        }

        val preview = Preview.Builder()
            .setTargetAspectRatio(AspectRatio.RATIO_4_3)
            .build()
            .also { it.setSurfaceProvider(previewView.surfaceProvider) }

        val analysis = ImageAnalysis.Builder()
            .setTargetAspectRatio(AspectRatio.RATIO_4_3)
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
            .build()
            .also { useCase ->
                useCase.setAnalyzer(executor) { proxy ->
                    val h = helper
                    if (h == null) {
                        proxy.close()
                    } else {
                        h.detectLiveStream(proxy, lensFacing == CameraSelector.LENS_FACING_FRONT)
                    }
                }
            }

        try {
            cameraProvider.unbindAll()
            cameraProvider.bindToLifecycle(activity, selector, preview, analysis)
        } catch (e: Exception) {
            Log.e(TAG, "Use case binding failed", e)
            listener.onCameraProblem(R.string.err_camera)
        }
    }

    // HandLandmarkerHelper.Listener (called on MediaPipe / executor threads)

    override fun onResults(frame: HandFrame) {
        activity.runOnUiThread {
            if (activity.isFinishing || activity.isDestroyed) return@runOnUiThread
            listener.onFrame(frame)
        }
    }

    override fun onError(message: String) {
        activity.runOnUiThread {
            if (activity.isFinishing || activity.isDestroyed) return@runOnUiThread
            listener.onCameraProblem(R.string.err_detection)
        }
    }

    companion object {
        private const val TAG = "HandCameraController"
    }
}
