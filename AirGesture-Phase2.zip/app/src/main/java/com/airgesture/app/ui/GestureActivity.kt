package com.airgesture.app.ui

import android.os.Bundle
import android.os.SystemClock
import android.view.View
import androidx.annotation.StringRes
import androidx.core.content.ContextCompat
import com.airgesture.app.R
import com.airgesture.app.data.GestureSettings
import com.airgesture.app.data.SettingsStore
import com.airgesture.app.databinding.ActivityGestureBinding
import com.airgesture.app.gesture.CancelReason
import com.airgesture.app.gesture.Gesture
import com.airgesture.app.gesture.GestureClassifier
import com.airgesture.app.gesture.GestureEngine
import com.airgesture.app.gesture.GestureEvent
import com.airgesture.app.gesture.GestureStabilizer
import com.airgesture.app.gesture.LandmarkSmoother
import com.airgesture.app.gesture.Phase
import com.airgesture.app.util.Haptics
import com.airgesture.app.vision.HandFrame
import kotlin.math.roundToInt

/**
 * Phase 2 screen: camera + hand tracking + the Grab / Move / Release / Cancel engine.
 * No file is transferred yet; the token you see is a placeholder for the file (Phase 3+).
 */
class GestureActivity : HandCameraActivity() {

    private lateinit var binding: ActivityGestureBinding
    private lateinit var store: SettingsStore
    private lateinit var haptics: Haptics

    private val engine = GestureEngine()
    private val stabilizer = GestureStabilizer()
    private val smoother = LandmarkSmoother()
    private var settings = GestureSettings()

    private var lastFrameTime = 0L
    private var fpsEma = 0f
    private var brightnessEma = -1f
    private var lowLight = false

    private var grabs = 0
    private var releases = 0
    private var cancels = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGestureBinding.inflate(layoutInflater)
        setContentView(binding.root)

        store = SettingsStore(this)
        haptics = Haptics(this)

        binding.backButton.setOnClickListener { finish() }
        binding.switchCameraButton.setOnClickListener {
            resetPipeline()
            switchCamera()
        }

        applySettings()
        resetPipeline()
        binding.statsText.text = getString(R.string.stats_no_hand, 0)
        updateCounters()

        setupCamera(
            binding.previewView,
            binding.permissionPanel.root,
            binding.permissionPanel.grantButton,
            binding.permissionPanel.settingsButton
        )
    }

    override fun onResume() {
        super.onResume()
        applySettings() // picks up changes made in Gesture Settings / Calibration
    }

    private fun applySettings() {
        settings = store.load()
        engine.config = settings.toEngineConfig()
        haptics.enabled = settings.haptics
        if (!settings.lowLightWarning) binding.warningBanner.visibility = View.GONE
    }

    private fun resetPipeline() {
        stabilizer.reset()
        smoother.reset()
        engine.reset()
        binding.overlay.clear()
        renderPhase(Gesture.NONE, false)
    }

    // ---------------------------------------------------------------- frames

    override fun onFrame(frame: HandFrame) {
        updateFps()
        updateLowLight(frame.brightness)

        val landmarks = frame.landmarks
        val gesture: Gesture
        var tooFar = false
        var palmX: Float? = null
        var palmY: Float? = null

        if (landmarks == null) {
            smoother.reset()
            gesture = stabilizer.update(Gesture.NONE)
            binding.overlay.setHand(null, frame.imageWidth, frame.imageHeight, gesture)
        } else {
            val result = GestureClassifier.classify(
                landmarks, frame.imageWidth, frame.imageHeight, settings.thresholds()
            )
            gesture = stabilizer.update(result.gesture)
            tooFar = result.tooFar
            val points = smoother.smooth(landmarks)
            palmX = points.palmCenterX()
            palmY = points.palmCenterY()
            binding.overlay.setHand(points, frame.imageWidth, frame.imageHeight, gesture)
        }

        val aspect = frame.imageHeight.toFloat() / frame.imageWidth.coerceAtLeast(1)
        val events = engine.update(SystemClock.uptimeMillis(), gesture, palmX, palmY, aspect)
        for (event in events) handleEvent(event)

        binding.overlay.setEngine(engine.snapshot)
        renderPhase(gesture, tooFar)
        renderStats(frame, landmarks != null)
    }

    override fun onCameraProblem(@StringRes messageRes: Int) {
        binding.errorBanner.setText(messageRes)
        binding.errorBanner.visibility = View.VISIBLE
    }

    private fun handleEvent(event: GestureEvent) {
        when (event) {
            is GestureEvent.Grabbed -> {
                grabs++
                haptics.grab()
            }
            is GestureEvent.Released -> {
                releases++
                haptics.release()
            }
            is GestureEvent.Cancelled -> {
                cancels++
                haptics.cancel()
            }
            GestureEvent.Armed, GestureEvent.MoveStarted -> Unit
        }
        updateCounters()
    }

    // ---------------------------------------------------------------- rendering

    private fun renderPhase(gesture: Gesture, tooFar: Boolean) {
        val s = engine.snapshot
        val emoji: String
        val title: String
        var hint: String
        val color: Int
        var progress = 0f
        var barColor = R.color.accent

        when (s.phase) {
            Phase.IDLE -> {
                if (gesture == Gesture.NONE) {
                    emoji = "👀"; title = getString(R.string.state_none_title)
                    hint = getString(R.string.state_none_hint)
                } else {
                    emoji = "🖐️"; title = getString(R.string.phase_idle_title)
                    hint = getString(R.string.phase_idle_hint)
                }
                color = R.color.text_primary
            }
            Phase.ARMING -> {
                emoji = "🖐️"; title = getString(R.string.phase_arming_title)
                hint = getString(R.string.phase_arming_hint)
                color = R.color.success; progress = s.progress; barColor = R.color.success
            }
            Phase.READY -> {
                emoji = "✅"; title = getString(R.string.phase_ready_title)
                hint = getString(R.string.phase_ready_hint)
                color = R.color.success; progress = 1f; barColor = R.color.success
            }
            Phase.GRABBING -> {
                emoji = "✊"; title = getString(R.string.phase_grabbing_title)
                hint = getString(R.string.phase_grabbing_hint)
                color = R.color.accent2; progress = s.progress; barColor = R.color.accent2
            }
            Phase.GRABBED -> {
                emoji = "✊"; title = getString(R.string.phase_grabbed_title)
                hint = getString(R.string.phase_grabbed_hint)
                color = R.color.accent2; progress = 1f; barColor = R.color.accent2
            }
            Phase.MOVING -> {
                emoji = "➡️"; title = getString(R.string.phase_moving_title)
                hint = getString(R.string.phase_moving_hint)
                color = R.color.accent2; progress = 1f; barColor = R.color.accent2
            }
            Phase.RELEASING -> {
                emoji = "🖐️"; title = getString(R.string.phase_releasing_title)
                hint = getString(R.string.phase_releasing_hint)
                color = R.color.success; progress = s.progress; barColor = R.color.success
            }
            Phase.RELEASED -> {
                emoji = "🚀"; title = getString(R.string.phase_released_title)
                hint = getString(
                    R.string.phase_released_hint,
                    s.lastHeldMs / 1000f,
                    (s.maxDisplacement * 100f).roundToInt()
                )
                color = R.color.success
            }
            Phase.CANCELLED -> {
                emoji = "🚫"; title = getString(R.string.phase_cancelled_title)
                hint = getString(
                    if (s.cancelReason == CancelReason.HAND_LOST) R.string.cancel_reason_lost
                    else R.string.cancel_reason_gesture
                )
                color = R.color.error
            }
        }

        if (s.cancelProgress > 0f) {
            hint = getString(R.string.phase_cancelling_hint)
            progress = s.cancelProgress
            barColor = R.color.error
        } else if (tooFar && s.phase == Phase.IDLE) {
            hint = getString(R.string.hint_move_closer)
        }

        binding.gestureEmoji.text = emoji
        binding.gestureTitle.text = title
        binding.gestureTitle.setTextColor(ContextCompat.getColor(this, color))
        binding.gestureHint.text = hint
        binding.holdProgress.setIndicatorColor(ContextCompat.getColor(this, barColor))
        binding.holdProgress.setProgressCompat((progress * 100f).roundToInt(), false)
    }

    private fun renderStats(frame: HandFrame, hasHand: Boolean) {
        val fps = fpsEma.roundToInt()
        if (!hasHand) {
            binding.statsText.text = getString(R.string.stats_no_hand, fps)
            return
        }
        val handLabel = when (frame.handedness) {
            "Left" -> getString(R.string.hand_left)
            "Right" -> getString(R.string.hand_right)
            else -> "–"
        }
        binding.statsText.text = getString(
            R.string.stats_format,
            handLabel,
            (frame.handednessScore * 100f).roundToInt(),
            fps,
            frame.inferenceMs.toInt()
        )
    }

    private fun updateCounters() {
        binding.countersText.text = getString(R.string.counters_format, grabs, releases, cancels)
    }

    private fun updateFps() {
        val now = SystemClock.uptimeMillis()
        if (lastFrameTime != 0L) {
            val delta = (now - lastFrameTime).coerceAtLeast(1L)
            val instant = 1000f / delta
            fpsEma = if (fpsEma == 0f) instant else 0.9f * fpsEma + 0.1f * instant
        }
        lastFrameTime = now
    }

    /** Smoothed brightness with hysteresis so the warning does not flicker. */
    private fun updateLowLight(brightness: Float) {
        brightnessEma = if (brightnessEma < 0f) brightness else 0.9f * brightnessEma + 0.1f * brightness
        val dark = if (lowLight) brightnessEma < LOW_LIGHT_OFF else brightnessEma < LOW_LIGHT_ON
        if (dark != lowLight) lowLight = dark
        binding.warningBanner.visibility =
            if (lowLight && settings.lowLightWarning) View.VISIBLE else View.GONE
    }

    private companion object {
        const val LOW_LIGHT_ON = 50f   // luminance 0..255: show warning below this
        const val LOW_LIGHT_OFF = 70f  // hide again above this
    }
}
