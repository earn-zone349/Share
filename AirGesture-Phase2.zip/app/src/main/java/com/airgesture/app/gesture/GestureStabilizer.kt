package com.airgesture.app.gesture

/**
 * Debounces per-frame gestures: a new gesture only becomes "stable" after it has been seen
 * for [framesRequired] consecutive frames. This removes flicker between Open Palm and Fist.
 */
class GestureStabilizer(private val framesRequired: Int = 4) {
    var stable: Gesture = Gesture.NONE
        private set
    private var candidate: Gesture = Gesture.NONE
    private var count = 0

    fun update(raw: Gesture): Gesture {
        if (raw == stable) {
            candidate = raw
            count = 0
            return stable
        }
        if (raw == candidate) {
            count++
        } else {
            candidate = raw
            count = 1
        }
        if (count >= framesRequired) {
            stable = candidate
            count = 0
        }
        return stable
    }

    fun reset() {
        stable = Gesture.NONE
        candidate = Gesture.NONE
        count = 0
    }
}
