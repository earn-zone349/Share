package com.airgesture.app.gesture

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark

/** Exponential moving average over landmark positions to reduce jitter in the overlay. */
class LandmarkSmoother(private val alpha: Float = 0.6f) {
    private var prevX: FloatArray? = null
    private var prevY: FloatArray? = null

    fun smooth(landmarks: List<NormalizedLandmark>): HandPoints {
        val n = landmarks.size
        val nx = FloatArray(n) { landmarks[it].x() }
        val ny = FloatArray(n) { landmarks[it].y() }
        val px = prevX
        val py = prevY
        if (px != null && py != null && px.size == n && py.size == n) {
            for (i in 0 until n) {
                nx[i] = alpha * nx[i] + (1f - alpha) * px[i]
                ny[i] = alpha * ny[i] + (1f - alpha) * py[i]
            }
        }
        prevX = nx.copyOf()
        prevY = ny.copyOf()
        return HandPoints(nx, ny)
    }

    fun reset() {
        prevX = null
        prevY = null
    }
}
