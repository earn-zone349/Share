package com.airgesture.app.ui

import android.os.Bundle
import android.os.SystemClock
import android.view.View
import androidx.annotation.StringRes
import com.airgesture.app.R
import com.airgesture.app.databinding.ActivityCalibrationBinding
import com.airgesture.app.data.SettingsStore
import com.airgesture.app.gesture.Gesture
import com.airgesture.app.gesture.GestureClassifier
import com.airgesture.app.gesture.LandmarkSmoother
import com.airgesture.app.vision.HandFrame

/**
 * Guided calibration (about 8 seconds): the user holds an open palm, then a fist.
 * We measure the finger tip/PIP distance ratios and place the open/curled thresholds between
 * the two measured ranges, so detection fits the user's hand, camera distance and phone.
 */
class CalibrationActivity : HandCameraActivity() {

    private enum class Step { INTRO, OPEN, FIST, DONE, FAILED }

    private lateinit var binding: ActivityCalibrationBinding
    private lateinit var store: SettingsStore
    private val smoother = LandmarkSmoother()

    private var step = Step.INTRO
    private var stepStart = 0L
    private val openSamples = ArrayList<Float>()   // weakest finger per frame while palm is open
    private val fistSamples = ArrayList<Float>()   // strongest finger per frame while in a fist
    @StringRes private var failureRes = R.string.calib_fail_nodata

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCalibrationBinding.inflate(layoutInflater)
        setContentView(binding.root)
        store = SettingsStore(this)

        binding.backButton.setOnClickListener { finish() }
        binding.switchCameraButton.setOnClickListener {
            smoother.reset()
            switchCamera()
        }
        binding.actionButton.setOnClickListener {
            when (step) {
                Step.INTRO, Step.FAILED -> startStep(Step.OPEN)
                Step.DONE -> finish()
                else -> Unit
            }
        }
        renderStep()

        setupCamera(
            binding.previewView,
            binding.permissionPanel.root,
            binding.permissionPanel.grantButton,
            binding.permissionPanel.settingsButton
        )
    }

    private fun startStep(next: Step) {
        step = next
        stepStart = SystemClock.uptimeMillis()
        when (next) {
            Step.OPEN -> {
                openSamples.clear()
                fistSamples.clear()
            }
            Step.FIST -> fistSamples.clear()
            else -> Unit
        }
        renderStep()
    }

    override fun onFrame(frame: HandFrame) {
        val landmarks = frame.landmarks
        if (landmarks == null) {
            smoother.reset()
            binding.overlay.setHand(null, frame.imageWidth, frame.imageHeight, Gesture.NONE)
        } else {
            binding.overlay.setHand(
                smoother.smooth(landmarks), frame.imageWidth, frame.imageHeight, Gesture.NONE
            )
        }

        if (step != Step.OPEN && step != Step.FIST) return

        val elapsed = SystemClock.uptimeMillis() - stepStart
        binding.calibProgress.setProgressCompat(
            ((elapsed * 100f) / STEP_MS).toInt().coerceIn(0, 100), false
        )

        if (elapsed >= WARMUP_MS && landmarks != null) {
            val ratios = GestureClassifier.fingerRatios(landmarks, frame.imageWidth, frame.imageHeight)
            if (ratios != null) {
                if (step == Step.OPEN) openSamples.add(ratios.min()) else fistSamples.add(ratios.max())
            }
        }

        if (elapsed >= STEP_MS) {
            if (step == Step.OPEN) startStep(Step.FIST) else finishCalibration()
        }
    }

    override fun onCameraProblem(@StringRes messageRes: Int) {
        binding.errorBanner.setText(messageRes)
        binding.errorBanner.visibility = View.VISIBLE
    }

    private fun finishCalibration() {
        if (openSamples.size < MIN_SAMPLES || fistSamples.size < MIN_SAMPLES) {
            fail(R.string.calib_fail_nodata)
            return
        }
        val openMin = percentile(openSamples, 0.15f)   // open palm: lowest typical ratio
        val fistMax = percentile(fistSamples, 0.85f)   // fist: highest typical ratio
        val gap = openMin - fistMax
        if (gap < MIN_GAP) {
            fail(R.string.calib_fail_similar)
            return
        }
        val extended = (fistMax + 0.65f * gap).coerceIn(1.0f, 2.2f)
        val curled = (fistMax + 0.35f * gap).coerceIn(0.6f, 1.6f)
        if (extended < curled + 0.1f) {
            fail(R.string.calib_fail_similar)
            return
        }
        store.save(
            store.load().copy(extendedRatio = extended, curledRatio = curled, calibrated = true)
        )
        step = Step.DONE
        renderStep()
    }

    private fun fail(@StringRes reason: Int) {
        failureRes = reason
        step = Step.FAILED
        renderStep()
    }

    private fun percentile(values: List<Float>, p: Float): Float {
        val sorted = values.sorted()
        val index = ((sorted.size - 1) * p).toInt().coerceIn(0, sorted.size - 1)
        return sorted[index]
    }

    private fun renderStep() {
        val title: Int
        val body: Int
        var buttonText = 0
        when (step) {
            Step.INTRO -> {
                title = R.string.calib_intro_title; body = R.string.calib_intro_body
                buttonText = R.string.calib_start
            }
            Step.OPEN -> {
                title = R.string.calib_open_title; body = R.string.calib_open_body
            }
            Step.FIST -> {
                title = R.string.calib_fist_title; body = R.string.calib_fist_body
            }
            Step.DONE -> {
                title = R.string.calib_done_title; body = R.string.calib_done_body
                buttonText = R.string.calib_finish
            }
            Step.FAILED -> {
                title = R.string.calib_fail_title; body = failureRes
                buttonText = R.string.calib_retry
            }
        }
        binding.calibTitle.setText(title)
        binding.calibBody.setText(body)
        binding.calibProgress.visibility =
            if (step == Step.OPEN || step == Step.FIST) View.VISIBLE else View.GONE
        binding.calibProgress.setProgressCompat(0, false)
        if (buttonText == 0) {
            binding.actionButton.visibility = View.GONE
        } else {
            binding.actionButton.visibility = View.VISIBLE
            binding.actionButton.setText(buttonText)
        }
    }

    private companion object {
        const val STEP_MS = 3500L
        const val WARMUP_MS = 800L
        const val MIN_SAMPLES = 15
        const val MIN_GAP = 0.25f
    }
}
