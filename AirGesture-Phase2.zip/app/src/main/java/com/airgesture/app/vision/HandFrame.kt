package com.airgesture.app.vision

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark

/**
 * One processed camera frame. [landmarks] is null when no hand was found.
 * [brightness] is the average luminance of the frame (0..255), used for the low-light warning.
 */
data class HandFrame(
    val landmarks: List<NormalizedLandmark>?,
    val handedness: String?,
    val handednessScore: Float,
    val imageWidth: Int,
    val imageHeight: Int,
    val inferenceMs: Long,
    val brightness: Float
)
