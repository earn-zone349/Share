package com.airgesture.app.gesture

import kotlin.math.max
import kotlin.math.sqrt

/** Where the Grab -> Move -> Release flow currently is. */
enum class Phase { IDLE, ARMING, READY, GRABBING, GRABBED, MOVING, RELEASING, RELEASED, CANCELLED }

enum class CancelReason { CANCEL_GESTURE, HAND_LOST }

/** Discrete events emitted by the engine (haptics, counters, and later: file transfer triggers). */
sealed class GestureEvent {
    object Armed : GestureEvent()
    object Grabbed : GestureEvent()
    object MoveStarted : GestureEvent()
    data class Released(val heldMs: Long, val movedDistance: Float) : GestureEvent()
    data class Cancelled(val reason: CancelReason) : GestureEvent()
}

/** All timings in milliseconds. Distances are fractions of the frame width. */
data class EngineConfig(
    val armHoldMs: Long = 500,      // open palm must be held this long before a grab is allowed
    val grabHoldMs: Long = 300,     // fist must be held this long to count as a grab
    val releaseHoldMs: Long = 250,  // open palm must be held this long to count as a release
    val cancelHoldMs: Long = 600,   // peace sign must be held this long to cancel
    val minGrabMs: Long = 400,      // a release is ignored if it comes sooner than this after the grab
    val moveThreshold: Float = 0.10f,
    val lostTimeoutMs: Long = 2000, // hand missing this long while grabbed -> cancel
    val readyLostMs: Long = 1500,   // hand missing this long while ready -> back to idle
    val cooldownMs: Long = 1200     // pause after a release/cancel before arming again
)

/** Immutable view of the engine for the UI. */
data class EngineSnapshot(
    val phase: Phase = Phase.IDLE,
    val progress: Float = 0f,         // 0..1 hold progress for ARMING / GRABBING / RELEASING
    val cancelProgress: Float = 0f,   // 0..1 hold progress of the cancel pose
    val palmX: Float = 0.5f,
    val palmY: Float = 0.5f,
    val originX: Float = 0.5f,
    val originY: Float = 0.5f,
    val displacement: Float = 0f,
    val maxDisplacement: Float = 0f,
    val lastHeldMs: Long = 0,
    val cancelReason: CancelReason? = null
)

/**
 * Pure-Kotlin state machine (no Android dependencies, unit-tested).
 *
 * IDLE -open palm held-> ARMING -> READY -fist held-> GRABBING -> GRABBED -moved-> MOVING
 *      -open palm held-> RELEASING -> RELEASED -cooldown-> IDLE
 * Cancel: peace sign held, or hand lost too long, while GRABBED / MOVING / RELEASING.
 *
 * False-gesture protection: a fist only counts after the palm was "armed", every transition needs a
 * hold time, an early release is ignored, brief poses abort, and there is a cooldown after each cycle.
 */
class GestureEngine(var config: EngineConfig = EngineConfig()) {

    var snapshot: EngineSnapshot = EngineSnapshot()
        private set

    private var phase = Phase.IDLE
    private var phaseStart = 0L
    private var lastSeen = 0L
    private var peaceStart = -1L
    private var grabStart = 0L
    private var resumePhase = Phase.GRABBED
    private var palmX = 0.5f
    private var palmY = 0.5f
    private var originX = 0.5f
    private var originY = 0.5f
    private var displacement = 0f
    private var maxDisplacement = 0f
    private var progress = 0f
    private var cancelProgress = 0f
    private var cancelReason: CancelReason? = null
    private var lastHeldMs = 0L

    fun reset() {
        phase = Phase.IDLE
        phaseStart = 0L
        lastSeen = 0L
        peaceStart = -1L
        grabStart = 0L
        resumePhase = Phase.GRABBED
        displacement = 0f
        maxDisplacement = 0f
        progress = 0f
        cancelProgress = 0f
        cancelReason = null
        lastHeldMs = 0L
        snapshot = EngineSnapshot()
    }

    /**
     * Feed one frame.
     * @param gesture debounced gesture (NONE when no hand)
     * @param px palm centre x (0..1) or null when no hand is visible
     * @param aspect frame height / width, so vertical movement is measured in the same units as horizontal
     */
    fun update(timeMs: Long, gesture: Gesture, px: Float?, py: Float?, aspect: Float): List<GestureEvent> {
        val events = ArrayList<GestureEvent>(2)
        val hasPalm = px != null && py != null
        if (gesture != Gesture.NONE) lastSeen = timeMs
        if (px != null && py != null) {
            palmX = px
            palmY = py
        }
        step(timeMs, gesture, hasPalm && gesture != Gesture.NONE, aspect, events)
        snapshot = EngineSnapshot(
            phase = phase,
            progress = progress,
            cancelProgress = cancelProgress,
            palmX = palmX,
            palmY = palmY,
            originX = originX,
            originY = originY,
            displacement = displacement,
            maxDisplacement = maxDisplacement,
            lastHeldMs = lastHeldMs,
            cancelReason = cancelReason
        )
        return events
    }

    private fun enter(next: Phase, timeMs: Long) {
        phase = next
        phaseStart = timeMs
        progress = 0f
        if (next != Phase.GRABBED && next != Phase.MOVING && next != Phase.RELEASING) {
            cancelProgress = 0f
            peaceStart = -1L
        }
    }

    private fun holdProgress(timeMs: Long, holdMs: Long): Float =
        if (holdMs <= 0L) 1f else ((timeMs - phaseStart).toFloat() / holdMs).coerceIn(0f, 1f)

    private fun cancel(reason: CancelReason, timeMs: Long, events: MutableList<GestureEvent>) {
        cancelReason = reason
        enter(Phase.CANCELLED, timeMs)
        events.add(GestureEvent.Cancelled(reason))
    }

    private fun step(
        timeMs: Long,
        gesture: Gesture,
        palmVisible: Boolean,
        aspect: Float,
        events: MutableList<GestureEvent>
    ) {
        val c = config
        when (phase) {
            Phase.IDLE -> {
                if (gesture == Gesture.OPEN_PALM) enter(Phase.ARMING, timeMs)
            }

            Phase.ARMING -> {
                if (gesture != Gesture.OPEN_PALM) {
                    enter(Phase.IDLE, timeMs)
                } else {
                    progress = holdProgress(timeMs, c.armHoldMs)
                    if (progress >= 1f) {
                        enter(Phase.READY, timeMs)
                        events.add(GestureEvent.Armed)
                    }
                }
            }

            Phase.READY -> {
                if (gesture == Gesture.FIST) {
                    enter(Phase.GRABBING, timeMs)
                } else if (gesture == Gesture.NONE && timeMs - lastSeen > c.readyLostMs) {
                    enter(Phase.IDLE, timeMs)
                }
            }

            Phase.GRABBING -> {
                if (gesture != Gesture.FIST) {
                    enter(Phase.READY, timeMs) // too brief: ignore
                } else {
                    progress = holdProgress(timeMs, c.grabHoldMs)
                    if (progress >= 1f) {
                        enter(Phase.GRABBED, timeMs)
                        grabStart = timeMs
                        originX = palmX
                        originY = palmY
                        displacement = 0f
                        maxDisplacement = 0f
                        events.add(GestureEvent.Grabbed)
                    }
                }
            }

            Phase.GRABBED, Phase.MOVING, Phase.RELEASING -> {
                // 1) cancel pose
                if (gesture == Gesture.PEACE) {
                    if (peaceStart < 0L) peaceStart = timeMs
                    cancelProgress = if (c.cancelHoldMs <= 0L) 1f
                    else ((timeMs - peaceStart).toFloat() / c.cancelHoldMs).coerceIn(0f, 1f)
                    if (cancelProgress >= 1f) {
                        cancel(CancelReason.CANCEL_GESTURE, timeMs, events)
                        return
                    }
                } else {
                    peaceStart = -1L
                    cancelProgress = 0f
                }

                // 2) hand lost for too long
                if (gesture == Gesture.NONE && timeMs - lastSeen > c.lostTimeoutMs) {
                    cancel(CancelReason.HAND_LOST, timeMs, events)
                    return
                }

                // 3) movement relative to where the grab happened
                if (palmVisible) {
                    val dx = palmX - originX
                    val dy = (palmY - originY) * aspect
                    displacement = sqrt(dx * dx + dy * dy)
                    maxDisplacement = max(maxDisplacement, displacement)
                }

                val heldLongEnough = timeMs - grabStart >= c.minGrabMs
                when (phase) {
                    Phase.GRABBED -> {
                        if (displacement >= c.moveThreshold) {
                            enter(Phase.MOVING, timeMs)
                            events.add(GestureEvent.MoveStarted)
                        } else if (gesture == Gesture.OPEN_PALM && heldLongEnough) {
                            resumePhase = Phase.GRABBED
                            enter(Phase.RELEASING, timeMs)
                        }
                    }

                    Phase.MOVING -> {
                        if (displacement < c.moveThreshold * 0.6f) {
                            enter(Phase.GRABBED, timeMs)
                        } else if (gesture == Gesture.OPEN_PALM && heldLongEnough) {
                            resumePhase = Phase.MOVING
                            enter(Phase.RELEASING, timeMs)
                        }
                    }

                    Phase.RELEASING -> {
                        if (gesture == Gesture.OPEN_PALM) {
                            progress = holdProgress(timeMs, c.releaseHoldMs)
                            if (progress >= 1f) {
                                lastHeldMs = timeMs - grabStart
                                events.add(GestureEvent.Released(lastHeldMs, maxDisplacement))
                                enter(Phase.RELEASED, timeMs)
                            }
                        } else if (gesture != Gesture.PEACE) {
                            // fist again / unknown: user changed their mind, keep holding
                            enter(resumePhase, timeMs)
                        }
                    }

                    else -> Unit
                }
            }

            Phase.RELEASED, Phase.CANCELLED -> {
                if (timeMs - phaseStart >= c.cooldownMs) enter(Phase.IDLE, timeMs)
            }
        }
    }
}
