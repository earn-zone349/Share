package com.airgesture.app.gesture

/** Per-frame hand poses recognised by the classifier. PEACE (index + middle finger) is the cancel pose. */
enum class Gesture { NONE, OPEN_PALM, FIST, PEACE, UNKNOWN }

/** Result of classifying a single frame. [tooFar] means the hand is too small to classify reliably. */
data class GestureResult(val gesture: Gesture, val tooFar: Boolean)

/** Smoothed landmark positions, normalised 0..1 in the (rotated, mirrored) analysis frame. */
class HandPoints(val x: FloatArray, val y: FloatArray) {
    /** Centre of the palm (wrist + the four finger knuckles), normalised. */
    fun palmCenterX(): Float = average(x)
    fun palmCenterY(): Float = average(y)

    private fun average(values: FloatArray): Float {
        var sum = 0f
        var n = 0
        for (i in PALM_INDICES) {
            if (i < values.size) {
                sum += values[i]
                n++
            }
        }
        return if (n == 0) 0.5f else sum / n
    }

    companion object {
        private val PALM_INDICES = intArrayOf(0, 5, 9, 13, 17)
    }
}
