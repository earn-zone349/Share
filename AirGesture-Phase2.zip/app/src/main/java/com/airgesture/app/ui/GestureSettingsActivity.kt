package com.airgesture.app.ui

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.airgesture.app.R
import com.airgesture.app.data.GestureSettings
import com.airgesture.app.data.SettingsStore
import com.airgesture.app.databinding.ActivityGestureSettingsBinding
import com.google.android.material.slider.Slider

/** Hold-time sliders, calibration entry point, feedback toggles. Every change is saved immediately. */
class GestureSettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGestureSettingsBinding
    private lateinit var store: SettingsStore
    private var loading = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGestureSettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        store = SettingsStore(this)

        binding.backButton.setOnClickListener { finish() }

        bindSlider(binding.armSlider, binding.armValue) { s, v -> s.copy(armHoldMs = v) }
        bindSlider(binding.grabSlider, binding.grabValue) { s, v -> s.copy(grabHoldMs = v) }
        bindSlider(binding.releaseSlider, binding.releaseValue) { s, v -> s.copy(releaseHoldMs = v) }
        bindSlider(binding.cancelSlider, binding.cancelValue) { s, v -> s.copy(cancelHoldMs = v) }

        binding.hapticsSwitch.setOnCheckedChangeListener { _, checked ->
            if (!loading) store.save(store.load().copy(haptics = checked))
        }
        binding.lowLightSwitch.setOnCheckedChangeListener { _, checked ->
            if (!loading) store.save(store.load().copy(lowLightWarning = checked))
        }

        binding.calibrateButton.setOnClickListener {
            startActivity(Intent(this, CalibrationActivity::class.java))
        }
        binding.resetButton.setOnClickListener {
            store.reset()
            bindFromStore()
        }
    }

    override fun onResume() {
        super.onResume()
        bindFromStore() // reflects a calibration finished in the other screen
    }

    private fun bindSlider(
        slider: Slider,
        valueView: TextView,
        update: (GestureSettings, Int) -> GestureSettings
    ) {
        slider.addOnChangeListener { _, value, fromUser ->
            valueView.text = getString(R.string.ms_format, value.toInt())
            if (fromUser && !loading) store.save(update(store.load(), value.toInt()))
        }
    }

    private fun bindFromStore() {
        loading = true
        val s = store.load()
        binding.armSlider.value = s.armHoldMs.toFloat()
        binding.grabSlider.value = s.grabHoldMs.toFloat()
        binding.releaseSlider.value = s.releaseHoldMs.toFloat()
        binding.cancelSlider.value = s.cancelHoldMs.toFloat()
        binding.hapticsSwitch.isChecked = s.haptics
        binding.lowLightSwitch.isChecked = s.lowLightWarning
        binding.calibStatus.setText(
            if (s.calibrated) R.string.settings_calib_done else R.string.settings_calib_default
        )
        loading = false
    }
}
