package com.airgesture.app.gesture

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import kotlin.math.hypot

/**
 * Finger-state thresholds. A finger is "extended" when (tip-to-wrist / pip-to-wrist) >= [extended]
 * and "curled" when that ratio is <= [curled]. Calibration replaces the defaults per user.
 */
data class Thresholds(val extended: Float = 1.15f, val curled: Float = 1.0f)

/**
 * Rule-based classifier working on the 21 MediaPipe hand landmarks. Rotation-invariant and
 * works for both hands. The thumb is ignored (least reliable signal).
 *
 * OPEN_PALM : >= 3 fingers extended, none curled
 * FIST      : none extended, >= 3 curled
 * PEACE     : index + middle extended, ring + pinky curled (cancel pose)
 */
object GestureClassifier {
    private const val WRIST = 0
    private const val MIDDLE_MCP = 9
    private val FINGER_TIPS = intArrayOf(8, 12, 16, 20)   // index, middle, ring, pinky
    private val FINGER_PIPS = intArrayOf(6, 10, 14, 18)
    private const val MIN_HAND_SIZE = 0.05f // wrist -> middle knuckle, fraction of frame diagonal

    private class Measure(val tooFar: Boolean, val ratios: FloatArray?)

    private fun measure(landmarks: List<NormalizedLandmark>, w: Int, h: Int): Measure {
        if (landmarks.size < 21 || w <= 0 || h <= 0) return Measure(false, null)

        fun dist(a: Int, b: Int): Float {
            val dx = (landmarks[a].x() - landmarks[b].x()) * w
            val dy = (landmarks[a].y() - landmarks[b].y()) * h
            return hypot(dx, dy)
        }

        val diagonal = hypot(w.toFloat(), h.toFloat())
        if (dist(WRIST, MIDDLE_MCP) / diagonal < MIN_HAND_SIZE) return Measure(true, null)

        val ratios = FloatArray(4)
        for (i in 0 until 4) {
            val pipDist = dist(FINGER_PIPS[i], WRIST)
            ratios[i] = if (pipDist <= 0f) 0f else dist(FINGER_TIPS[i], WRIST) / pipDist
        }
        return Measure(false, ratios)
    }

    /** Tip/PIP distance ratios for index, middle, ring, pinky; null if the hand is unusable. Used by calibration. */
    fun fingerRatios(landmarks: List<NormalizedLandmark>, w: Int, h: Int): FloatArray? =
        measure(landmarks, w, h).ratios

    fun classify(
        landmarks: List<NormalizedLandmark>,
        imageWidth: Int,
        imageHeight: Int,
        thresholds: Thresholds = Thresholds()
    ): GestureResult {
        val m = measure(landmarks, imageWidth, imageHeight)
        val ratios = m.ratios ?: return GestureResult(Gesture.UNKNOWN, m.tooFar)

        // +1 extended, -1 curled, 0 in between
        val state = IntArray(4) {
            when {
                ratios[it] >= thresholds.extended -> 1
                ratios[it] <= thresholds.curled -> -1
                else -> 0
            }
        }
        val extended = state.count { it == 1 }
        val curled = state.count { it == -1 }

        val gesture = when {
            extended >= 3 && curled == 0 -> Gesture.OPEN_PALM
            extended == 0 && curled >= 3 -> Gesture.FIST
            state[0] == 1 && state[1] == 1 && state[2] == -1 && state[3] == -1 -> Gesture.PEACE
            else -> Gesture.UNKNOWN
        }
        return GestureResult(gesture, false)
    }
}
