package com.airgesture.app.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.airgesture.app.vision.HandCameraController

/**
 * Shared camera screen plumbing: permission flow, controller lifecycle, camera switching.
 * Subclasses call [setupCamera] at the end of onCreate (after setContentView).
 */
abstract class HandCameraActivity : AppCompatActivity(), HandCameraController.Listener {

    private var controller: HandCameraController? = null
    private var permissionPanel: View? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCameraNow() else permissionPanel?.visibility = View.VISIBLE
        }

    protected fun setupCamera(
        previewView: PreviewView,
        permissionPanel: View,
        grantButton: View,
        settingsButton: View
    ) {
        this.permissionPanel = permissionPanel
        controller = HandCameraController(this, previewView, this)

        grantButton.setOnClickListener { permissionLauncher.launch(Manifest.permission.CAMERA) }
        settingsButton.setOnClickListener {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.fromParts("package", packageName, null)
                }
            )
        }

        if (hasCameraPermission()) startCameraNow()
        else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    protected fun switchCamera() {
        controller?.switchCamera()
    }

    private fun hasCameraPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED

    private fun startCameraNow() {
        permissionPanel?.visibility = View.GONE
        controller?.start()
    }

    override fun onResume() {
        super.onResume()
        // Covers the case where permission was granted from system settings.
        val c = controller
        if (c != null && !c.isStarted && hasCameraPermission()) startCameraNow()
    }

    override fun onDestroy() {
        controller?.release()
        controller = null
        super.onDestroy()
    }
}
