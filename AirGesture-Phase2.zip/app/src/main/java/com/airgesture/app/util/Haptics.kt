package com.airgesture.app.util

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/** Short vibration patterns for gesture events. No-op when disabled or unsupported. */
@Suppress("DEPRECATION")
class Haptics(context: Context) {
    var enabled = true

    private val vibrator: Vibrator? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)
                ?.defaultVibrator
        } else {
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }

    fun grab() = pulse(longArrayOf(0, 45))
    fun release() = pulse(longArrayOf(0, 30, 50, 60))
    fun cancel() = pulse(longArrayOf(0, 40, 60, 40, 60, 40))

    private fun pulse(timings: LongArray) {
        val v = vibrator ?: return
        if (!enabled || !v.hasVibrator()) return
        v.vibrate(VibrationEffect.createWaveform(timings, -1))
    }
}
