package com.airgesture.app.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import com.airgesture.app.R
import com.airgesture.app.gesture.EngineSnapshot
import com.airgesture.app.gesture.Gesture
import com.airgesture.app.gesture.HandPoints
import com.airgesture.app.gesture.Phase
import kotlin.math.max

/**
 * Draws on top of the camera preview (FILL_CENTER scaling):
 *  - the 21 hand landmarks
 *  - a hold-progress ring around the palm while arming / grabbing / releasing
 *  - a file "token" that follows the palm while grabbed, plus a line back to the grab origin
 */
class HandOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var points: HandPoints? = null
    private var engine: EngineSnapshot? = null
    private var imageWidth = 1
    private var imageHeight = 1
    private var gesture = Gesture.NONE

    private val density = resources.displayMetrics.density
    private val ringRect = RectF()

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 3f * density
        strokeCap = Paint.Cap.ROUND
    }
    private val pointPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.white)
        style = Paint.Style.FILL
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 6f * density
        strokeCap = Paint.Cap.ROUND
    }
    private val tokenPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = ContextCompat.getColor(context, R.color.accent2)
        alpha = 220
    }
    private val tokenStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * density
        color = ContextCompat.getColor(context, R.color.white)
    }
    private val trailPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * density
        color = ContextCompat.getColor(context, R.color.accent2)
        alpha = 160
        pathEffect = android.graphics.DashPathEffect(floatArrayOf(10f * density, 8f * density), 0f)
    }
    private val originPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = ContextCompat.getColor(context, R.color.accent2)
        alpha = 160
    }
    private val tokenTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = 26f * density
    }

    fun setHand(points: HandPoints?, imageWidth: Int, imageHeight: Int, gesture: Gesture) {
        this.points = points
        this.imageWidth = imageWidth
        this.imageHeight = imageHeight
        this.gesture = gesture
        invalidate()
    }

    fun setEngine(snapshot: EngineSnapshot?) {
        engine = snapshot
        invalidate()
    }

    fun clear() {
        points = null
        engine = null
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (imageWidth <= 0 || imageHeight <= 0 || width == 0 || height == 0) return

        val scale = max(width.toFloat() / imageWidth, height.toFloat() / imageHeight)
        val offsetX = (width - imageWidth * scale) / 2f
        val offsetY = (height - imageHeight * scale) / 2f
        fun mapX(nx: Float) = nx * imageWidth * scale + offsetX
        fun mapY(ny: Float) = ny * imageHeight * scale + offsetY

        drawLandmarks(canvas, ::mapX, ::mapY)
        engine?.let { drawEngine(canvas, it, ::mapX, ::mapY) }
    }

    private fun drawLandmarks(canvas: Canvas, mapX: (Float) -> Float, mapY: (Float) -> Float) {
        val p = points ?: return
        linePaint.color = ContextCompat.getColor(
            context,
            when (gesture) {
                Gesture.OPEN_PALM -> R.color.success
                Gesture.FIST -> R.color.accent2
                Gesture.PEACE -> R.color.warning
                else -> R.color.accent
            }
        )
        val count = p.x.size
        var i = 0
        while (i < CONNECTIONS.size) {
            val a = CONNECTIONS[i]
            val b = CONNECTIONS[i + 1]
            if (a < count && b < count) {
                canvas.drawLine(mapX(p.x[a]), mapY(p.y[a]), mapX(p.x[b]), mapY(p.y[b]), linePaint)
            }
            i += 2
        }
        for (k in 0 until count) {
            canvas.drawCircle(mapX(p.x[k]), mapY(p.y[k]), 4f * density, pointPaint)
        }
    }

    private fun drawEngine(
        canvas: Canvas,
        s: EngineSnapshot,
        mapX: (Float) -> Float,
        mapY: (Float) -> Float
    ) {
        val cx = mapX(s.palmX)
        val cy = mapY(s.palmY)

        // hold-progress ring (arming / grabbing / releasing) or cancel ring
        val ringProgress = when {
            s.cancelProgress > 0f -> s.cancelProgress
            s.phase == Phase.ARMING || s.phase == Phase.GRABBING || s.phase == Phase.RELEASING -> s.progress
            else -> 0f
        }
        if (ringProgress > 0f) {
            ringPaint.color = ContextCompat.getColor(
                context,
                when {
                    s.cancelProgress > 0f -> R.color.error
                    s.phase == Phase.GRABBING -> R.color.accent2
                    else -> R.color.success
                }
            )
            val r = 46f * density
            ringRect.set(cx - r, cy - r, cx + r, cy + r)
            canvas.drawArc(ringRect, -90f, 360f * ringProgress, false, ringPaint)
        }

        // file token while the file is "in hand"
        if (s.phase == Phase.GRABBED || s.phase == Phase.MOVING || s.phase == Phase.RELEASING) {
            val ox = mapX(s.originX)
            val oy = mapY(s.originY)
            canvas.drawLine(ox, oy, cx, cy, trailPaint)
            canvas.drawCircle(ox, oy, 6f * density, originPaint)

            val tokenRadius = 30f * density
            canvas.drawCircle(cx, cy, tokenRadius, tokenPaint)
            canvas.drawCircle(cx, cy, tokenRadius, tokenStrokePaint)
            val textY = cy - (tokenTextPaint.ascent() + tokenTextPaint.descent()) / 2f
            canvas.drawText("📄", cx, textY, tokenTextPaint)
        }
    }

    companion object {
        // Pairs of landmark indices: thumb, index, middle, ring, pinky and palm edges.
        private val CONNECTIONS = intArrayOf(
            0, 1, 1, 2, 2, 3, 3, 4,
            0, 5, 5, 6, 6, 7, 7, 8,
            5, 9, 9, 10, 10, 11, 11, 12,
            9, 13, 13, 14, 14, 15, 15, 16,
            13, 17, 17, 18, 18, 19, 19, 20,
            0, 17
        )
    }
}
