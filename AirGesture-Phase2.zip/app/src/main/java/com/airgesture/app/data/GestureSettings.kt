package com.airgesture.app.data

import android.content.Context
import com.airgesture.app.gesture.EngineConfig
import com.airgesture.app.gesture.Thresholds

data class GestureSettings(
    val extendedRatio: Float = 1.15f,
    val curledRatio: Float = 1.0f,
    val calibrated: Boolean = false,
    val armHoldMs: Int = 500,
    val grabHoldMs: Int = 300,
    val releaseHoldMs: Int = 250,
    val cancelHoldMs: Int = 600,
    val haptics: Boolean = true,
    val lowLightWarning: Boolean = true
) {
    fun thresholds() = Thresholds(extended = extendedRatio, curled = curledRatio)

    fun toEngineConfig() = EngineConfig(
        armHoldMs = armHoldMs.toLong(),
        grabHoldMs = grabHoldMs.toLong(),
        releaseHoldMs = releaseHoldMs.toLong(),
        cancelHoldMs = cancelHoldMs.toLong()
    )
}

/** Persists [GestureSettings] in SharedPreferences. */
class SettingsStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("gesture_settings", Context.MODE_PRIVATE)

    fun load(): GestureSettings {
        val d = GestureSettings()
        return GestureSettings(
            extendedRatio = prefs.getFloat(K_EXT, d.extendedRatio),
            curledRatio = prefs.getFloat(K_CURL, d.curledRatio),
            calibrated = prefs.getBoolean(K_CALIBRATED, d.calibrated),
            armHoldMs = prefs.getInt(K_ARM, d.armHoldMs),
            grabHoldMs = prefs.getInt(K_GRAB, d.grabHoldMs),
            releaseHoldMs = prefs.getInt(K_RELEASE, d.releaseHoldMs),
            cancelHoldMs = prefs.getInt(K_CANCEL, d.cancelHoldMs),
            haptics = prefs.getBoolean(K_HAPTICS, d.haptics),
            lowLightWarning = prefs.getBoolean(K_LOWLIGHT, d.lowLightWarning)
        )
    }

    fun save(s: GestureSettings) {
        prefs.edit()
            .putFloat(K_EXT, s.extendedRatio)
            .putFloat(K_CURL, s.curledRatio)
            .putBoolean(K_CALIBRATED, s.calibrated)
            .putInt(K_ARM, s.armHoldMs)
            .putInt(K_GRAB, s.grabHoldMs)
            .putInt(K_RELEASE, s.releaseHoldMs)
            .putInt(K_CANCEL, s.cancelHoldMs)
            .putBoolean(K_HAPTICS, s.haptics)
            .putBoolean(K_LOWLIGHT, s.lowLightWarning)
            .apply()
    }

    fun reset() {
        prefs.edit().clear().apply()
    }

    private companion object {
        const val K_EXT = "extended_ratio"
        const val K_CURL = "curled_ratio"
        const val K_CALIBRATED = "calibrated"
        const val K_ARM = "arm_hold_ms"
        const val K_GRAB = "grab_hold_ms"
        const val K_RELEASE = "release_hold_ms"
        const val K_CANCEL = "cancel_hold_ms"
        const val K_HAPTICS = "haptics"
        const val K_LOWLIGHT = "low_light_warning"
    }
}
