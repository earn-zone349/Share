package com.airgesture.app.transfer

import com.airgesture.app.transfer.TransferProtocol.Msg
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.util.Locale

class TransferLogicTest {

    private fun roundTrip(msg: Msg) {
        val bytes = TransferProtocol.encode(msg)
        assertTrue(TransferProtocol.isTransferMessage(bytes))
        assertEquals(msg, TransferProtocol.decode(bytes))
    }

    @Test
    fun everyMessageSurvivesARoundTrip() {
        roundTrip(Msg.Offer("ID1", 3, 123456789012L, "রাকিব ছবি.jpg"))
        roundTrip(Msg.Accept("ID1"))
        roundTrip(Msg.Decline("ID1", TransferProtocol.DECLINE_SPACE))
        roundTrip(Msg.FileHeader("ID1", 2, "video.mp4", 5_000_000_000L, "video/mp4", -8123456789L))
        roundTrip(Msg.FileHash("ID1", 2, "ab".repeat(32)))
        roundTrip(Msg.FileHash("ID1", 0, ""))
        roundTrip(Msg.FileResult("ID1", 1, false, TransferProtocol.RESULT_HASH, -42L))
        roundTrip(Msg.Cancel("ID1"))
        roundTrip(Msg.End("ID1", 2))
    }

    @Test
    fun foreignOrBrokenBytesAreRejected() {
        assertNull(TransferProtocol.decode(byteArrayOf()))
        assertNull(TransferProtocol.decode(byteArrayOf(1, 0, 0)))          // ping/pong/bye range
        assertNull(TransferProtocol.decode(byteArrayOf(0x10)))              // truncated offer
        assertNull(TransferProtocol.decode(byteArrayOf(0x1F, 1, 2, 3)))     // unknown tag
        assertFalse(TransferProtocol.isTransferMessage(byteArrayOf(3)))
    }

    @Test
    fun longNamesAreClippedSoMessagesStaySmall() {
        val bytes = TransferProtocol.encode(Msg.Offer("ID", 1, 1, "x".repeat(5000)))
        assertTrue(bytes.size < 1000)
    }

    @Test
    fun sha256KnownVectors() {
        assertEquals(
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
            Sha256.hex(ByteArrayInputStream("abc".toByteArray()))
        )
        assertEquals(
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
            Sha256.hex(ByteArrayInputStream(ByteArray(0)))
        )
    }

    @Test
    fun sha256IsTheSameForAnyBufferSize() {
        val data = ByteArray(1_000_003) { (it * 31).toByte() }
        val a = Sha256.hex(ByteArrayInputStream(data), 7)
        val b = Sha256.hex(ByteArrayInputStream(data), 256 * 1024)
        assertEquals(a, b)
    }

    @Test
    fun fileNamesAreSanitisedAndUnique() {
        assertEquals("ab.txt", FileNames.sanitize("a/b:.txt"))
        assertEquals("file", FileNames.sanitize("///"))
        assertEquals("passwd", FileNames.sanitize("../../passwd"))
        val long = FileNames.sanitize("x".repeat(300) + ".jpg")
        assertEquals(120, long.length)
        assertTrue(long.endsWith(".jpg"))

        val taken = setOf("photo.jpg", "photo (1).jpg")
        assertEquals("photo (2).jpg", FileNames.unique("photo.jpg") { it in taken })
        assertEquals("new.jpg", FileNames.unique("new.jpg") { it in taken })
    }

    @Test
    fun speedAndDurationFormatting() {
        assertEquals("12.4 MB/s", SpeedFormatter.format(13_002_342L, Locale.US))
        assertEquals("0 B/s", SpeedFormatter.format(-5, Locale.US))
        assertEquals("8s", DurationFormatter.format(8))
        assertEquals("1m 05s", DurationFormatter.format(65))
        assertEquals("1h 02m", DurationFormatter.format(3720))
        assertEquals("–", DurationFormatter.format(-1))
    }
}
