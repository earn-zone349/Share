package com.airgesture.app

import android.app.Activity
import android.app.Application
import android.os.Bundle

/** Tracks whether any screen of the app is visible (used to decide between opening a screen and notifying). */
class AirGestureApp : Application() {
    override fun onCreate() {
        super.onCreate()
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityStarted(activity: Activity) {
                startedCount++
            }

            override fun onActivityStopped(activity: Activity) {
                if (startedCount > 0) startedCount--
            }

            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) = Unit
            override fun onActivityResumed(activity: Activity) = Unit
            override fun onActivityPaused(activity: Activity) = Unit
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit
            override fun onActivityDestroyed(activity: Activity) = Unit
        })
    }

    companion object {
        @Volatile
        private var startedCount = 0

        val isForeground: Boolean get() = startedCount > 0
    }
}
