package com.airgesture.app.transfer

/** Safe file names for received files. */
object FileNames {
    private const val MAX_LEN = 120
    private const val FORBIDDEN = "\\/:*?\"<>|"

    /** Strips path separators and other characters that are unsafe in file names, and shortens long names. */
    fun sanitize(raw: String): String {
        var s = raw.filter { !it.isISOControl() && it !in FORBIDDEN }.trim().trim('.').trim()
        if (s.isEmpty()) return "file"
        if (s.length > MAX_LEN) {
            val dot = s.lastIndexOf('.')
            val ext = if (dot in 1 until s.length && s.length - dot <= 10) s.substring(dot) else ""
            s = s.substring(0, MAX_LEN - ext.length) + ext
        }
        return s
    }

    /** "photo.jpg" -> "photo (1).jpg" -> "photo (2).jpg" until [exists] says the name is free. */
    fun unique(name: String, exists: (String) -> Boolean): String {
        if (!exists(name)) return name
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (true) {
            val candidate = "$base ($i)$ext"
            if (!exists(candidate)) return candidate
            i++
        }
    }
}
