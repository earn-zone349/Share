package com.airgesture.app.transfer

import android.app.Notification
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.airgesture.app.R
import com.airgesture.app.files.SizeFormatter

/**
 * Foreground service that keeps the process (and the Nearby link) alive while a transfer runs, so a long
 * transfer survives the screen turning off. It shows progress in a notification and stops by itself.
 */
class TransferService : Service(), TransferManager.Listener {

    private lateinit var manager: TransferManager

    override fun onCreate() {
        super.onCreate()
        Notifications.ensureChannels(this)
        manager = TransferManager.get(this)
        manager.addListener(this)
        enterForeground(build(manager.snapshot))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!manager.isActive()) stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        manager.removeListener(this)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onTransferChanged(snapshot: TransferManager.Snapshot) {
        if (!manager.isActive()) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, build(snapshot))
    }

    private fun enterForeground(notification: Notification) {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        } else {
            0
        }
        try {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type)
        } catch (e: Exception) {
            Log.w(TAG, "Could not enter the foreground", e)
            stopSelf()
        }
    }

    private fun build(s: TransferManager.Snapshot): Notification {
        val sending = s.direction == TransferManager.Direction.SEND
        val title = getString(
            if (sending) R.string.notif_sending_title else R.string.notif_receiving_title, s.peerName
        )
        val percent = if (s.totalBytes > 0) (s.doneBytes * 100 / s.totalBytes).toInt().coerceIn(0, 100) else 0
        val text = when (s.phase) {
            TransferManager.Phase.OFFERING -> getString(R.string.notif_waiting)
            TransferManager.Phase.AWAITING_ACCEPT -> getString(R.string.notif_awaiting_accept)
            else -> getString(
                R.string.notif_progress, percent,
                SpeedFormatter.format(s.speedBps), SizeFormatter.format(s.totalBytes)
            )
        }
        return NotificationCompat.Builder(this, Notifications.CHANNEL_TRANSFER)
            .setSmallIcon(R.drawable.ic_stat_transfer)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, percent, s.phase == TransferManager.Phase.OFFERING)
            .setContentIntent(Notifications.openTransferIntent(this))
            .build()
    }

    companion object {
        private const val TAG = "TransferService"
        private const val NOTIFICATION_ID = 4001

        fun start(context: Context) {
            try {
                ContextCompat.startForegroundService(context, Intent(context, TransferService::class.java))
            } catch (e: Exception) {
                // the transfer itself still works while the app is open
                Log.w(TAG, "Could not start the transfer service", e)
            }
        }
    }
}
