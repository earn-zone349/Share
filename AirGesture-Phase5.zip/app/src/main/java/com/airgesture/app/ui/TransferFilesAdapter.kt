package com.airgesture.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.airgesture.app.R
import com.airgesture.app.databinding.ItemTransferFileBinding
import com.airgesture.app.files.SizeFormatter
import com.airgesture.app.transfer.TransferManager.FileState
import com.airgesture.app.transfer.TransferManager.FileStatus

class TransferFilesAdapter(
    private val onOpen: (FileState) -> Unit
) : ListAdapter<FileState, TransferFilesAdapter.Holder>(Diff) {

    class Holder(val binding: ItemTransferFileBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(ItemTransferFileBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val file = getItem(position)
        val b = holder.binding
        val context = b.root.context
        val size = SizeFormatter.format(file.size)

        b.tfName.text = file.name
        b.tfIcon.text = when (file.status) {
            FileStatus.PENDING -> "⏳"
            FileStatus.ACTIVE -> "🔄"
            FileStatus.SAVING -> "💾"
            FileStatus.DONE -> "✅"
            FileStatus.FAILED -> "❌"
        }
        b.tfMeta.text = when (file.status) {
            FileStatus.ACTIVE -> {
                val percent = if (file.size > 0) (file.bytes * 100 / file.size).toInt().coerceIn(0, 100) else 0
                val base = context.getString(R.string.file_active_format, size, percent)
                if (file.attempt > 1) context.getString(R.string.file_retry_format, base, file.attempt) else base
            }
            FileStatus.SAVING -> context.getString(R.string.file_saving_format, size)
            FileStatus.FAILED -> context.getString(R.string.file_failed_format, size, file.attempt.coerceAtLeast(1))
            else -> size
        }
        b.root.isClickable = file.uri != null
        b.root.setOnClickListener { if (file.uri != null) onOpen(file) }
    }

    private object Diff : DiffUtil.ItemCallback<FileState>() {
        override fun areItemsTheSame(a: FileState, b: FileState) = a.index == b.index
        override fun areContentsTheSame(a: FileState, b: FileState) = a == b
    }
}
