package com.airgesture.app.ui

import android.Manifest
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.airgesture.app.R
import com.airgesture.app.databinding.ActivityTransferBinding
import com.airgesture.app.files.SelectionStore
import com.airgesture.app.files.SizeFormatter
import com.airgesture.app.net.ConnectionManager
import com.airgesture.app.transfer.DurationFormatter
import com.airgesture.app.transfer.SpeedFormatter
import com.airgesture.app.transfer.TransferManager
import com.airgesture.app.transfer.TransferManager.Direction
import com.airgesture.app.transfer.TransferManager.Phase
import kotlin.math.max

/** Progress, speed and results of the current transfer; also where an incoming offer is accepted. */
class TransferActivity : AppCompatActivity(), TransferManager.Listener {

    private lateinit var binding: ActivityTransferBinding
    private lateinit var manager: TransferManager
    private lateinit var connection: ConnectionManager
    private lateinit var adapter: TransferFilesAdapter

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* best effort */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTransferBinding.inflate(layoutInflater)
        setContentView(binding.root)
        manager = TransferManager.get(this)
        connection = ConnectionManager.get(this)

        adapter = TransferFilesAdapter { openFile(it) }
        binding.fileList.layoutManager = LinearLayoutManager(this)
        binding.fileList.adapter = adapter

        binding.backButton.setOnClickListener { finish() }
        binding.acceptButton.setOnClickListener { manager.accept() }
        binding.declineButton.setOnClickListener { manager.decline() }
        binding.pauseButton.setOnClickListener {
            if (manager.snapshot.phase == Phase.PAUSED) manager.resume() else manager.pause()
        }
        binding.cancelButton.setOnClickListener { manager.cancel() }
        binding.retryButton.setOnClickListener {
            when (manager.retryFailed()) {
                TransferManager.SendResult.NOT_CONNECTED -> toast(R.string.msg_not_connected)
                TransferManager.SendResult.BUSY -> toast(R.string.msg_transfer_busy)
                else -> Unit
            }
        }
        binding.openFolderButton.setOnClickListener {
            try {
                startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
            } catch (e: ActivityNotFoundException) {
                toast(R.string.msg_cannot_open_file)
            }
        }
        binding.sendNowButton.setOnClickListener { TransferLauncher.sendSelection(this) }
        binding.closeButton.setOnClickListener {
            manager.dismissFinished()
        }

        askForNotificationsOnce()
    }

    override fun onStart() {
        super.onStart()
        manager.addListener(this)
        render(manager.snapshot)
    }

    override fun onStop() {
        manager.removeListener(this)
        super.onStop()
    }

    override fun onTransferChanged(snapshot: TransferManager.Snapshot) = render(snapshot)

    // ---------------------------------------------------------------- rendering

    private fun render(s: TransferManager.Snapshot) {
        val sending = s.direction == Direction.SEND
        val peer = s.peerName
        val active = manager.isActive()
        val terminal = s.phase == Phase.COMPLETED || s.phase == Phase.FAILED ||
            s.phase == Phase.CANCELLED || s.phase == Phase.DECLINED

        var emoji = "📭"
        var title = getString(R.string.transfer_idle_title)
        var subtitle = ""

        when (s.phase) {
            Phase.IDLE -> {
                subtitle = idleSubtitle()
            }
            Phase.OFFERING -> {
                emoji = "⏳"
                title = getString(R.string.transfer_offering_title, peer)
            }
            Phase.AWAITING_ACCEPT -> {
                emoji = "📥"
                title = getString(R.string.transfer_offer_title)
            }
            Phase.TRANSFERRING -> {
                emoji = if (sending) "📤" else "📥"
                title = getString(
                    if (sending) R.string.transfer_sending_title else R.string.transfer_receiving_title, peer
                )
            }
            Phase.PAUSED -> {
                emoji = "⏸️"
                title = getString(R.string.transfer_paused_title)
                subtitle = getString(R.string.transfer_paused_sub)
            }
            Phase.COMPLETED -> {
                emoji = "✅"
                title = getString(R.string.transfer_done_title)
                subtitle = summary(s, sending)
            }
            Phase.FAILED -> {
                emoji = "⚠️"
                title = getString(R.string.transfer_failed_title)
                subtitle = reasonText(s.reason) ?: summary(s, sending)
            }
            Phase.CANCELLED -> {
                emoji = "🚫"
                title = getString(R.string.transfer_cancelled_title)
                subtitle = reasonText(s.reason) ?: ""
            }
            Phase.DECLINED -> {
                emoji = "🚫"
                title = getString(R.string.transfer_declined_title)
                subtitle = reasonText(s.reason) ?: ""
            }
        }
        binding.transferEmoji.text = emoji
        binding.transferTitle.text = title
        binding.transferSubtitle.text = subtitle
        binding.transferSubtitle.visibility = if (subtitle.isEmpty()) View.GONE else View.VISIBLE

        // incoming offer
        binding.offerCard.visibility = if (s.phase == Phase.AWAITING_ACCEPT) View.VISIBLE else View.GONE
        if (s.phase == Phase.AWAITING_ACCEPT) {
            binding.offerText.text = getString(
                R.string.transfer_offer_text, peer, s.offerCount, SizeFormatter.format(s.totalBytes)
            )
            binding.offerFirst.text = getString(R.string.transfer_offer_first, s.offerFirstName)
        }

        // progress
        val running = s.phase == Phase.TRANSFERRING || s.phase == Phase.PAUSED
        val showBar = running || s.phase == Phase.OFFERING || s.phase == Phase.COMPLETED
        binding.transferProgress.visibility = if (showBar) View.VISIBLE else View.GONE
        if (showBar) {
            val percent = when {
                s.phase == Phase.COMPLETED -> 100
                s.totalBytes > 0 -> (s.doneBytes * 100 / s.totalBytes).toInt().coerceIn(0, 100)
                else -> 0
            }
            val indeterminate = s.phase == Phase.OFFERING
            if (binding.transferProgress.isIndeterminate != indeterminate) {
                binding.transferProgress.visibility = View.INVISIBLE
                binding.transferProgress.isIndeterminate = indeterminate
                binding.transferProgress.visibility = View.VISIBLE
            }
            if (!indeterminate) binding.transferProgress.setProgressCompat(percent, false)
        }

        binding.transferStats.visibility = if (running) View.VISIBLE else View.GONE
        if (running) {
            val done = SizeFormatter.format(s.doneBytes)
            val total = SizeFormatter.format(s.totalBytes)
            val speed = SpeedFormatter.format(s.speedBps)
            binding.transferStats.text =
                if (s.etaSeconds >= 0 && s.speedBps > 0) {
                    getString(R.string.transfer_progress_format, done, total, speed, DurationFormatter.format(s.etaSeconds))
                } else {
                    getString(R.string.transfer_progress_noeta, done, total, speed)
                }
        }

        val current = s.files.getOrNull(s.currentIndex)
        binding.currentFileText.visibility = if (running && current != null) View.VISIBLE else View.GONE
        if (running && current != null) {
            val count = if (sending) s.files.size else max(s.offerCount, s.files.size)
            binding.currentFileText.text =
                getString(R.string.transfer_current_format, current.index + 1, count, current.name)
        }

        // buttons
        binding.pauseButton.visibility = if (sending && running) View.VISIBLE else View.GONE
        binding.pauseButton.setText(if (s.phase == Phase.PAUSED) R.string.btn_resume else R.string.btn_pause)
        binding.cancelButton.visibility =
            if (active && s.phase != Phase.AWAITING_ACCEPT) View.VISIBLE else View.GONE
        binding.retryButton.visibility =
            if (terminal && sending && s.files.any { it.status != TransferManager.FileStatus.DONE }) View.VISIBLE
            else View.GONE
        binding.openFolderButton.visibility =
            if (terminal && !sending && s.received.isNotEmpty()) View.VISIBLE else View.GONE
        binding.closeButton.visibility = if (terminal) View.VISIBLE else View.GONE
        binding.sendNowButton.visibility =
            if (s.phase == Phase.IDLE && connection.isConnected && SelectionStore.snapshot().isNotEmpty())
                View.VISIBLE else View.GONE

        adapter.submitList(s.files)
    }

    private fun idleSubtitle(): String {
        if (!connection.isConnected) return getString(R.string.transfer_idle_not_connected)
        val peer = connection.state.peerName.orEmpty()
        return if (SelectionStore.snapshot().isEmpty()) getString(R.string.transfer_idle_no_files, peer)
        else getString(R.string.transfer_idle_connected, peer)
    }

    private fun summary(s: TransferManager.Snapshot, sending: Boolean): String {
        val seconds = max((s.endedAtMs - s.startedAtMs) / 1000L, 1L)
        val total = max(s.files.size, if (sending) 0 else s.offerCount)
        val doneBytes = s.files.filter { it.status == TransferManager.FileStatus.DONE }.sumOf { it.size }
        return if (s.doneCount == total) {
            getString(
                R.string.transfer_summary_format, s.doneCount, SizeFormatter.format(doneBytes),
                SpeedFormatter.format(doneBytes / seconds), DurationFormatter.format(seconds)
            )
        } else {
            getString(R.string.transfer_summary_partial, s.doneCount, total, SizeFormatter.format(doneBytes))
        }
    }

    private fun reasonText(reason: TransferManager.Reason): String? {
        @StringRes val res = when (reason) {
            TransferManager.Reason.NONE -> return null
            TransferManager.Reason.DECLINED -> R.string.reason_declined
            TransferManager.Reason.BUSY -> R.string.reason_busy
            TransferManager.Reason.NO_SPACE -> R.string.reason_no_space
            TransferManager.Reason.CONNECTION_LOST -> R.string.reason_connection_lost
            TransferManager.Reason.PEER_CANCELLED -> R.string.reason_peer_cancelled
            TransferManager.Reason.TIMEOUT -> R.string.reason_timeout
            TransferManager.Reason.SOME_FAILED -> R.string.reason_some_failed
        }
        return getString(res)
    }

    // ---------------------------------------------------------------- helpers

    private fun openFile(file: TransferManager.FileState) {
        val uri = file.uri ?: return
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, file.mime.ifBlank { "*/*" })
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            toast(R.string.msg_cannot_open_file)
        }
    }

    private fun toast(@StringRes message: Int) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    /** Android 13+ needs a runtime permission for the progress notification; ask once, never insist. */
    private fun askForNotificationsOnce() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        val prefs = getSharedPreferences("app", MODE_PRIVATE)
        if (granted || prefs.getBoolean(KEY_ASKED, false)) return
        prefs.edit().putBoolean(KEY_ASKED, true).apply()
        notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    private companion object {
        const val KEY_ASKED = "asked_notifications"
    }
}
