package com.airgesture.app.transfer

import com.airgesture.app.files.SizeFormatter
import java.util.Locale

object SpeedFormatter {
    fun format(bytesPerSecond: Long, locale: Locale = Locale.getDefault()): String =
        SizeFormatter.format(bytesPerSecond.coerceAtLeast(0), locale) + "/s"
}

object DurationFormatter {
    /** 8 -> "8s", 65 -> "1m 05s", 3720 -> "1h 02m", negative -> "–". */
    fun format(totalSeconds: Long): String {
        if (totalSeconds < 0) return "–"
        if (totalSeconds < 60) return "${totalSeconds}s"
        val minutes = totalSeconds / 60
        if (totalSeconds < 3600) return "${minutes}m ${(totalSeconds % 60).toString().padStart(2, '0')}s"
        return "${minutes / 60}h ${(minutes % 60).toString().padStart(2, '0')}m"
    }
}
