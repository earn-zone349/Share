package com.airgesture.app.ui

import android.app.Activity
import android.content.Intent
import android.widget.Toast
import androidx.annotation.StringRes
import com.airgesture.app.R
import com.airgesture.app.files.SelectionStore
import com.airgesture.app.transfer.TransferManager

/** Starts sending the selected files to the connected phone (used by the gesture release and the buttons). */
object TransferLauncher {
    fun sendSelection(activity: Activity) {
        when (TransferManager.get(activity).send(SelectionStore.snapshot())) {
            TransferManager.SendResult.STARTED ->
                activity.startActivity(Intent(activity, TransferActivity::class.java))
            TransferManager.SendResult.EMPTY -> toast(activity, R.string.msg_no_files)
            TransferManager.SendResult.NOT_CONNECTED -> toast(activity, R.string.msg_not_connected)
            TransferManager.SendResult.BUSY -> toast(activity, R.string.msg_transfer_busy)
        }
    }

    private fun toast(activity: Activity, @StringRes message: Int) {
        Toast.makeText(activity, message, Toast.LENGTH_LONG).show()
    }
}
