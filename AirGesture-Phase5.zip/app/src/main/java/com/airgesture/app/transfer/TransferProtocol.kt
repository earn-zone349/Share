package com.airgesture.app.transfer

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream

/**
 * Control messages exchanged over Nearby BYTES payloads while files travel as FILE payloads.
 * Binary format (DataOutputStream): one tag byte (0x10..0x17) followed by the fields. Pure Kotlin.
 *
 * Flow:  sender OFFER -> receiver ACCEPT/DECLINE -> per file: FILE_HEADER, file payload, FILE_HASH
 *        -> receiver FILE_RESULT (after saving and verifying) -> sender END.  CANCEL ends it from either side.
 * Offer, header and hash stay tiny, so every message fits Nearby's 32 KB BYTES limit.
 */
object TransferProtocol {
    const val MAX_NAME_CHARS = 200

    const val DECLINE_USER = 0
    const val DECLINE_BUSY = 1
    const val DECLINE_SPACE = 2

    const val RESULT_OK = 0
    const val RESULT_HASH = 1
    const val RESULT_STORAGE = 2
    const val RESULT_TRANSFER = 3

    private const val TAG_OFFER = 0x10
    private const val TAG_ACCEPT = 0x11
    private const val TAG_DECLINE = 0x12
    private const val TAG_HEADER = 0x13
    private const val TAG_HASH = 0x14
    private const val TAG_RESULT = 0x15
    private const val TAG_CANCEL = 0x16
    private const val TAG_END = 0x17

    sealed class Msg {
        data class Offer(val id: String, val count: Int, val totalBytes: Long, val firstName: String) : Msg()
        data class Accept(val id: String) : Msg()
        data class Decline(val id: String, val reason: Int) : Msg()
        data class FileHeader(
            val id: String, val index: Int, val name: String, val size: Long,
            val mime: String, val payloadId: Long
        ) : Msg()
        /** [sha256] is empty when the sender could not compute it (receiver then skips verification). */
        data class FileHash(val id: String, val index: Int, val sha256: String) : Msg()
        data class FileResult(
            val id: String, val index: Int, val ok: Boolean, val reason: Int, val payloadId: Long
        ) : Msg()
        data class Cancel(val id: String) : Msg()
        data class End(val id: String, val failedCount: Int) : Msg()
    }

    fun isTransferMessage(bytes: ByteArray): Boolean =
        bytes.isNotEmpty() && bytes[0].toInt() in TAG_OFFER..TAG_END

    private fun clip(s: String) = if (s.length > MAX_NAME_CHARS) s.substring(0, MAX_NAME_CHARS) else s

    fun encode(msg: Msg): ByteArray {
        val bytes = ByteArrayOutputStream()
        val out = DataOutputStream(bytes)
        when (msg) {
            is Msg.Offer -> {
                out.writeByte(TAG_OFFER); out.writeUTF(msg.id); out.writeInt(msg.count)
                out.writeLong(msg.totalBytes); out.writeUTF(clip(msg.firstName))
            }
            is Msg.Accept -> { out.writeByte(TAG_ACCEPT); out.writeUTF(msg.id) }
            is Msg.Decline -> { out.writeByte(TAG_DECLINE); out.writeUTF(msg.id); out.writeInt(msg.reason) }
            is Msg.FileHeader -> {
                out.writeByte(TAG_HEADER); out.writeUTF(msg.id); out.writeInt(msg.index)
                out.writeUTF(clip(msg.name)); out.writeLong(msg.size); out.writeUTF(msg.mime)
                out.writeLong(msg.payloadId)
            }
            is Msg.FileHash -> {
                out.writeByte(TAG_HASH); out.writeUTF(msg.id); out.writeInt(msg.index); out.writeUTF(msg.sha256)
            }
            is Msg.FileResult -> {
                out.writeByte(TAG_RESULT); out.writeUTF(msg.id); out.writeInt(msg.index)
                out.writeBoolean(msg.ok); out.writeInt(msg.reason); out.writeLong(msg.payloadId)
            }
            is Msg.Cancel -> { out.writeByte(TAG_CANCEL); out.writeUTF(msg.id) }
            is Msg.End -> { out.writeByte(TAG_END); out.writeUTF(msg.id); out.writeInt(msg.failedCount) }
        }
        out.flush()
        return bytes.toByteArray()
    }

    /** Returns null for anything that is not a well-formed transfer message. */
    fun decode(bytes: ByteArray): Msg? {
        if (!isTransferMessage(bytes)) return null
        return try {
            val input = DataInputStream(ByteArrayInputStream(bytes))
            when (input.readUnsignedByte()) {
                TAG_OFFER -> Msg.Offer(input.readUTF(), input.readInt(), input.readLong(), input.readUTF())
                TAG_ACCEPT -> Msg.Accept(input.readUTF())
                TAG_DECLINE -> Msg.Decline(input.readUTF(), input.readInt())
                TAG_HEADER -> Msg.FileHeader(
                    input.readUTF(), input.readInt(), input.readUTF(), input.readLong(),
                    input.readUTF(), input.readLong()
                )
                TAG_HASH -> Msg.FileHash(input.readUTF(), input.readInt(), input.readUTF())
                TAG_RESULT -> Msg.FileResult(
                    input.readUTF(), input.readInt(), input.readBoolean(), input.readInt(), input.readLong()
                )
                TAG_CANCEL -> Msg.Cancel(input.readUTF())
                TAG_END -> Msg.End(input.readUTF(), input.readInt())
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }
}
