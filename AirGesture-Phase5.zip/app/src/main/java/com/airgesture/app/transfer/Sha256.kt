package com.airgesture.app.transfer

import java.io.InputStream
import java.security.MessageDigest

/** SHA-256 helpers used to verify that a received file is byte-for-byte identical to the original. */
object Sha256 {
    private const val HEX = "0123456789abcdef"

    fun newDigest(): MessageDigest = MessageDigest.getInstance("SHA-256")

    fun toHex(bytes: ByteArray): String {
        val sb = StringBuilder(bytes.size * 2)
        for (b in bytes) {
            val v = b.toInt() and 0xFF
            sb.append(HEX[v shr 4]).append(HEX[v and 0x0F])
        }
        return sb.toString()
    }

    fun hex(input: InputStream, bufferSize: Int = 256 * 1024): String {
        val digest = newDigest()
        val buffer = ByteArray(bufferSize)
        while (true) {
            val n = input.read(buffer)
            if (n < 0) break
            digest.update(buffer, 0, n)
        }
        return toHex(digest.digest())
    }
}
