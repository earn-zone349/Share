package com.airgesture.app.transfer

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.util.Log
import com.airgesture.app.AirGestureApp
import com.airgesture.app.files.ReceiveFolder
import com.airgesture.app.files.SharedFile
import com.airgesture.app.net.ConnectionManager
import com.airgesture.app.net.PairingProtocol
import com.airgesture.app.transfer.TransferProtocol.Msg
import com.airgesture.app.ui.TransferActivity
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import java.io.IOException
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.max

/**
 * Sends and receives files over the Nearby link ([ConnectionManager]).
 *
 *  - Files travel as Nearby FILE payloads, read straight from their content URI (no copy, no compression,
 *    nothing held in memory), so large files work and the link runs at full speed.
 *  - Files are sent one after another. The receiver must accept the offer first.
 *  - Every file is checked with SHA-256 (computed while the file is sent / saved) and re-sent up to
 *    [MAX_ATTEMPTS] times if it fails.
 *  - Pause takes effect after the current file; cancel stops at once.
 *
 * All state lives on the main thread. Heavy work (hashing, saving, the send loop) runs on executors and
 * hops back with [post].
 */
class TransferManager private constructor(context: Context) :
    ConnectionManager.PayloadListener, ConnectionManager.Listener {

    enum class Direction { SEND, RECEIVE }
    enum class Phase { IDLE, OFFERING, AWAITING_ACCEPT, TRANSFERRING, PAUSED, COMPLETED, FAILED, CANCELLED, DECLINED }
    enum class FileStatus { PENDING, ACTIVE, SAVING, DONE, FAILED }
    enum class Reason {
        NONE, DECLINED, BUSY, NO_SPACE, CONNECTION_LOST, PEER_CANCELLED, TIMEOUT, SOME_FAILED
    }
    enum class SendResult { STARTED, EMPTY, NOT_CONNECTED, BUSY }

    data class FileState(
        val index: Int,
        val name: String,
        val size: Long,
        val bytes: Long = 0L,
        val status: FileStatus = FileStatus.PENDING,
        val attempt: Int = 0,
        val uri: Uri? = null,
        val mime: String = ""
    )

    data class Received(val name: String, val uri: Uri, val mime: String, val size: Long)

    data class Snapshot(
        val phase: Phase = Phase.IDLE,
        val direction: Direction? = null,
        val peerName: String = "",
        val files: List<FileState> = emptyList(),
        val received: List<Received> = emptyList(),
        val totalBytes: Long = 0L,
        val doneBytes: Long = 0L,
        val currentIndex: Int = -1,
        val speedBps: Long = 0L,
        val etaSeconds: Long = -1L,
        val reason: Reason = Reason.NONE,
        val startedAtMs: Long = 0L,
        val endedAtMs: Long = 0L,
        val offerCount: Int = 0,
        val offerFirstName: String = ""
    ) {
        val failedCount: Int get() = files.count { it.status == FileStatus.FAILED }
        val doneCount: Int get() = files.count { it.status == FileStatus.DONE }
    }

    fun interface Listener {
        fun onTransferChanged(snapshot: Snapshot)
    }

    // ------------------------------------------------------------------ internals

    private class FileGate(val index: Int, val payloadId: Long) {
        val latch = CountDownLatch(1)

        @Volatile var payloadDone = false
        @Volatile var payloadFailed = false
        @Volatile var payloadDoneAt = 0L
        @Volatile var lastProgressAt = SystemClock.elapsedRealtime()
        @Volatile var result: Msg.FileResult? = null
    }

    private class SendJob(val id: String, val files: List<SharedFile>) {
        @Volatile var cancelled = false
        @Volatile var paused = false
        @Volatile var gate: FileGate? = null
    }

    private class Incoming(val id: String, val count: Int, val totalBytes: Long) {
        @Volatile var cancelled = false
        val headers = HashMap<Int, Msg.FileHeader>()
        val payloads = HashMap<Long, Payload>()
        val payloadToIndex = HashMap<Long, Int>()
        val completed = HashSet<Long>()
        val saving = HashSet<Int>()
        val expectedHash = HashMap<Int, String>()
        val computedHash = HashMap<Int, String>()
        val targets = HashMap<Int, ReceivedFileSaver.Target>()
        val done = HashSet<Int>()
        var lastActivityAt = SystemClock.elapsedRealtime()
    }

    private enum class Outcome { OK, RETRY, FATAL }

    private val appContext = context.applicationContext
    private val connection = ConnectionManager.get(appContext)
    private val saver = ReceivedFileSaver(appContext)
    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<Listener>()
    private val sendExecutor = Executors.newSingleThreadExecutor()
    private val ioExecutor = Executors.newFixedThreadPool(2)

    @Volatile
    var snapshot: Snapshot = Snapshot()
        private set

    private var phase = Phase.IDLE
    private var direction: Direction? = null
    private var peer = ""
    private var reason = Reason.NONE
    private val files = ArrayList<FileState>()
    private val received = ArrayList<Received>()
    private var totalBytes = 0L
    private var offerCount = 0
    private var offerFirstName = ""
    private var currentIndex = -1
    private var startedAt = 0L
    private var endedAt = 0L
    private var speedBps = 0L
    private var etaSec = -1L
    private var lastSpeedAt = 0L
    private var lastSpeedBytes = 0L
    private var lastPublishAt = 0L
    private var send: SendJob? = null
    private var incoming: Incoming? = null
    private var lastSendFiles: List<SharedFile> = emptyList()

    init {
        connection.payloadListener = this
        connection.addListener(this)
    }

    fun addListener(listener: Listener) {
        listeners.addIfAbsent(listener)
    }

    fun removeListener(listener: Listener) {
        listeners.remove(listener)
    }

    fun isActive(): Boolean = when (phase) {
        Phase.OFFERING, Phase.AWAITING_ACCEPT, Phase.TRANSFERRING, Phase.PAUSED -> true
        else -> false
    }

    // ------------------------------------------------------------------ public API (main thread)

    fun send(list: List<SharedFile>): SendResult {
        if (list.isEmpty()) return SendResult.EMPTY
        if (!connection.isConnected) return SendResult.NOT_CONNECTED
        if (isActive()) return SendResult.BUSY

        resetState()
        val id = PairingProtocol.newId(10)
        val job = SendJob(id, list)
        send = job
        lastSendFiles = list
        direction = Direction.SEND
        peer = connection.state.peerName.orEmpty()
        phase = Phase.OFFERING
        files.addAll(list.mapIndexed { i, f -> FileState(i, f.name, max(f.sizeBytes, 0L)) })
        totalBytes = files.sumOf { it.size }
        publish()

        sendMsg(Msg.Offer(id, list.size, totalBytes, list.first().name))
        main.postDelayed(offerTimeout, OFFER_TIMEOUT_MS)
        TransferService.start(appContext)
        return SendResult.STARTED
    }

    /** Sends again whatever did not arrive in the last outgoing transfer. */
    fun retryFailed(): SendResult {
        if (isActive()) return SendResult.BUSY
        if (direction != Direction.SEND) return SendResult.EMPTY
        val subset = files.filter { it.status != FileStatus.DONE }
            .mapNotNull { lastSendFiles.getOrNull(it.index) }
        return send(subset)
    }

    fun accept() {
        val inc = incoming ?: return
        if (phase != Phase.AWAITING_ACCEPT) return
        main.removeCallbacks(acceptTimeout)
        sendMsg(Msg.Accept(inc.id))
        phase = Phase.TRANSFERRING
        startedAt = SystemClock.elapsedRealtime()
        lastSpeedAt = startedAt
        lastSpeedBytes = 0L
        inc.lastActivityAt = startedAt
        publish()
        main.postDelayed(watchdog, WATCHDOG_MS)
        TransferService.start(appContext)
    }

    fun decline() {
        val inc = incoming ?: return
        if (phase != Phase.AWAITING_ACCEPT) return
        main.removeCallbacks(acceptTimeout)
        sendMsg(Msg.Decline(inc.id, TransferProtocol.DECLINE_USER))
        incoming = null
        resetState()
        publish()
    }

    /** Takes effect after the file that is currently being sent. */
    fun pause() {
        val job = send ?: return
        if (phase != Phase.TRANSFERRING) return
        job.paused = true
        phase = Phase.PAUSED
        publish()
    }

    fun resume() {
        val job = send ?: return
        if (phase != Phase.PAUSED) return
        job.paused = false
        phase = Phase.TRANSFERRING
        publish()
    }

    fun cancel() {
        if (!isActive()) return
        val id = send?.id.takeIf { direction == Direction.SEND } ?: incoming?.id
        id?.let { sendMsg(Msg.Cancel(it)) }
        abortWork()
        endTransfer(Phase.CANCELLED, Reason.NONE)
    }

    /** Clears a finished / failed transfer from the screen. */
    fun dismissFinished() {
        if (isActive()) return
        resetState()
        publish()
    }

    // ------------------------------------------------------------------ connection state

    override fun onStateChanged(state: ConnectionManager.State) {
        if (isActive() && state.status != ConnectionManager.Status.CONNECTED) {
            abortWork()
            endTransfer(Phase.FAILED, Reason.CONNECTION_LOST)
        }
    }

    // ------------------------------------------------------------------ incoming messages (main thread)

    override fun onBytes(endpointId: String, bytes: ByteArray) {
        val msg = TransferProtocol.decode(bytes) ?: return
        when (msg) {
            is Msg.Offer -> onOffer(msg)
            is Msg.Accept -> onAccepted(msg)
            is Msg.Decline -> onDeclined(msg)
            is Msg.FileHeader -> onFileHeader(msg)
            is Msg.FileHash -> onFileHash(msg)
            is Msg.FileResult -> onFileResult(msg)
            is Msg.Cancel -> onPeerCancel(msg)
            is Msg.End -> onEnd(msg)
        }
    }

    override fun onFilePayload(payload: Payload) {
        val inc = incoming
        if (inc == null || inc.cancelled || !isActive()) {
            try { payload.close() } catch (e: Exception) { /* ignore */ }
            return
        }
        inc.lastActivityAt = SystemClock.elapsedRealtime()
        inc.payloads[payload.id] = payload
        inc.payloadToIndex[payload.id]?.let { maybeStartSave(inc, it) }
    }

    override fun onTransferUpdate(update: PayloadTransferUpdate) {
        val now = SystemClock.elapsedRealtime()

        // sender side
        val job = send
        val gate = job?.gate
        if (job != null && gate != null && direction == Direction.SEND && update.payloadId == gate.payloadId) {
            when (update.status) {
                PayloadTransferUpdate.Status.IN_PROGRESS -> {
                    gate.lastProgressAt = now
                    setFile(gate.index) { it.copy(bytes = update.bytesTransferred) }
                    publishThrottled()
                }
                PayloadTransferUpdate.Status.SUCCESS -> {
                    gate.payloadDone = true
                    gate.payloadDoneAt = now
                    gate.lastProgressAt = now
                    setFile(gate.index) { it.copy(bytes = it.size) }
                    publishThrottled()
                }
                PayloadTransferUpdate.Status.FAILURE, PayloadTransferUpdate.Status.CANCELED -> {
                    gate.payloadFailed = true
                    gate.latch.countDown()
                }
            }
            return
        }

        // receiver side
        val inc = incoming ?: return
        if (direction != Direction.RECEIVE || inc.cancelled) return
        inc.lastActivityAt = now
        val index = inc.payloadToIndex[update.payloadId]
        when (update.status) {
            PayloadTransferUpdate.Status.IN_PROGRESS -> {
                if (index != null) {
                    setFile(index) { it.copy(bytes = update.bytesTransferred, status = FileStatus.ACTIVE) }
                    publishThrottled()
                }
            }
            PayloadTransferUpdate.Status.SUCCESS -> {
                inc.completed.add(update.payloadId)
                if (index != null) maybeStartSave(inc, index)
            }
            PayloadTransferUpdate.Status.FAILURE, PayloadTransferUpdate.Status.CANCELED -> {
                if (index != null && inc.headers[index]?.payloadId == update.payloadId) {
                    failIndex(inc, index, TransferProtocol.RESULT_TRANSFER)
                }
            }
        }
    }

    // ---- sender: replies from the receiver

    private fun onAccepted(msg: Msg.Accept) {
        val job = send ?: return
        if (job.id != msg.id || phase != Phase.OFFERING) return
        main.removeCallbacks(offerTimeout)
        phase = Phase.TRANSFERRING
        startedAt = SystemClock.elapsedRealtime()
        lastSpeedAt = startedAt
        lastSpeedBytes = 0L
        publish()
        sendExecutor.execute { runSend(job) }
    }

    private fun onDeclined(msg: Msg.Decline) {
        val job = send ?: return
        if (job.id != msg.id || phase != Phase.OFFERING) return
        val why = when (msg.reason) {
            TransferProtocol.DECLINE_BUSY -> Reason.BUSY
            TransferProtocol.DECLINE_SPACE -> Reason.NO_SPACE
            else -> Reason.DECLINED
        }
        endTransfer(Phase.DECLINED, why)
    }

    private fun onFileResult(msg: Msg.FileResult) {
        val job = send ?: return
        val gate = job.gate ?: return
        if (job.id != msg.id || gate.index != msg.index || gate.payloadId != msg.payloadId) return
        gate.result = msg
        gate.latch.countDown()
    }

    private fun onPeerCancel(msg: Msg.Cancel) {
        val matches = (direction == Direction.SEND && send?.id == msg.id) ||
            (direction == Direction.RECEIVE && incoming?.id == msg.id)
        if (!matches || !isActive()) return
        abortWork()
        endTransfer(Phase.CANCELLED, Reason.PEER_CANCELLED)
    }

    // ---- receiver: offer, headers, hashes

    private fun onOffer(msg: Msg.Offer) {
        if (isActive()) {
            sendMsg(Msg.Decline(msg.id, TransferProtocol.DECLINE_BUSY))
            return
        }
        if (!ReceiveFolder.hasSpaceFor(appContext, msg.totalBytes)) {
            sendMsg(Msg.Decline(msg.id, TransferProtocol.DECLINE_SPACE))
            return
        }
        resetState()
        incoming = Incoming(msg.id, msg.count, msg.totalBytes)
        direction = Direction.RECEIVE
        peer = connection.state.peerName.orEmpty()
        totalBytes = msg.totalBytes
        offerCount = msg.count
        offerFirstName = msg.firstName
        phase = Phase.AWAITING_ACCEPT
        publish()
        main.postDelayed(acceptTimeout, ACCEPT_TIMEOUT_MS)
        surfaceIncomingOffer()
    }

    private fun onFileHeader(msg: Msg.FileHeader) {
        val inc = incoming ?: return
        if (direction != Direction.RECEIVE || msg.id != inc.id || phase != Phase.TRANSFERRING) return
        inc.lastActivityAt = SystemClock.elapsedRealtime()

        val old = inc.headers[msg.index]
        if (old != null && old.payloadId != msg.payloadId) resetIndex(inc, msg.index) // sender is retrying
        inc.headers[msg.index] = msg
        inc.payloadToIndex[msg.payloadId] = msg.index
        val attempt = (files.getOrNull(msg.index)?.attempt ?: 0) + 1
        setFile(msg.index) { FileState(msg.index, msg.name, max(msg.size, 0L), 0L, FileStatus.ACTIVE, attempt) }
        currentIndex = msg.index
        publish()
        maybeStartSave(inc, msg.index)
    }

    private fun onFileHash(msg: Msg.FileHash) {
        val inc = incoming ?: return
        if (direction != Direction.RECEIVE || msg.id != inc.id) return
        inc.lastActivityAt = SystemClock.elapsedRealtime()
        inc.expectedHash[msg.index] = msg.sha256
        maybeVerify(inc, msg.index)
    }

    private fun onEnd(msg: Msg.End) {
        val inc = incoming ?: return
        if (direction != Direction.RECEIVE || msg.id != inc.id || phase != Phase.TRANSFERRING) return
        finishReceive(inc)
    }

    private fun resetIndex(inc: Incoming, index: Int) {
        inc.headers[index]?.let { inc.payloadToIndex.remove(it.payloadId) }
        inc.headers.remove(index)
        inc.saving.remove(index)
        inc.computedHash.remove(index)
        inc.done.remove(index)
        inc.targets.remove(index)?.let { saver.delete(it) }
    }

    private fun maybeStartSave(inc: Incoming, index: Int) {
        val header = inc.headers[index] ?: return
        val payload = inc.payloads[header.payloadId] ?: return
        if (header.payloadId !in inc.completed) return
        if (!inc.saving.add(index)) return
        setFile(index) { it.copy(status = FileStatus.SAVING, bytes = it.size) }
        publish()
        ioExecutor.execute { saveFile(inc, header, payload) }
    }

    /** Background: copy the received file to its final place while hashing it in the same pass. */
    private fun saveFile(inc: Incoming, header: Msg.FileHeader, payload: Payload) {
        var target: ReceivedFileSaver.Target? = null
        try {
            val pfd = payload.asFile()?.asParcelFileDescriptor() ?: throw IOException("No file in payload")
            val created = saver.create(header.name, header.mime)
            target = created
            val digest = Sha256.newDigest()
            ParcelFileDescriptor.AutoCloseInputStream(pfd).use { input ->
                created.output.use { out ->
                    val buffer = ByteArray(COPY_BUFFER)
                    while (true) {
                        if (inc.cancelled) throw IOException("Cancelled")
                        val n = input.read(buffer)
                        if (n < 0) break
                        digest.update(buffer, 0, n)
                        out.write(buffer, 0, n)
                    }
                }
            }
            saver.finish(created)
            val hex = Sha256.toHex(digest.digest())
            post { onSaved(inc, header, created, hex) }
        } catch (e: Exception) {
            Log.w(TAG, "Saving ${header.name} failed", e)
            target?.let { saver.delete(it) }
            post { onSaved(inc, header, null, "") }
        } finally {
            try { payload.close() } catch (e: Exception) { /* ignore */ }
        }
    }

    private fun onSaved(inc: Incoming, header: Msg.FileHeader, target: ReceivedFileSaver.Target?, hex: String) {
        val stale = incoming !== inc || inc.cancelled || !isActive() ||
            inc.headers[header.index]?.payloadId != header.payloadId
        if (stale) {
            target?.let { saver.delete(it) }
            return
        }
        if (target == null) {
            failIndex(inc, header.index, TransferProtocol.RESULT_STORAGE)
            return
        }
        inc.targets[header.index] = target
        inc.computedHash[header.index] = hex
        maybeVerify(inc, header.index)
    }

    private fun maybeVerify(inc: Incoming, index: Int) {
        val computed = inc.computedHash[index] ?: return
        val expected = inc.expectedHash[index] ?: return
        val header = inc.headers[index] ?: return
        val target = inc.targets[index] ?: return
        if (index in inc.done) return

        val ok = expected.isEmpty() || expected.equals(computed, ignoreCase = true)
        if (!ok) {
            saver.delete(target)
            inc.targets.remove(index)
            inc.computedHash.remove(index)
            inc.saving.remove(index)
            setFile(index) { it.copy(status = FileStatus.FAILED) }
            sendMsg(Msg.FileResult(inc.id, index, false, TransferProtocol.RESULT_HASH, header.payloadId))
            publish()
            return
        }

        inc.done.add(index)
        received.add(Received(header.name, target.uri, header.mime, header.size))
        setFile(index) {
            it.copy(status = FileStatus.DONE, bytes = it.size, uri = target.uri, mime = header.mime)
        }
        sendMsg(Msg.FileResult(inc.id, index, true, TransferProtocol.RESULT_OK, header.payloadId))
        publish()
        if (inc.done.size >= inc.count) finishReceive(inc)
    }

    private fun failIndex(inc: Incoming, index: Int, code: Int) {
        inc.targets.remove(index)?.let { saver.delete(it) }
        inc.saving.remove(index)
        inc.computedHash.remove(index)
        setFile(index) { it.copy(status = FileStatus.FAILED) }
        sendMsg(Msg.FileResult(inc.id, index, false, code, inc.headers[index]?.payloadId ?: 0L))
        publish()
    }

    private fun finishReceive(inc: Incoming) {
        if (!isActive()) return
        val failed = inc.count - inc.done.size
        if (failed <= 0) endTransfer(Phase.COMPLETED, Reason.NONE)
        else endTransfer(Phase.FAILED, Reason.SOME_FAILED)
    }

    // ------------------------------------------------------------------ sender worker (background)

    private fun runSend(job: SendJob) {
        var failed = 0
        for (i in job.files.indices) {
            while (job.paused && !job.cancelled) Thread.sleep(200)
            if (job.cancelled) return

            var ok = false
            var attempt = 0
            while (attempt < MAX_ATTEMPTS && !job.cancelled) {
                attempt++
                val n = attempt
                post {
                    currentIndex = i
                    setFile(i) { it.copy(status = FileStatus.ACTIVE, bytes = 0L, attempt = n) }
                    publish()
                }
                when (sendOneFile(job, i)) {
                    Outcome.OK -> ok = true
                    Outcome.FATAL -> attempt = MAX_ATTEMPTS
                    Outcome.RETRY -> Thread.sleep(500)
                }
                if (ok) break
            }
            if (job.cancelled) return
            if (!ok) failed++
            val success = ok
            post {
                setFile(i) {
                    it.copy(status = if (success) FileStatus.DONE else FileStatus.FAILED,
                        bytes = if (success) it.size else it.bytes)
                }
                publish()
            }
        }
        if (job.cancelled) return
        sendMsg(Msg.End(job.id, failed))
        val failedCount = failed
        post {
            if (send === job && !job.cancelled && isActive()) {
                if (failedCount == 0) endTransfer(Phase.COMPLETED, Reason.NONE)
                else endTransfer(Phase.FAILED, Reason.SOME_FAILED)
            }
        }
    }

    private fun sendOneFile(job: SendJob, index: Int): Outcome {
        val file = job.files[index]
        val pfd = try {
            appContext.contentResolver.openFileDescriptor(file.uri, "r")
        } catch (e: Exception) {
            null
        } ?: return Outcome.FATAL

        val size = if (file.sizeBytes >= 0) file.sizeBytes else pfd.statSize
        val payload = Payload.fromFile(pfd)
        val gate = FileGate(index, payload.id)
        job.gate = gate

        val header = Msg.FileHeader(job.id, index, file.name, size, file.mimeType, payload.id)
        if (!sendMsg(header) || !connection.sendPayload(payload)) {
            try { pfd.close() } catch (e: Exception) { /* ignore */ }
            return Outcome.RETRY
        }
        ioExecutor.execute { hashAndSend(job, gate, file) }

        while (true) {
            if (job.cancelled) {
                connection.cancelPayload(payload.id)
                return Outcome.FATAL
            }
            if (gate.latch.await(500, TimeUnit.MILLISECONDS)) break
            if (!connection.isConnected) return Outcome.FATAL
            val now = SystemClock.elapsedRealtime()
            val stalled = if (gate.payloadDone) {
                now - gate.payloadDoneAt > resultWaitMs(size)
            } else {
                now - gate.lastProgressAt > STALL_MS
            }
            if (stalled) {
                connection.cancelPayload(payload.id)
                return Outcome.RETRY
            }
        }
        if (gate.payloadFailed) return Outcome.RETRY
        return if (gate.result?.ok == true) Outcome.OK else Outcome.RETRY
    }

    private fun hashAndSend(job: SendJob, gate: FileGate, file: SharedFile) {
        val hex = try {
            appContext.contentResolver.openInputStream(file.uri)?.use { Sha256.hex(it) } ?: ""
        } catch (e: Exception) {
            "" // empty = "could not compute", the receiver then skips verification
        }
        if (!job.cancelled) sendMsg(Msg.FileHash(job.id, gate.index, hex))
    }

    private fun resultWaitMs(size: Long): Long = 60_000L + size / (10L * 1024 * 1024) * 1000L

    // ------------------------------------------------------------------ state helpers (main thread)

    private fun sendMsg(msg: Msg): Boolean = connection.sendBytes(TransferProtocol.encode(msg))

    private fun post(block: () -> Unit) {
        main.post { block() }
    }

    private fun setFile(index: Int, transform: (FileState) -> FileState) {
        if (index < 0) return
        while (files.size <= index) files.add(FileState(files.size, "…", 0L))
        files[index] = transform(files[index])
    }

    private fun resetState() {
        main.removeCallbacks(offerTimeout)
        main.removeCallbacks(acceptTimeout)
        main.removeCallbacks(watchdog)
        phase = Phase.IDLE
        direction = null
        peer = ""
        reason = Reason.NONE
        files.clear()
        received.clear()
        totalBytes = 0L
        offerCount = 0
        offerFirstName = ""
        currentIndex = -1
        startedAt = 0L
        endedAt = 0L
        speedBps = 0L
        etaSec = -1L
        lastSpeedAt = 0L
        lastSpeedBytes = 0L
        send = null
        incoming = null
    }

    /** Stops background work and removes half-finished files. */
    private fun abortWork() {
        send?.let { job ->
            job.cancelled = true
            job.gate?.let {
                connection.cancelPayload(it.payloadId)
                it.latch.countDown()
            }
        }
        incoming?.let { inc ->
            inc.cancelled = true
            for (id in inc.payloads.keys) connection.cancelPayload(id)
            for ((index, target) in inc.targets) {
                if (index !in inc.done) saver.delete(target)
            }
        }
    }

    private fun endTransfer(newPhase: Phase, newReason: Reason) {
        main.removeCallbacks(offerTimeout)
        main.removeCallbacks(acceptTimeout)
        main.removeCallbacks(watchdog)
        phase = newPhase
        reason = newReason
        endedAt = SystemClock.elapsedRealtime()
        currentIndex = -1
        speedBps = 0L
        etaSec = -1L
        publish()
    }

    private fun doneBytes(): Long = files.sumOf {
        when (it.status) {
            FileStatus.DONE, FileStatus.SAVING -> it.size
            else -> it.bytes
        }
    }

    private fun publish() {
        lastPublishAt = SystemClock.elapsedRealtime()
        snapshot = Snapshot(
            phase = phase,
            direction = direction,
            peerName = peer,
            files = files.toList(),
            received = received.toList(),
            totalBytes = totalBytes,
            doneBytes = doneBytes(),
            currentIndex = currentIndex,
            speedBps = speedBps,
            etaSeconds = etaSec,
            reason = reason,
            startedAtMs = startedAt,
            endedAtMs = endedAt,
            offerCount = offerCount,
            offerFirstName = offerFirstName
        )
        for (l in listeners) l.onTransferChanged(snapshot)
    }

    private fun publishThrottled() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastSpeedAt >= SPEED_SAMPLE_MS) {
            val done = doneBytes()
            val instant = (done - lastSpeedBytes) * 1000L / max(now - lastSpeedAt, 1L)
            speedBps = if (speedBps == 0L) instant else (speedBps * 0.7 + instant * 0.3).toLong()
            etaSec = if (speedBps > 0) max(totalBytes - done, 0L) / speedBps else -1L
            lastSpeedAt = now
            lastSpeedBytes = done
        }
        if (now - lastPublishAt >= PUBLISH_MS) publish()
    }

    // ------------------------------------------------------------------ timers

    private val offerTimeout = Runnable {
        if (phase == Phase.OFFERING) {
            send?.id?.let { sendMsg(Msg.Cancel(it)) }
            abortWork()
            endTransfer(Phase.FAILED, Reason.TIMEOUT)
        }
    }

    private val acceptTimeout = Runnable {
        if (phase == Phase.AWAITING_ACCEPT) decline()
    }

    private val watchdog = object : Runnable {
        override fun run() {
            val inc = incoming
            if (direction == Direction.RECEIVE && phase == Phase.TRANSFERRING && inc != null) {
                val busySaving = inc.saving.size > inc.done.size
                if (!busySaving &&
                    SystemClock.elapsedRealtime() - inc.lastActivityAt > RECEIVE_IDLE_MS
                ) {
                    sendMsg(Msg.Cancel(inc.id))
                    abortWork()
                    endTransfer(Phase.FAILED, Reason.TIMEOUT)
                    return
                }
                main.postDelayed(this, WATCHDOG_MS)
            }
        }
    }

    // ------------------------------------------------------------------ UI hook

    private fun surfaceIncomingOffer() {
        if (AirGestureApp.isForeground) {
            try {
                appContext.startActivity(
                    Intent(appContext, TransferActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                )
            } catch (e: Exception) {
                Log.w(TAG, "Could not open the transfer screen", e)
            }
        } else {
            Notifications.incomingOffer(appContext, peer, offerCount, totalBytes)
        }
    }

    companion object {
        private const val TAG = "TransferManager"
        private const val MAX_ATTEMPTS = 3
        private const val OFFER_TIMEOUT_MS = 60_000L
        private const val ACCEPT_TIMEOUT_MS = 120_000L
        private const val STALL_MS = 45_000L
        private const val RECEIVE_IDLE_MS = 90_000L
        private const val WATCHDOG_MS = 5_000L
        private const val SPEED_SAMPLE_MS = 500L
        private const val PUBLISH_MS = 100L
        private const val COPY_BUFFER = 256 * 1024

        @Volatile
        private var instance: TransferManager? = null

        fun get(context: Context): TransferManager =
            instance ?: synchronized(this) {
                instance ?: TransferManager(context).also { instance = it }
            }
    }
}
