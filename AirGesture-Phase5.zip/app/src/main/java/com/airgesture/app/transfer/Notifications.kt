package com.airgesture.app.transfer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.airgesture.app.R
import com.airgesture.app.files.SizeFormatter
import com.airgesture.app.ui.TransferActivity

object Notifications {
    const val CHANNEL_TRANSFER = "transfer"
    const val CHANNEL_INCOMING = "incoming"
    private const val INCOMING_ID = 4002

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_TRANSFER, context.getString(R.string.channel_transfer),
                NotificationManager.IMPORTANCE_LOW
            )
        )
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_INCOMING, context.getString(R.string.channel_incoming),
                NotificationManager.IMPORTANCE_HIGH
            )
        )
    }

    fun openTransferIntent(context: Context): PendingIntent =
        PendingIntent.getActivity(
            context, 0,
            Intent(context, TransferActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    /** Best effort: does nothing when the user switched notifications off. */
    fun incomingOffer(context: Context, peer: String, count: Int, totalBytes: Long) {
        ensureChannels(context)
        val notification = NotificationCompat.Builder(context, CHANNEL_INCOMING)
            .setSmallIcon(R.drawable.ic_stat_transfer)
            .setContentTitle(context.getString(R.string.notif_incoming_title, peer))
            .setContentText(
                context.getString(R.string.notif_incoming_text, count, SizeFormatter.format(totalBytes))
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openTransferIntent(context))
            .build()
        try {
            val manager = NotificationManagerCompat.from(context)
            if (manager.areNotificationsEnabled()) manager.notify(INCOMING_ID, notification)
        } catch (e: SecurityException) {
            // POST_NOTIFICATIONS not granted
        }
    }
}
