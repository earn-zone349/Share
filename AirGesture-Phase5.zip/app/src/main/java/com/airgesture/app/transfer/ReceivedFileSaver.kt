package com.airgesture.app.transfer

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream

/**
 * Writes received files where the user can find them, without any storage permission:
 *  - Android 10+: MediaStore. Photos go to Pictures/AirGesture, videos to Movies/AirGesture,
 *    music to Music/AirGesture, everything else to Downloads/AirGesture.
 *  - Android 8-9: the app's own external Downloads/AirGesture folder.
 */
class ReceivedFileSaver(context: Context) {
    private val appContext = context.applicationContext
    private val resolver = appContext.contentResolver

    class Target(val uri: Uri, val output: OutputStream, val file: File?)

    @Throws(IOException::class)
    fun create(rawName: String, mime: String): Target {
        val name = FileNames.sanitize(rawName)
        val type = mime.ifBlank { "application/octet-stream" }
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) createInMediaStore(name, type)
        else createLegacy(name)
    }

    /** Call after the output stream was closed. */
    fun finish(target: Target) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && target.file == null) {
            val values = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            resolver.update(target.uri, values, null, null)
        }
    }

    /** Removes a half-written or rejected file. */
    fun delete(target: Target) {
        try {
            target.output.close()
        } catch (e: Exception) {
            // already closed
        }
        try {
            if (target.file != null) target.file.delete() else resolver.delete(target.uri, null, null)
        } catch (e: Exception) {
            // nothing left to remove
        }
    }

    private fun createInMediaStore(name: String, mime: String): Target {
        val (collection, folder) = when {
            mime.startsWith("image/") ->
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to Environment.DIRECTORY_PICTURES
            mime.startsWith("video/") ->
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to Environment.DIRECTORY_MOVIES
            mime.startsWith("audio/") ->
                MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to Environment.DIRECTORY_MUSIC
            else ->
                MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to Environment.DIRECTORY_DOWNLOADS
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "$folder/$FOLDER")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = resolver.insert(collection, values) ?: throw IOException("MediaStore insert failed")
        val output = resolver.openOutputStream(uri)
        if (output == null) {
            resolver.delete(uri, null, null)
            throw IOException("Cannot open output stream")
        }
        return Target(uri, output, null)
    }

    private fun createLegacy(name: String): Target {
        val base = appContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: appContext.filesDir
        val dir = File(base, FOLDER).also { it.mkdirs() }
        val unique = FileNames.unique(name) { File(dir, it).exists() }
        val file = File(dir, unique)
        val uri = FileProvider.getUriForFile(appContext, "${appContext.packageName}.fileprovider", file)
        return Target(uri, FileOutputStream(file), file)
    }

    companion object {
        const val FOLDER = "AirGesture"
    }
}
