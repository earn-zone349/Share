package com.airgesture.app.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.core.os.LocaleListCompat
import com.airgesture.app.R
import com.airgesture.app.databinding.ActivityMainBinding
import com.airgesture.app.databinding.ItemMenuBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private data class MenuEntry(
        val icon: String,
        @StringRes val title: Int,
        @StringRes val subtitle: Int,
        val availableFromPhase: Int,
        val onClick: (() -> Unit)? = null
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.languageButton.setOnClickListener { showLanguageDialog() }
        buildMenu()
    }

    private fun buildMenu() {
        val entries = listOf(
            MenuEntry("🖐️", R.string.menu_gesture_transfer, R.string.menu_gesture_transfer_sub, 1) {
                startActivity(Intent(this, GestureActivity::class.java))
            },
            MenuEntry("📤", R.string.menu_send_files, R.string.menu_send_files_sub, 3) {
                startActivity(Intent(this, SendFilesActivity::class.java))
            },
            MenuEntry("📥", R.string.menu_receive_files, R.string.menu_receive_files_sub, 4),
            MenuEntry("📱", R.string.menu_connected_devices, R.string.menu_connected_devices_sub, 4),
            MenuEntry("🕘", R.string.menu_transfer_history, R.string.menu_transfer_history_sub, 9),
            MenuEntry("🎯", R.string.menu_gesture_settings, R.string.menu_gesture_settings_sub, 2) {
                startActivity(Intent(this, GestureSettingsActivity::class.java))
            },
            MenuEntry("✨", R.string.menu_animation_settings, R.string.menu_animation_settings_sub, 8),
            MenuEntry("🔒", R.string.menu_privacy_security, R.string.menu_privacy_security_sub, 7),
            MenuEntry("📡", R.string.menu_offline_mode, R.string.menu_offline_mode_sub, 4),
            MenuEntry("🛟", R.string.menu_help, R.string.menu_help_sub, 9)
        )

        for (entry in entries) {
            val item = ItemMenuBinding.inflate(layoutInflater, binding.menuContainer, false)
            item.icon.text = entry.icon
            item.title.setText(entry.title)
            item.subtitle.setText(entry.subtitle)

            val action = entry.onClick
            if (action != null) {
                item.badge.visibility = android.view.View.GONE
                item.card.strokeColor = ContextCompat.getColor(this, R.color.accent)
                item.card.setOnClickListener { action() }
            } else {
                item.card.setOnClickListener {
                    Toast.makeText(
                        this,
                        getString(R.string.coming_in_phase, entry.availableFromPhase),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            binding.menuContainer.addView(item.root)
        }
    }

    private fun showLanguageDialog() {
        val tags = arrayOf("", "en", "bn")
        val labels = arrayOf(
            getString(R.string.lang_system),
            getString(R.string.lang_english),
            getString(R.string.lang_bangla)
        )
        val current = AppCompatDelegate.getApplicationLocales().toLanguageTags()
        val checked = when {
            current.startsWith("en") -> 1
            current.startsWith("bn") -> 2
            else -> 0
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.language_title)
            .setSingleChoiceItems(labels, checked) { dialog, which ->
                val tag = tags[which]
                AppCompatDelegate.setApplicationLocales(
                    if (tag.isEmpty()) LocaleListCompat.getEmptyLocaleList()
                    else LocaleListCompat.forLanguageTags(tag)
                )
                dialog.dismiss()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
